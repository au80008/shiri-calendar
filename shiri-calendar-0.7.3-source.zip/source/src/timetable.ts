import { localDateKey } from "./calendar.ts";
import type { CalendarItem } from "./model.ts";

export function shiftDate(date: string, days: number): string {
  const day = new Date(`${date}T12:00:00`);
  day.setDate(day.getDate() + days);
  return localDateKey(day);
}
export function weekDates(date: string): string[] {
  const day = new Date(`${date}T12:00:00`);
  const monday = shiftDate(date, -((day.getDay() + 6) % 7));
  return Array.from({ length: 7 }, (_, i) => shiftDate(monday, i));
}
export function minutes(time: string): number {
  const [hour, minute] = time.split(":").map(Number);
  return hour * 60 + minute;
}
export function clockTime(value: number): string {
  return `${Math.floor(value / 60).toString().padStart(2, "0")}:${(value % 60).toString().padStart(2, "0")}`;
}
export function eventRange(item: CalendarItem): { start: number; end: number } {
  const start = minutes(item.time!);
  return { start, end: item.endTime ? minutes(item.endTime) : Math.min(start + 60, 1440) };
}
export interface TimetableBlock {
  item: CalendarItem;
  start: number;
  end: number;
  column: number;
  columns: number;
}
export function layoutDay(items: CalendarItem[]): TimetableBlock[] {
  const blocks = items.filter(x => x.time).map(item => ({
    item, ...eventRange(item), column: 0, columns: 1,
  })).sort((a, b) => a.start - b.start || b.end - a.end || a.item.id.localeCompare(b.item.id));
  let group: TimetableBlock[] = [], ends: number[] = [], groupEnd = -1;
  const finish = () => group.forEach(block => { block.columns = ends.length; });
  for (const block of blocks) {
    if (block.start >= groupEnd) {
      finish(); group = []; ends = []; groupEnd = -1;
    }
    let column = ends.findIndex(end => end <= block.start);
    if (column < 0) column = ends.length;
    ends[column] = block.end;
    block.column = column;
    group.push(block);
    groupEnd = Math.max(groupEnd, block.end);
  }
  finish();
  return blocks;
}
