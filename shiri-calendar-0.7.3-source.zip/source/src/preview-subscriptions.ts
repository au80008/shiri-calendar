// Development-only deterministic adapter. Production subscription parsing lives in Rust.
import type {AppSnapshot} from './model.ts';
import {clockInZone,dateKeyInZone} from './clock.ts';
import {sourceColors,type SourceInput,type PreviewResult,type ExternalOccurrence,type CalendarSourceSummary,type CalendarViewPrefs} from './subscriptions.ts';
export type PreviewProfile=AppSnapshot&{externalItems?:ExternalOccurrence[];previewLinks?:Record<string,string>;importedOriginals?:Record<string,ExternalOccurrence>};
export function originalTitlePreview(profile:PreviewProfile,item:ExternalOccurrence):string {
 return item.relatedTitle??profile.importedOriginals?.[JSON.stringify([item.sourceId,item.uid,item.recurrenceKey])]?.title??item.title;
}
export function originalSlotPreview(profile:PreviewProfile,item:ExternalOccurrence):string {
 const original=profile.importedOriginals?.[JSON.stringify([item.sourceId,item.uid,item.recurrenceKey])]??item;
 if(original.relatedSlot)return original.relatedSlot;
 if(original.allDay){const first=original.startDate??original.date,last=original.endDate??original.date;return `all-day:${Math.round((Date.parse(last)-Date.parse(first))/86400000)+1}`;}
 const zone=profile.calendarSources?.find(source=>source.id===item.sourceId)?.fallbackZone??'UTC';
 const clock=(raw:string)=>{const date=new Date(raw),wall=clockInZone(date,zone);const seconds=date.getUTCSeconds();return {date:wall.date,time:`${String(wall.hour).padStart(2,'0')}:${String(wall.minute).padStart(2,'0')}${seconds?`:${String(seconds).padStart(2,'0')}`:''}`};};
 if(!original.startUtc||!original.endUtc)return `${original.time??''}–${original.endTime??''}`;
 const start=clock(original.startUtc),end=clock(original.endUtc),span=Math.round((Date.parse(end.date)-Date.parse(start.date))/86400000);
 return `${start.time}–${end.time}${span?` (+${span}d)`:''}`;
}
export function relatedMetadataPreview(profile:PreviewProfile):ExternalOccurrence[] {
 const groups=new Map<string,Set<string>>();
 for(const item of profile.externalItems??[]){const title=originalTitlePreview(profile,item);if(item.recurring||!title.trim())continue;const key=JSON.stringify([item.sourceId,title,originalSlotPreview(profile,item)]);const uids=groups.get(key)??new Set<string>();uids.add(item.uid);groups.set(key,uids);}
 return (profile.externalItems??[]).map(item=>{const title=originalTitlePreview(profile,item),slot=originalSlotPreview(profile,item);const count=item.recurring||!title.trim()?0:groups.get(JSON.stringify([item.sourceId,title,slot]))?.size??0;return {...item,relatedTitle:count>=2?title:null,relatedSlot:count>=2?slot:null,relatedCount:count>=2?count:0};});
}
const tickets=new Map<string,{signature:string;url:string;items:ExternalOccurrence[];at:number}>();
function urlOf(raw:string):URL {let text=raw.trim();if((text.startsWith('"')&&text.endsWith('"'))||(text.startsWith("'")&&text.endsWith("'")))text=text.slice(1,-1);text=text.replace(/^webcals?:/i,'https:');const url=new URL(text);if(!['http:','https:'].includes(url.protocol)||url.username||url.password)throw new Error('请使用 http、https 或 webcal 日历订阅链接');url.hash='';return url;}
function validate(input:SourceInput){if(!input.name.trim()||input.name.length>80)throw new Error('请输入日历名称');urlOf(input.url);clockInZone(new Date(),input.fallbackZone);if(!sourceColors.includes(input.color))throw new Error('日历颜色无效');}
function profiles():Record<string,ExternalOccurrence[]> {return JSON.parse(localStorage.getItem('shiri-preview-feeds')??'{}');}
function defaultItems(input:SourceInput):ExternalOccurrence[]{const date=dateKeyInZone(new Date(),input.fallbackZone);return [{id:'preview-event',sourceId:'',sourceName:input.name,color:input.color,uid:'preview-event',recurrenceKey:'preview',startUtc:`${date}T08:00:00Z`,endUtc:`${date}T09:00:00Z`,allDay:false,date,time:'10:00',endTime:'11:00',title:'预览课程',description:'浏览器开发预览数据',location:'示例教室',continuedBefore:false,continuesAfter:false}];}
export async function inspectPreview(input:SourceInput):Promise<PreviewResult>{
 validate(input);const url=urlOf(input.url);if(url.pathname.includes('html'))throw new Error('此链接未返回日历，请复制 iCal/ICS 订阅地址');if(url.pathname.includes('auth'))throw new Error('此日历需要登录，请使用订阅地址');
 const feeds=profiles();let corrected=false;
 if(!(url.toString() in feeds)){for(const [k,v]of [...url.searchParams])if(v.startsWith('"')&&v.endsWith('"')){url.searchParams.set(k,v.slice(1,-1));corrected=true;}}
 const items=feeds[url.toString()]??defaultItems(input);const ticket=crypto.randomUUID();while(tickets.size>=8)tickets.delete(tickets.keys().next().value!);tickets.set(ticket,{signature:JSON.stringify(input),url:url.toString(),items:structuredClone(items),at:Date.now()});
 const dates=items.map(i=>i.date).sort();return {ticket,canonicalHost:url.hostname,calendarName:input.name,eventCount:items.length,unsupportedCount:0,firstDate:dates[0]??null,lastDate:dates.at(-1)??null,samples:items.slice(0,3).map(i=>({title:i.title,date:i.date,time:i.time,location:i.location})),warnings:corrected?['已清理链接参数外层的复制引号']:[]};
}
export function applySubscriptionPreview(name:string,args:Record<string,unknown>,profile:PreviewProfile):PreviewProfile {
 const next=structuredClone(profile);next.calendarSources??=[];next.previewLinks??={};next.externalItems??=[];const now=new Date().toISOString();
 if(name==='set_calendar_view'){const prefs=args.prefs as CalendarViewPrefs;clockInZone(new Date(),prefs.displayZone);next.calendarView=prefs;return next;}
 if(name==='remove_subscription'){const id=String(args.id);if(!next.calendarSources.some(s=>s.id===id))throw new Error('日历来源已移除');next.calendarSources=next.calendarSources.filter(s=>s.id!==id);next.externalItems=next.externalItems.filter(i=>i.sourceId!==id);delete next.previewLinks[id];return next;}
 if(name==='refresh_calendar')throw new Error('请重新输入链接导入，不自动刷新');
 if(name==='save_subscription'){
  const supplied=args.input as SourceInput;const input={...supplied,url:supplied.url.trim()||next.previewLinks[String(args.id)]||'https://example.invalid/calendar'};validate(input);const id=args.id?String(args.id):crypto.randomUUID();const old=next.calendarSources.find(s=>s.id===id);if(args.id&&!old)throw new Error('日历来源已移除');
  const ticket=args.ticket?tickets.get(String(args.ticket)):undefined;const valid=!!ticket&&ticket.signature===JSON.stringify(supplied)&&Date.now()-ticket.at<600000;
  if(args.ticket&&!valid)throw new Error('预览已过期或输入发生变化，请重新检查链接');
  const needs=!old||next.previewLinks[id]!==urlOf(input.url).toString()||old.fallbackZone!==input.fallbackZone||old.overrideUnknownZone!==input.overrideUnknownZone;
  if(needs&&!valid)throw new Error('请先检查链接，再确认订阅');const canonical=valid?ticket!.url:urlOf(input.url).toString();
  if(Object.entries(next.previewLinks).some(([other,url])=>other!==id&&url===canonical))throw new Error('这个链接已经订阅，可在原日历上立即刷新');
  const source:CalendarSourceSummary={id,name:input.name,host:new URL(canonical).hostname,color:input.color,visible:input.visible,fallbackZone:input.fallbackZone,overrideUnknownZone:input.overrideUnknownZone,reminderMinutes:input.reminderMinutes,revision:(old?.revision??0)+1,feedVersion:(old?.feedVersion??0)+(valid?1:0),eventCount:valid?ticket!.items.length:old?.eventCount??0,lastAttemptAt:valid?now:old?.lastAttemptAt??null,lastSuccessAt:valid?now:old?.lastSuccessAt??null,lastError:null,refreshing:false};
  next.previewLinks[id]=canonical;next.calendarSources=next.calendarSources.filter(s=>s.id!==id).concat(source);
  if(valid){for(const key of Object.keys(next.importedOriginals??{}))if(JSON.parse(key)[0]===id)delete next.importedOriginals![key];}if(valid)next.externalItems=next.externalItems.filter(i=>i.sourceId!==id).concat(ticket!.items.map(i=>({...i,id:`ext:${id}:${i.uid}`,sourceId:id,sourceName:input.name,color:input.color})));
  return next;
 }
 throw new Error('预览不支持此订阅操作');
}
