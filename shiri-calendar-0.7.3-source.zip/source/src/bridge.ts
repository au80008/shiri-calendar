import { invoke, isTauri } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";
export const desktop = isTauri();
export async function command<T>(
  name: string,
  args: Record<string, unknown> = {},
): Promise<T> {
  if (desktop) return invoke<T>(name, args);
  if (
    import.meta.env.DEV &&
    new URLSearchParams(location.search).has("preview")
  ) {
    const preview = await import("./preview.ts");
    return preview.command<T>(name, args);
  }
  throw new Error("请从拾日桌面应用打开");
}
export async function subscribe<T>(event: string, callback: (data: T) => void) {
  if (desktop) return listen<T>(event, (payload) => callback(payload.payload));
  const handler = (e: Event) => callback((e as CustomEvent<T>).detail);
  window.addEventListener(event, handler);
  return () => window.removeEventListener(event, handler);
}
