import "./styles.css";
import "./theme.css";
import "./reminder.css";
import { command, subscribe } from "./bridge.ts";
import type { Reminder } from "./model.ts";
import { button, el, iconButton } from "./ui/dom.ts";
import { t, setLanguage, formatDate, translateError, type Language } from './i18n.ts';
const root = document.querySelector<HTMLElement>("#reminders")!;
let queue: Reminder[] = [];
let error: unknown = "";
function render() {
  document.title = t('日程提醒');
  root.replaceChildren();
  const current = queue[0];
  const head = el("header", "toolbar");
  head.append(
    el(
      "strong",
      "",
      `${t('日程提醒')}${queue.length > 1 ? ` · ${t('{count} 项', {count:queue.length})}` : ""}`,
    ),
    iconButton("close", t("关闭提醒窗口"), () => void close()),
  );
  root.append(head);
  if (!current) {
    root.append(el("p", "reminder-empty", t("目前没有提醒")));
    return;
  }
  const body = el("div", "reminder-body");
  body.append(
    el("h1", "truncate", current.item.title),
    el(
      "p",
      "reminder-time",
      `${formatDate(current.item.date)}  ${current.item.time ?? ""}`,
    ),
  );
  if (error) {
    const message = el("p", "form-error", translateError(error));
    message.setAttribute("role", "alert");
    body.append(message);
  }
  const actions = el("div", "reminder-actions");
  actions.append(
    button(t("关闭"), "secondary-button", () => void close()),
    button(t("查看日程"), "primary-button", () => void act("open_reminder")),
  );
  body.append(actions);
  root.append(body);
}
async function act(name: string) {
  try {
    await command(name, { key: queue[0]?.key ?? "" });
    error = "";
  } catch (e) {
    error = e;
    render();
  }
}
async function close() {
  await act("dismiss_reminder");
}
await subscribe<Reminder[]>("calendar://reminders-changed", (value) => {
  queue = value;
  render();
});
let languageChanged = false;
await subscribe<Language>('calendar://language-changed', language => {
  languageChanged = true;
  setLanguage(language);
  document.documentElement.lang = language;
  render();
});
try {
  const language = await command<Language>('get_language');
  if (!languageChanged) {
    setLanguage(language);
    document.documentElement.lang = language;
  }
  queue = await command<Reminder[]>("get_active_reminders");
  render();
} catch (e) {
  root.append(el("p", "startup-error", translateError(e)));
}
