import {buildMonthGrid, localDateKey, sortItems} from './calendar.ts';
import type {CalendarItem} from './model.ts';

export type OverviewKind = 'month' | 'year';

export function monthDays(year:number, month:number):string[] {
  return buildMonthGrid(year, month);
}

export function yearMonths(year:number):{year:number;month:number;days:string[]}[] {
  return Array.from({length:12}, (_, month) => ({year,month,days:monthDays(year,month)}));
}

export function overviewRange(view:OverviewKind, year:number, month:number):{from:string;to:string} {
  if (view === 'year') return {
    from:localDateKey(new Date(year,0,1,12)),
    to:localDateKey(new Date(year,11,31,12)),
  };
  const days = monthDays(year,month);
  return {from:days[0],to:days[41]};
}

export function groupItemsByDate(items:CalendarItem[]):Map<string,CalendarItem[]> {
  const grouped = new Map<string,CalendarItem[]>();
  for (const item of sortItems(items)) {
    const day = grouped.get(item.date) ?? [];
    day.push(item);
    grouped.set(item.date,day);
  }
  return grouped;
}
