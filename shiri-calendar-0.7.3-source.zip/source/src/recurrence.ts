import type { CalendarItem, Recurrence } from "./model.ts";

const dayMs = 86_400_000;
type CivilDate = { year: number; month: number; day: number; ordinal: number };

function parseDate(value: string): CivilDate | undefined {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return;
  const [year, month, day] = value.split("-").map(Number);
  if (year < 1900 || year > 9999 || month < 1 || month > 12 || day < 1 || day > 31) return;
  const date = new Date(0);
  date.setUTCFullYear(year, month - 1, day);
  date.setUTCHours(0, 0, 0, 0);
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) return;
  return { year, month, day, ordinal: date.getTime() / dayMs };
}

function dateKey(ordinal: number): string {
  return new Date(ordinal * dayMs).toISOString().slice(0, 10);
}

function weekday(ordinal: number): number {
  return ((ordinal + 3) % 7 + 7) % 7 + 1;
}

/** Shared with the browser adapter so invalid imported/input rules cannot loop. */
export function validRecurrence(value: unknown): value is Recurrence {
  if (!value || typeof value !== "object") return false;
  const rule = value as Recurrence;
  return ["daily", "weekly", "monthly", "yearly"].includes(rule.frequency)
    && Number.isInteger(rule.interval) && rule.interval >= 1 && rule.interval <= 999
    && (rule.weekdays == null || (rule.frequency === "weekly" && Array.isArray(rule.weekdays)
      && rule.weekdays.length > 0 && rule.weekdays.length <= 7
      && rule.weekdays.every(day => Number.isInteger(day) && day >= 1 && day <= 7)
      && new Set(rule.weekdays).size === rule.weekdays.length))
    && (rule.until == null || !!parseDate(rule.until))
    && (rule.count == null || (Number.isInteger(rule.count) && rule.count >= 1 && rule.count <= 10_000))
    && !(rule.until != null && rule.count != null);
}

export function validDate(value: string): boolean {
  return !!parseDate(value);
}

/** Seek by periods. Only bounded month/year counts need to inspect prior periods. */
function* plannedDates(item: CalendarItem, start: string, end: string): Generator<string> {
  const anchor = parseDate(item.date), lower = parseDate(start), upper = parseDate(end), rule = item.recurrence;
  if (!anchor || !lower || !upper || !validRecurrence(rule) || start > end || end < item.date) return;
  const last = rule.until && rule.until < end ? rule.until : end;
  if (last < start || last < item.date) return;
  const maxOrdinal = parseDate(last)!.ordinal;
  if (rule.frequency === "daily") {
    const first = Math.max(0, Math.ceil((lower.ordinal - anchor.ordinal) / rule.interval));
    const final = Math.min(Math.floor((maxOrdinal - anchor.ordinal) / rule.interval), (rule.count ?? Infinity) - 1);
    for (let index = first; index <= final; index++) yield dateKey(anchor.ordinal + index * rule.interval);
    return;
  }
  if (rule.frequency === "weekly") {
    const days = [...(rule.weekdays ?? [weekday(anchor.ordinal)])].sort((a, b) => a - b);
    const week = anchor.ordinal - weekday(anchor.ordinal) + 1;
    const initial = days.filter(day => week + day - 1 >= anchor.ordinal);
    const period = rule.interval * 7;
    const first = Math.max(0, Math.floor((lower.ordinal - week) / period));
    for (let cycle = first; week + cycle * period <= maxOrdinal; cycle++) {
      const scheduled = cycle === 0 ? initial : days;
      for (let index = 0; index < scheduled.length; index++) {
        const sequence = cycle === 0 ? index + 1 : initial.length + (cycle - 1) * days.length + index + 1;
        if (rule.count != null && sequence > rule.count) return;
        const ordinal = week + cycle * period + scheduled[index] - 1;
        if (ordinal >= lower.ordinal && ordinal <= maxOrdinal) yield dateKey(ordinal);
      }
    }
    return;
  }
  const monthly = rule.frequency === "monthly";
  const anchorPeriod = monthly ? anchor.year * 12 + anchor.month - 1 : anchor.year;
  const lowerPeriod = monthly ? lower.year * 12 + lower.month - 1 : lower.year;
  const upperDate = parseDate(last)!;
  const finalPeriod = monthly ? upperDate.year * 12 + upperDate.month - 1 : upperDate.year;
  const first = rule.count == null ? Math.max(0, Math.floor((lowerPeriod - anchorPeriod) / rule.interval)) : 0;
  let sequence = 0;
  for (let cycle = first; anchorPeriod + cycle * rule.interval <= finalPeriod; cycle++) {
    const period = anchorPeriod + cycle * rule.interval;
    const year = monthly ? Math.floor(period / 12) : period;
    const month = monthly ? period % 12 + 1 : anchor.month;
    const nominal = `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(anchor.day).padStart(2, "0")}`;
    if (!parseDate(nominal)) continue;
    sequence++;
    if (rule.count != null && sequence > rule.count) return;
    if (nominal >= start && nominal <= last) yield nominal;
  }
}

export function occurrenceForDate(item: CalendarItem, nominalDate: string): CalendarItem | undefined {
  if (!validDate(nominalDate) || !plannedDates(item, nominalDate, nominalDate).next().value) return;
  return materialize(item, nominalDate);
}

function materialize(item: CalendarItem, nominalDate: string): CalendarItem | undefined {
  const exception = item.exceptions?.[nominalDate];
  if (exception?.deleted) return;
  const input = exception?.input;
  if (input && !validDate(input.date)) return;
  return {
    ...item,
    date: nominalDate,
    ...input,
    completed: exception?.completed ?? input?.completed ?? item.completed,
    recurrence: item.recurrence,
    id: `${item.id}@${nominalDate}`,
    seriesId: item.id,
    occurrenceDate: nominalDate,
  };
}

export function expandItems(items: CalendarItem[], start: string, end: string): CalendarItem[] {
  if (!validDate(start) || !validDate(end) || start > end) return [];
  const result: CalendarItem[] = [];
  for (const item of items) {
    if (!validRecurrence(item.recurrence)) {
      if (item.date >= start && item.date <= end) result.push(item);
      continue;
    }
    const nominalDates = new Set(plannedDates(item, start, end));
    for (const nominal of nominalDates) {
      const occurrence = materialize(item, nominal);
      if (occurrence && occurrence.date >= start && occurrence.date <= end) result.push(occurrence);
    }
    for (const [nominal, exception] of Object.entries(item.exceptions ?? {})) {
      if (nominalDates.has(nominal) || !exception.input || exception.input.date < start || exception.input.date > end) continue;
      const occurrence = occurrenceForDate(item, nominal);
      if (occurrence && occurrence.date >= start && occurrence.date <= end) result.push(occurrence);
    }
  }
  return result.sort((a, b) => a.date.localeCompare(b.date) || (a.time ?? "").localeCompare(b.time ?? "") || a.id.localeCompare(b.id));
}

/** Search bounded, growing windows; sparse rules do not require daily iteration. */
export function nextOccurrence(item: CalendarItem, fromDate: string): CalendarItem | undefined {
  const from = parseDate(fromDate);
  if (!from) return;
  if (!validRecurrence(item.recurrence)) return !item.completed && item.date >= fromDate ? item : undefined;
  // Old/imported completed series can only have open instances through overrides.
  if (item.completed) {
    return Object.keys(item.exceptions ?? {})
      .map(nominal => occurrenceForDate(item, nominal))
      .filter((value): value is CalendarItem => !!value && !value.completed && value.date >= fromDate)
      .sort((a, b) => a.date.localeCompare(b.date) || (a.time ?? "").localeCompare(b.time ?? ""))[0];
  }
  const maximum = parseDate("9999-12-31")!.ordinal;
  let start = from.ordinal, width = 31;
  while (start <= maximum) {
    const end = Math.min(maximum, start + width - 1);
    const candidate = expandItems([item], dateKey(start), dateKey(end)).find(value => !value.completed);
    if (candidate) return candidate;
    start = end + 1;
    width *= 2;
  }
}
