import { t } from '../i18n.ts';
import { dateLabel, localDateKey, sortItems } from "../calendar.ts";
import type { CalendarItem } from "../model.ts";
import { el, icon, iconButton, button } from "./dom.ts";
import { recurrenceText } from "./recurrence-fields.ts";
export function agendaView(
  date: string,
  items: CalendarItem[],
  toggle: (item: CalendarItem) => void,
  edit: (item: CalendarItem) => void,
  remove: (item: CalendarItem) => void,
  today = localDateKey(new Date()),
): HTMLElement {
  const section = el("section", "agenda");
  section.setAttribute("aria-label", t("每日安排"));
  const selected = sortItems(items.filter((x) => x.date === date));
  const heading = el("div", "agenda-heading");
  heading.append(
    el(
      "h2",
      "",
      `${date === today ? t("今天 · ") : ""}${dateLabel(date)}`,
    ),
    el("span", "count", t('{count} 项', {count:selected.length})),
  );
  const list = el("div", "agenda-list");
  if (!selected.length) {
    const empty = el("div", "empty-state");
    empty.append(
      icon("calendar"),
      el("p", "", t("这一天，留给新的安排")),
      el("span", "", t("记下一件小事，让日子从容一点")),
    );
    list.append(empty);
  }
  let hadUntimed = false;
  for (const item of selected) {
    if (!item.time && !item.completed && !hadUntimed) {
      list.append(el("div", "list-label", t("无时间安排")));
      hadUntimed = true;
    }
    const row = el(
      "article",
      `agenda-row ${item.kind ?? "event"}${item.completed ? " completed" : ""}${item.external?' external':''}`,
    );
    const check = iconButton(
      "check",
      t(item.completed ? '取消完成 {title}' : '完成 {title}', {title:item.title}),
      () => toggle(item),
    );
    check.classList.add("completion-button");
    if (!item.completed) check.replaceChildren();
    const marker = el("span", "note-marker");
    marker.append(icon("note"));
    const content = button("", "item-content", () => edit(item));
    const line = el("span", "item-title-line");
    if (item.time) line.append(el("span", "item-time", item.time));
    line.append(el("span", "item-title", item.title));
    if (item.kind === "note" || item.kind === "task")
      line.append(el("span", "item-kind", item.kind === "note" ? t("备忘") : t("待办")));
    content.append(line);
    if(item.external){
      row.style.setProperty('--source-color',item.external.color);
      if(item.time&&item.endTime)content.append(el('span','item-detail',t('至 {time}', {time:item.endTime})));
      content.append(el('span','item-detail source-caption',`${item.external.sourceName}${item.external.allDay?` · ${t('全天')}`:''}${item.external.location?` · ${item.external.location}`:''}`));
      row.append(marker,content);list.append(row);continue;
    }
    if (item.recurrence) {
      const repeat = el("span", "item-detail repeat-badge", recurrenceText(item.recurrence));
      repeat.prepend(icon("repeat"));
      content.append(repeat);
    }
    if (item.time && item.endTime)
      content.append(el("span", "item-detail", t('至 {time}', {time:item.endTime})));
    if (item.notes || item.reminderMinutes !== null)
      content.append(
        el(
          "span",
          "item-detail",
          item.notes ||
            (item.reminderMinutes === 0
              ? t("准时提醒")
              : t('提前 {minutes} 分钟提醒', {minutes:item.reminderMinutes!})),
        ),
      );
    const actions = el("div", "item-actions");
    actions.append(
      iconButton("edit", t('编辑 {title}', {title:item.title}), () => edit(item)),
      iconButton("trash", t('删除 {title}', {title:item.title}), () => remove(item)),
    );
    row.append(item.kind === "note" ? marker : check, content, actions);
    list.append(row);
  }
  section.append(heading, list);
  return section;
}
