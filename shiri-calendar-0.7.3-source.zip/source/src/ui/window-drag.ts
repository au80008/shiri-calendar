import { t } from '../i18n.ts';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { desktop } from '../bridge.ts';

/** Keep header controls clickable while the rest of the header moves the window. */
export function enableWindowDrag(region: HTMLElement, onError: (error: unknown) => void = console.error): void {
  region.classList.add('window-drag-region');
  region.title = t('按住鼠标左键拖动窗口');
  region.addEventListener('mousedown', event => {
    if (document.documentElement.classList.contains('window-fullscreen')) return;
    if (!desktop || event.button !== 0 || event.defaultPrevented) return;
    const target = event.target;
    if (!(target instanceof Element) || target.closest('button, input, textarea, select, a, [contenteditable], [role="button"], [data-no-window-drag]')) return;
    event.preventDefault();
    void getCurrentWindow().startDragging().catch(onError);
  });
}
