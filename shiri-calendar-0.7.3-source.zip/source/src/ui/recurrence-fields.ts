import { t, getLanguage } from '../i18n.ts';
import type { Recurrence } from "../model.ts";
import { el } from "./dom.ts";
import { temporalControl, normalizeTemporal } from './temporal-control.ts';
import { validDate } from '../recurrence.ts';

const weekdayNames = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"];
export interface RecurrenceDraft {
  mode: string; frequency: string; interval: string; weekdays: number[];
  ending: string; until: string; count: string; weekdaysTouched: boolean; untilTouched: boolean;
}
const isoDay = (date: string) => ((new Date(`${date}T12:00:00`).getDay() + 6) % 7) + 1;
export function recurrenceText(rule: Recurrence): string {
  const units = { daily: "天", weekly: "周", monthly: "月", yearly: "年" };
  const days = rule.frequency === "weekly" && rule.weekdays?.length
    ? ` · ${rule.weekdays.map(d => t(weekdayNames[d - 1])).join(getLanguage() === 'en' ? ', ' : '、')}` : "";
  const unit = { daily: 'day', weekly: 'week', monthly: 'month', yearly: 'year' }[rule.frequency];
  const prefix = getLanguage() === 'en'
    ? `Every ${rule.interval === 1 ? '' : `${rule.interval} `}${unit}${rule.interval === 1 ? '' : 's'}`
    : `每${rule.interval === 1 ? "" : rule.interval}${units[rule.frequency]}`;
  return `${prefix}${days}${rule.until ? t(' · 截止 {date}', {date:rule.until}) : rule.count ? t(' · 共 {count} 次', {count:rule.count}) : ""}`;
}
export function recurrenceFields(initial: Recurrence | null | undefined, getDate: () => string, draft?: RecurrenceDraft) {
  const element = el("div", "recurrence-fields");
  function field(label: string, control: HTMLSelectElement | HTMLInputElement) {
    const wrapper = el("label", "field");
    control.setAttribute("aria-label", label);
    wrapper.append(el("span", "field-label", label), control);
    return wrapper;
  }
  function select(options: [string, string][]) {
    const control = el("select");
    for (const [value, text] of options) {
      const option = el("option", "", text); option.value = value; control.append(option);
    }
    return control;
  }
  const mode = select([["none", t("不重复")], ["daily", t("每天")], ["workdays", t("工作日（周一至周五）")], ["weekly", t("每周")], ["monthly", t("每月")], ["yearly", t("每年")], ["custom", t("自定义")]]);
  const weekdays = draft?.weekdays ?? initial?.weekdays ?? [isoDay(getDate())];
  const workdays = initial?.frequency === "weekly" && initial.interval === 1 && weekdays.length === 5 && [1,2,3,4,5].every(d => weekdays.includes(d));
  mode.value = draft?.mode ?? (!initial ? "none" : initial.interval !== 1 ? "custom" : workdays ? "workdays" : initial.frequency);
  const custom = el("div", "time-fields recurrence-custom");
  const interval = el("input"); interval.type = "number"; interval.min = "1"; interval.max = "999"; interval.step = "1"; interval.value = draft?.interval ?? String(initial?.interval ?? 1);
  const frequency = select([["daily", t("天")], ["weekly", t("周")], ["monthly", t("月")], ["yearly", t("年")]]);
  frequency.value = draft?.frequency ?? initial?.frequency ?? "daily";
  custom.append(field(t("重复间隔"), interval), field(t("重复单位"), frequency));
  const week = el("fieldset", "recurrence-weekdays");
  week.append(el("legend", "field-label", t("每周重复于")));
  const dayControls = weekdayNames.map((name, index) => {
    const label = el("label", "weekday-option");
    const input = el("input"); input.type = "checkbox"; input.setAttribute("aria-label", t(name)); input.checked = weekdays.includes(index + 1);
    label.append(input, el("span", "", t(name))); week.append(label); return input;
  });
  let weekdaysTouched = draft?.weekdaysTouched ?? false;
  week.addEventListener("input", () => { weekdaysTouched = true; });
  const ending = select([["never", t("一直重复")], ["until", t("指定日期结束")], ["count", t("重复若干次")]]);
  ending.value = draft?.ending ?? (initial?.until ? "until" : initial?.count ? "count" : "never");
  const until = el("input"); until.value = draft?.until ?? initial?.until ?? getDate();
  let untilTouched = draft?.untilTouched ?? false;
  until.addEventListener("input", () => { untilTouched = true; });
  const count = el("input"); count.type = "number"; count.min = "1"; count.max = "10000"; count.step = "1"; count.value = draft?.count ?? String(initial?.count ?? 10);
  const endingField = field(t("结束重复"), ending), untilField = field(t("重复截止日期"), until), countField = field(t("重复次数"), count);
  temporalControl(until, 'date', t('截止日期选择器'), t('选择重复截止日期'));
  const details = el("div", "recurrence-details");
  details.append(custom, week, endingField, untilField, countField);
  const hint = el("p", "field-hint recurrence-hint");
  element.append(field(t("重复"), mode), details, hint);
  const currentFrequency = () => mode.value === "workdays" ? "weekly" : mode.value === "custom" ? frequency.value : mode.value;
  function update() {
    details.hidden = mode.value === "none";
    custom.hidden = mode.value !== "custom";
    interval.disabled = custom.hidden; frequency.disabled = custom.hidden;
    week.hidden = currentFrequency() !== "weekly" || mode.value === "workdays";
    for (const input of dayControls) input.disabled = week.hidden;
    untilField.hidden = ending.value !== "until";
    countField.hidden = ending.value !== "count";
    ending.disabled = details.hidden;
    until.disabled = details.hidden || untilField.hidden;
    count.disabled = details.hidden || countField.hidden;
    hint.textContent = mode.value === "workdays" ? t("周一至周五重复，节日也包含在内。") : currentFrequency() === "monthly" ? t("每月同一天；没有该日期的月份会跳过。") : currentFrequency() === "yearly" ? t("每年同一天；2 月 29 日只在闰年出现。") : "";
    hint.hidden = mode.value === "none" || !hint.textContent;
  }
  mode.addEventListener("change", update); frequency.addEventListener("change", update); ending.addEventListener("change", update);
  update();
  const read = (): Recurrence | null => mode.value === "none" ? null : {
    frequency: currentFrequency() as Recurrence["frequency"],
    interval: mode.value === "custom" ? Number(interval.value) : 1,
    ...(currentFrequency() === "weekly" ? { weekdays: mode.value === "workdays" ? [1,2,3,4,5] : dayControls.flatMap((input, i) => input.checked ? [i + 1] : []) } : {}),
    until: ending.value === "until" ? normalizeTemporal(until.value, 'date') || null : null,
    count: ending.value === "count" ? Number(count.value) : null,
  };
  return {
    element, read,
    state: (): RecurrenceDraft => ({
      mode: mode.value, frequency: frequency.value, interval: interval.value,
      weekdays: dayControls.flatMap((input, i) => input.checked ? [i + 1] : []),
      ending: ending.value, until: until.value, count: count.value, weekdaysTouched, untilTouched,
    }),
    updateAnchor() {
      if (!weekdaysTouched && !initial?.weekdays?.length) dayControls.forEach((input, i) => { input.checked = isoDay(getDate()) === i + 1; });
      if (!untilTouched && !initial?.until) until.value = getDate();
    },
    error() {
      const rule = read(); if (!rule) return "";
      if (!Number.isInteger(rule.interval) || rule.interval < 1 || rule.interval > 999) return t("重复间隔需为 1–999 的整数");
      if (rule.frequency === "weekly" && !rule.weekdays?.length) return t("请至少选择一个星期");
      if (ending.value === "until" && !rule.until) return t("请选择重复截止日期");
      if (rule.until && !validDate(rule.until)) return t('请选择有效的重复截止日期');
      if (rule.until && rule.until < getDate()) return t("截止日期不能早于开始日期");
      if (ending.value === "count" && (!Number.isInteger(rule.count) || rule.count! < 1 || rule.count! > 10000)) return t("重复次数需为 1–10000 的整数");
      return "";
    },
  };
}
