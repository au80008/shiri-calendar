import {clockInZone} from '../clock.ts';
import { clockTime, layoutDay, shiftDate, weekDates } from "../timetable.ts";
import type { CalendarItem } from "../model.ts";
import { button, el, icon } from "./dom.ts";
import { recurrenceText } from "./recurrence-fields.ts";
import { holidaysForDate } from "../holidays.ts";
import type { AddContext } from "./add-view.ts";
import {calendarToolbar} from './calendar-toolbar.ts';
import {formatDate,t} from '../i18n.ts';
import {enableCalendarDrag} from './calendar-drag.ts';
import type {DragChange} from '../event-drag.ts';

export function timetableView(
  selected: string,
  items: CalendarItem[],
  chooseDate: (date: string) => void,
  edit: (item: CalendarItem) => void,
  scrollTop: number | undefined,
  onScroll: (value: number) => void,
  add: (context: AddContext, x: number, y: number) => void,
  options:{zone?:string|null;onManageCalendars?:()=>void;onItemMenu?:(item:CalendarItem,x:number,y:number)=>void;onChangeView?:(view:'week'|'month'|'year')=>void;canDrag?:()=>boolean;onReschedule?:(item:CalendarItem,change:DragChange)=>void;onCreateRange?:(date:string,time:string,endTime:string)=>void}={},
): HTMLElement {
  const section = el("section", "timetable");
  section.dataset.selectedDate=selected;
  section.setAttribute("role", "region");
  section.setAttribute("aria-label", t("周时间表"));
  const byId=new Map(items.map(item=>[item.id,item]));
  section.addEventListener("contextmenu", e => {
    e.preventDefault();
    const card=(e.target as Element).closest<HTMLElement>('[data-item-id]');
    const item=card&&byId.get(card.dataset.itemId!);
    if(item&&options.onItemMenu){options.onItemMenu(item,e.clientX,e.clientY);return;}
    const target = (e.target as Element).closest<HTMLElement>("[data-date]");
    const day = target?.dataset.date ?? section.dataset.selectedDate!;
    const column = (e.target as Element).closest<HTMLElement>(".time-day");
    const minute = column ? Math.max(0, Math.min(1425,
      Math.floor((e.clientY - column.getBoundingClientRect().top) / 52 * 60 / 15) * 15)) : null;
    add({ date: day, time: minute === null ? null : clockTime(minute) }, e.clientX, e.clientY);
  });
  const days = weekDates(selected), now = new Date(), clock=clockInZone(now,options.zone??null), today=clock.date;
  const label = (day: string) => formatDate(day);
  const toolbar=calendarToolbar({view:'week',title:t('周时间表'),subtitle:t('{year}年 · {start} — {end}',{year:days[0].slice(0,4),start:label(days[0]),end:label(days[6])}),
    navigate:delta=>chooseDate(shiftDate(section.dataset.selectedDate!,delta*7)),today:()=>chooseDate(today),manageCalendars:options.onManageCalendars,changeView:options.onChangeView});
  const xscroll = el("div", "timetable-xscroll"), sheet = el("div", "timetable-sheet");
  const header = el("div", "week-header timetable-columns");
  header.append(el("span", "zone-label", t("本地时间")));
  const names = [t("周一"), t("周二"), t("周三"), t("周四"), t("周五"), t("周六"), t("周日")];
  for (const [i, day] of days.entries()) {
    const dayButton = button("", `week-day${day === today ? " is-today" : ""}${day === selected ? " selected" : ""}`, () => chooseDate(day));
    dayButton.setAttribute("aria-label", t('查看 {date}',{date:day}));
    dayButton.dataset.date = day;
    if (day === selected) dayButton.setAttribute("aria-current", "date");
    dayButton.append(el("span", "", names[i]), el("strong", "", String(Number(day.slice(8)))));
    header.append(dayButton);
  }
  const holidays = el("div", "holiday-row timetable-columns");
  holidays.setAttribute("aria-label", t("丹麦和中国节日"));
  const holidayLabel = el("span", "untimed-label", t("节日"));
  holidayLabel.title = t("丹麦与中国的节日日期");
  holidays.append(holidayLabel);
  for (const day of days) {
    const cell = el("div", "holiday-cell");
    cell.dataset.date = day;
    for (const holiday of holidaysForDate(day)) {
      const label = `${t(holiday.country === "CN" ? "中国" : "丹麦")} · ${t(holiday.name)}`;
      const badge = el("span", `holiday-badge ${holiday.country.toLowerCase()}`, label);
      badge.title = `${day} ${label}${holiday.localName ? ` / ${holiday.localName}` : ""}`;
      cell.append(badge);
    }
    holidays.append(cell);
  }
  const untimed = el("div", "untimed-row timetable-columns");
  untimed.append(el("span", "untimed-label", t("记录")));
  for (const day of days) {
    const cell = el("div", "untimed-cell");
    cell.dataset.date = day;
    for (const item of items.filter(x => x.date === day && !x.time)) {
      const kind = item.kind ?? "event";
      const prefix=item.external?.allDay?t('全天'):kind==='note'?t('备忘'):kind==='task'?t('待办'):'';
      const task = button(`${prefix?prefix+' · ':''}${item.title}`, `untimed-event ${kind}${item.completed ? " completed" : ""}${item.external?' external':''}`, () => edit(item));
      task.dataset.itemId=item.id;
      if(item.external){task.style.setProperty('--source-color',item.external.color);task.title=`${item.external.sourceName} · ${item.title}`;}
      task.title = `${item.completed ? t("已完成 · ") : ""}${item.title}`;
      if (item.recurrence) {
        task.prepend(icon("repeat"));
        task.title += `\n${recurrenceText(item.recurrence)}`;
      }
      cell.append(task);
    }
    untimed.append(cell);
  }
  const scroller = el("div", "time-scroll");
  scroller.tabIndex = 0;
  scroller.setAttribute("aria-label", t("按小时浏览周日程"));
  const grid = el("div", "hour-grid timetable-columns");
  const axis = el("div", "hour-axis");
  for (let hour = 0; hour < 24; hour++) {
    const tick = el("span", "hour-label", `${hour.toString().padStart(2, "0")}:00`);
    tick.style.top = `${hour * 52}px`;
    axis.append(tick);
  }
  grid.append(axis);
  for (const day of days) {
    const column = el("div", `time-day${day === today ? " is-today" : ""}`);
    column.dataset.date = day;
    for (const block of layoutDay(items.filter(x => x.date === day))) {
      const time = `${block.item.time}–${clockTime(block.end)}`;
      const event = button("", `timetable-event ${block.item.kind ?? "event"}${block.item.completed ? " completed" : ""}${block.item.external?' external':''}`, () => edit(block.item));
      event.dataset.itemId=block.item.id;
      event.setAttribute("aria-label", t(block.item.external?'查看 {title}，{date} {time}':'编辑 {title}，{date} {time}',{title:block.item.title,date:day,time}));
      if(block.item.external)event.style.setProperty('--source-color',block.item.external.color);
      event.title = `${block.item.title}\n${time}${block.item.completed ? t(" · 已完成") : ""}${block.item.notes ? `\n${block.item.notes}` : ""}`;
      event.style.top = `${block.start / 60 * 52}px`;
      event.style.height = `${Math.max(4, (block.end - block.start) / 60 * 52 - 2)}px`;
      event.style.left = `calc(${block.column / block.columns * 100}% + 3px)`;
      event.style.width = `calc(${100 / block.columns}% - 6px)`;
      event.append(el("span", "event-name", block.item.title), el("span", "event-time", time));
      if(!block.item.external?.continuesAfter){const handle=el('span','event-resize-handle');handle.title=t('拖动调整结束时间');event.append(handle);}
      if (block.item.recurrence) {
        const repeat = icon("repeat"); repeat.classList.add("event-repeat"); event.append(repeat);
        event.title += `\n${recurrenceText(block.item.recurrence)}`;
      }
      column.append(event);
    }
    if (day === today) {
      const line = el("div", "current-time-line");
      const time = clock.hour * 60 + clock.minute;
      line.style.top = `${time / 60 * 52}px`;
      line.title = t('现在 {time}',{time:clockTime(time)});
      column.append(line);
    }
    grid.append(column);
  }
  scroller.append(grid);
  scroller.addEventListener("scroll", () => onScroll(scroller.scrollTop), { passive: true });
  sheet.append(header, holidays, untimed, scroller);
  xscroll.append(sheet);
  section.append(toolbar, xscroll, el("footer", "timetable-footer", t("点击内容编辑 · 右键添加 · 节日：丹麦 / 中国")));
  if(options.onReschedule)enableCalendarDrag(section,items,{kind:'week',allowed:options.canDrag??(()=>true),commit:options.onReschedule,create:options.onCreateRange});
  requestAnimationFrame(() => {
    if (!scroller.isConnected || scroller.dataset.scrollReady) return;
    // Leave room for the complete 07:00 label; earlier hours remain scrollable.
    scroller.scrollTop = scrollTop ?? 7 * 52 - 10;
    scroller.dataset.scrollReady='true';
  });
  return section;
}
