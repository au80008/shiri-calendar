import { t, formatMonth, weekdayLabels } from '../i18n.ts';
import { buildMonthGrid, localDateKey, shiftMonth } from '../calendar.ts';
import { validDate } from '../recurrence.ts';
import { button, el, icon, iconButton } from './dom.ts';

type Kind = 'date' | 'time';
const pad = (value: number) => String(value).padStart(2, '0');
let nextId = 0;
export const validTime = (value: string) => /^([01]\d|2[0-3]):[0-5]\d$/.test(value);

export function normalizeTemporal(value: string, kind: Kind): string {
  const text = value.trim();
  if (kind === 'date') {
    const match = /^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/.exec(text);
    const date = match ? `${match[1]}-${pad(Number(match[2]))}-${pad(Number(match[3]))}` : text;
    return validDate(date) ? date : text;
  }
  const match = /^(\d{1,2})[:：](\d{1,2})$/.exec(text);
  const time = match ? `${pad(Number(match[1]))}:${pad(Number(match[2]))}`
    : /^\d{3,4}$/.test(text) ? `${text.slice(0, -2).padStart(2, '0')}:${text.slice(-2)}` : text;
  return validTime(time) ? time : text;
}

/** Keep editable text and its caret separate from the optional picker surface. */
export function temporalControl(input: HTMLInputElement, kind: Kind, title: string, triggerLabel: string): void {
  input.type = 'text';
  input.inputMode = kind === 'time' ? 'decimal' : 'text';
  input.autocomplete = 'off';
  input.spellcheck = false;
  input.placeholder = kind === 'date' ? 'YYYY-MM-DD' : 'HH:mm';
  input.classList.add('temporal-input');
  const wrapper = el('div', 'temporal-control');
  input.replaceWith(wrapper);
  const panel = el('div', `form-picker ${kind}-picker`);
  panel.id = `form-picker-${++nextId}`;
  panel.setAttribute('popover', 'auto');
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-label', title);
  const trigger = iconButton(kind === 'date' ? 'calendar' : 'clock', triggerLabel, () => {});
  trigger.className = 'temporal-trigger';
  trigger.setAttribute('popovertarget', panel.id);
  trigger.setAttribute('aria-haspopup', 'dialog');
  trigger.setAttribute('aria-expanded', 'false');
  trigger.setAttribute('aria-controls', panel.id);
  wrapper.append(input, trigger, panel);

  const close = () => {
    if (panel.matches(':popover-open')) panel.hidePopover();
    input.focus({ preventScroll: true });
    input.setSelectionRange(input.value.length, input.value.length);
  };
  const commit = (value: string) => {
    input.value = value;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    close();
  };
  input.addEventListener('blur', () => {
    const value = normalizeTemporal(input.value, kind);
    if (value !== input.value) {
      input.value = value;
      input.dispatchEvent(new Event('input', { bubbles: true }));
    }
  });
  input.addEventListener('keydown', event => {
    if ((event.altKey && event.key === 'ArrowDown') || event.key === 'F4') {
      event.preventDefault(); trigger.click();
    }
  });
  let scrollController: AbortController | undefined;
  const position = () => {
    if (!panel.matches(':popover-open')) return;
    const anchor = wrapper.getBoundingClientRect(), box = panel.getBoundingClientRect();
    const below = innerHeight - anchor.bottom - 8, above = anchor.top - 8;
    const preferred = below >= box.height || below >= above ? anchor.bottom + 6 : anchor.top - box.height - 6;
    panel.style.left = `${Math.max(8, Math.min(anchor.left, innerWidth - box.width - 8))}px`;
    panel.style.top = `${Math.max(8, Math.min(preferred, innerHeight - box.height - 8))}px`;
  };
  panel.addEventListener('beforetoggle', event => {
    if ((event as ToggleEvent).newState !== 'open') return;
    if (input.disabled) { event.preventDefault(); return; }
    panel.style.visibility = 'hidden';
    if (kind === 'date') renderDate(); else renderTime();
    requestAnimationFrame(() => {
      if (!panel.matches(':popover-open')) return;
      position();
      panel.style.visibility = 'visible';
      panel.querySelector<HTMLElement>('[tabindex="0"]')?.focus({ preventScroll: true });
      for (const list of panel.querySelectorAll<HTMLElement>('.time-picker-list')) {
        const selected = list.querySelector<HTMLElement>('[aria-pressed="true"]');
        if (selected) list.scrollTop = selected.offsetTop - list.clientHeight / 2 + selected.clientHeight / 2;
      }
    });
    scrollController?.abort();
    scrollController = new AbortController();
    const form = input.closest('form');
    form?.addEventListener('scroll', () => {
      const anchor = wrapper.getBoundingClientRect(), viewport = form.getBoundingClientRect();
      if (anchor.bottom < viewport.top || anchor.top > viewport.bottom) {
        if (panel.matches(':popover-open')) panel.hidePopover();
      } else position();
    }, { signal: scrollController.signal });
  });
  panel.addEventListener('toggle', event => {
    const open = (event as ToggleEvent).newState === 'open';
    trigger.setAttribute('aria-expanded', String(open));
    if (!open) scrollController?.abort();
  });

  function renderDate() {
    const selected = normalizeTemporal(input.value, 'date');
    const anchor = validDate(selected) ? selected : localDateKey(new Date());
    let year = Number(anchor.slice(0, 4)), month = Number(anchor.slice(5, 7)) - 1;
    let focused = anchor;
    function render() {
      panel.replaceChildren();
      const head = el('div', 'picker-heading');
      const prev = iconButton('left', t('上个月'), () => moveMonth(-1));
      const next = iconButton('right', t('下个月'), () => moveMonth(1));
      prev.disabled = year === 1900 && month === 0;
      next.disabled = year === 9999 && month === 11;
      head.append(prev, el('strong', '', formatMonth(year, month)), next);
      const week = el('div', 'picker-weekdays');
      for (const day of weekdayLabels()) week.append(el('span', '', day));
      const grid = el('div', 'picker-dates');
      const keys = buildMonthGrid(year, month), today = localDateKey(new Date());
      const tabDate = keys.includes(focused) ? focused : keys.find(key => key.slice(5, 7) === pad(month + 1))!;
      for (const key of keys) {
        const control = button(String(Number(key.slice(8))), 'picker-date', () => commit(key));
        control.setAttribute('aria-label', key);
        control.setAttribute('aria-pressed', String(key === selected));
        control.dataset.date = key;
        control.tabIndex = key === tabDate ? 0 : -1;
        control.disabled = !validDate(key);
        control.classList.toggle('outside', Number(key.slice(5, 7)) !== month + 1);
        if (key === today) control.setAttribute('aria-current', 'date');
        grid.append(control);
      }
      grid.addEventListener('keydown', event => {
        const key = (event.target as HTMLElement).dataset.date;
        if (!key || !validDate(key)) return;
        const date = new Date(`${key}T12:00:00`), weekday = (date.getDay() + 6) % 7;
        const delta: Record<string, number> = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7, Home: -weekday, End: 6 - weekday };
        if (event.key in delta) date.setDate(date.getDate() + delta[event.key]);
        else if (event.key === 'PageUp' || event.key === 'PageDown') {
          const day = date.getDate(); date.setDate(1);
          date.setMonth(date.getMonth() + (event.key === 'PageUp' ? -1 : 1));
          date.setDate(Math.min(day, new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate()));
        } else return;
        event.preventDefault();
        focused = localDateKey(date);
        if (!validDate(focused)) return;
        year = date.getFullYear(); month = date.getMonth(); render();
        panel.querySelector<HTMLElement>(`[data-date="${focused}"]`)?.focus({ preventScroll: true });
      });
      const footer = el('div', 'picker-actions');
      footer.append(button(t('今天'), 'picker-action', () => commit(localDateKey(new Date()))), button(t('关闭'), 'picker-action', close));
      panel.append(head, week, grid, footer);
    }
    function moveMonth(delta: number) {
      ({ year, month } = shiftMonth(year, month, delta)); render();
      panel.querySelector<HTMLElement>('[tabindex="0"]')?.focus({ preventScroll: true });
    }
    render();
  }

  function renderTime() {
    const value = normalizeTemporal(input.value, 'time'), now = new Date();
    let hour = validTime(value) ? Number(value.slice(0, 2)) : now.getHours();
    let minute = validTime(value) ? Number(value.slice(3)) : now.getMinutes();
    panel.replaceChildren();
    const head = el('div', 'picker-heading');
    const preview = el('strong', 'time-picker-preview');
    const updatePreview = () => { preview.textContent = `${pad(hour)}:${pad(minute)}`; };
    updatePreview(); head.append(el('span', '', title.replace('选择器', '').replace(' picker', '')), preview);
    const columns = el('div', 'time-picker-columns');
    for (const [unit, count] of [['时', 24], ['分', 60]] as const) {
      const column = el('div', 'time-picker-column');
      column.append(el('span', 'picker-caption', unit === '时' ? t('小时') : t('分钟')));
      const list = el('div', 'time-picker-list');
      list.setAttribute('role', 'group'); list.setAttribute('aria-label', unit === '时' ? t('小时') : t('分钟'));
      const controls: HTMLButtonElement[] = [];
      for (let index = 0; index < count; index++) {
        const control = button(pad(index), 'picker-time', () => {
          if (unit === '时') hour = index; else minute = index;
          for (const [value, option] of controls.entries()) {
            const active = value === index;
            option.setAttribute('aria-pressed', String(active)); option.tabIndex = active ? 0 : -1;
          }
          updatePreview();
        });
        control.setAttribute('aria-label', t(unit === '时' ? '{value} 时' : '{value} 分', {value:index}));
        control.setAttribute('aria-pressed', String(index === (unit === '时' ? hour : minute)));
        control.tabIndex = index === (unit === '时' ? hour : minute) ? 0 : -1;
        controls.push(control); list.append(control);
      }
      list.addEventListener('keydown', event => {
        const current = controls.indexOf(document.activeElement as HTMLButtonElement);
        if (current < 0 || !['ArrowUp', 'ArrowDown', 'Home', 'End'].includes(event.key)) return;
        event.preventDefault();
        const index = event.key === 'Home' ? 0 : event.key === 'End' ? count - 1 : (current + (event.key === 'ArrowUp' ? -1 : 1) + count) % count;
        controls[index].click(); controls[index].focus();
      });
      column.append(list); columns.append(column);
    }
    const footer = el('div', 'picker-actions');
    footer.append(button(t('清空'), 'picker-action', () => commit('')), button(t('确定'), 'picker-action picker-confirm', () => commit(`${pad(hour)}:${pad(minute)}`)));
    panel.append(head, columns, footer);
  }
}
