import {clockInZone} from '../clock.ts';
import {clockTime} from '../timetable.ts';
import {t} from '../i18n.ts';

export function updateCalendarSelection(view:HTMLElement,selected:string){
  view.dataset.selectedDate=selected;
  for(const day of view.querySelectorAll<HTMLElement>('.day,.week-day,.overview-date,.overview-year-day,.overview-month-cell')){
    const active=(day.dataset.date??day.getAttribute('aria-label'))===selected;
    day.classList.toggle('selected',active);
    if(day.matches('button'))day.setAttribute('aria-pressed',String(active));
    if(day.matches('.week-day')){
      if(active)day.setAttribute('aria-current','date');else day.removeAttribute('aria-current');
    }
  }
}

export function updateCurrentTime(view:HTMLElement,zone:string|null){
  const clock=clockInZone(new Date(),zone),minute=clock.hour*60+clock.minute;
  const line=view.querySelector<HTMLElement>('.current-time-line');
  if(line){line.style.top=`${minute/60*52}px`;line.title=t('现在 {time}',{time:clockTime(minute)});}
}
