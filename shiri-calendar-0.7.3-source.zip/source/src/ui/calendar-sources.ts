import { t, translateError, getLanguage } from '../i18n.ts';
import type {AppSnapshot} from '../model.ts';
import {defaultView,type CalendarSourceSummary,type CalendarViewPrefs,type SourceInput,type PreviewResult} from '../subscriptions.ts';
import {button,el,iconButton} from './dom.ts';import {calendarField,timezoneSelect} from './calendar-fields.ts';import {subscriptionForm} from './subscription-form.ts';
export interface SourceActions {
 close:()=>void;link:(id:string)=>Promise<string>;inspect:(input:SourceInput)=>Promise<PreviewResult>;
 save:(id:string|null,input:SourceInput,ticket?:string)=>Promise<AppSnapshot>;remove:(id:string)=>Promise<AppSnapshot>;
 view:(prefs:CalendarViewPrefs)=>Promise<AppSnapshot>;
}
export function calendarSources(initial:AppSnapshot,actions:SourceActions):{element:HTMLElement;update:(snapshot:AppSnapshot)=>void}{
 const element=el('section','calendar-sources');let current=initial;let formOpen=false,busy=false,error='';
 function update(snapshot:AppSnapshot){current=snapshot;if(!formOpen)render();}
 async function act(run:()=>Promise<AppSnapshot>){if(busy){render();return;}busy=true;error='';try{current=await run();}catch(e){error=translateError(e);}finally{busy=false;if(!formOpen)render();}}
 function config(source:CalendarSourceSummary,url:string):SourceInput{return {name:source.name,url,color:source.color,visible:source.visible,fallbackZone:source.fallbackZone,overrideUnknownZone:source.overrideUnknownZone,reminderMinutes:source.reminderMinutes};}
 function openForm(source?:CalendarSourceSummary,url='',reimport=false){
  formOpen=true;element.replaceChildren(subscriptionForm(source?config(source,url):undefined,actions.inspect,async(input,ticket)=>{current=await actions.save(source?.id??null,input,ticket);formOpen=false;render();},()=>{formOpen=false;render();},source?()=>confirmRemove(source):undefined,reimport));
 }
 function confirmRemove(source:CalendarSourceSummary){
  const confirm=el('div','remove-source-confirm');confirm.setAttribute('role','alertdialog');confirm.setAttribute('aria-label',t('移除日历'));confirm.append(el('h2','',t('移除此日历？')),el('p','',t('{name} 的全部导入安排与本地修改将移除，其他个人安排会保留。', {name:source.name})));const row=el('div','form-actions');const cancel=button(t('保留'),'secondary-button',()=>openSource(source));const remove=button(t('确认移除'),'primary-button',async()=>{remove.disabled=true;cancel.disabled=true;try{current=await actions.remove(source.id);formOpen=false;render();}catch(e){remove.disabled=false;cancel.disabled=false;confirm.append(el('p','form-error',translateError(e)));}});row.append(cancel,remove);confirm.append(row);element.replaceChildren(confirm);cancel.focus();
 }
 async function openSource(source:CalendarSourceSummary){if(busy)return;busy=true;try{const url=await actions.link(source.id);openForm(source,url);}catch(e){error=translateError(e);render();}finally{busy=false;}}
 function render(){
  element.replaceChildren();const head=el('div','dialog-heading');head.append(el('strong','',t('我的日历')),iconButton('close',t('关闭日历管理'),actions.close));element.append(head,el('p','source-caption',t('已导入的本地日历，可编辑，不自动更新。')));
  if(error){const alert=el('p','form-error',error);alert.setAttribute('role','alert');element.append(alert);}
  const prefs=current.calendarView??defaultView;const local=el('label','source-local source-check');const localCheck=el('input');localCheck.type='checkbox';localCheck.checked=prefs.localVisible;localCheck.disabled=busy;localCheck.setAttribute('aria-label',t('显示 拾日'));localCheck.addEventListener('change',()=>void act(()=>actions.view({...prefs,localVisible:localCheck.checked})));local.append(localCheck,el('span','source-dot local-dot'),el('strong','',t('拾日')));element.append(local);
  const list=el('div','source-list');
  for(const source of current.calendarSources??[]){
   const row=el('article','source-row');row.dataset.sourceId=source.id;row.style.setProperty('--source-color',source.color);
   const label=el('label','source-check source-name');const check=el('input');check.type='checkbox';check.checked=source.visible;check.disabled=busy;check.setAttribute('aria-label',t('显示 {name}', {name:source.name}));check.addEventListener('change',()=>void act(async()=>actions.save(source.id,{...config(source,await actions.link(source.id)),visible:check.checked})));label.append(check,el('span','source-dot'),el('strong','truncate',source.name));
   const buttons=el('div','source-row-actions');const refresh=iconButton('repeat',t('重新导入 {name}', {name:source.name}),()=>openForm(source,'',true));refresh.disabled=busy;const manage=iconButton('edit',t('管理 {name}', {name:source.name}),()=>void openSource(source));manage.disabled=busy;buttons.append(refresh,manage);
   const status=el('span','source-status');status.textContent=source.lastSuccessAt?t('已导入 · {date}', {date:new Date(source.lastSuccessAt).toLocaleString(getLanguage(),{timeZone:prefs.displayZone??undefined,month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'})}):t('已保存在本地');
   row.append(label,buttons,el('span','source-host',source.host),status);list.append(row);
  }
  element.append(list,button(t('添加日历'),'primary-button add-source-button',()=>openForm()));
  const zone=timezoneSelect(prefs.displayZone,true);zone.disabled=busy;zone.addEventListener('change',()=>void act(()=>actions.view({...prefs,displayZone:zone.value==='system'?null:zone.value})));element.append(calendarField(t('显示时区'),zone),el('p','field-hint',t('导入后只在拾日编辑。需要重新同步时，点击重新导入并再次输入链接。')));
 }
 render();return {element,update};
}
