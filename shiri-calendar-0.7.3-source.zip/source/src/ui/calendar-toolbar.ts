import {t} from '../i18n.ts';
import {button,el,icon,iconButton} from './dom.ts';
import {enableWindowDrag} from './window-drag.ts';

type CalendarScale='week'|'month'|'year';
const views=[['week','周'],['month','月'],['year','年']] as const;
let nextId=0;

/** Shared controls keep their position and interaction in all three calendar views. */
export function calendarToolbar(options:{
 view:CalendarScale;title:string;subtitle:string;
 navigate:(delta:number)=>void;today:()=>void;
 manageCalendars?:()=>void;changeView?:(view:CalendarScale)=>void;
}):HTMLElement{
 const toolbar=el('header','timetable-toolbar calendar-toolbar');
 enableWindowDrag(toolbar);
 const title=el('div','timetable-title');
 title.append(el('h2','',options.title),el('span','',options.subtitle));
 const controls=el('div','month-controls calendar-toolbar-controls');
 if(options.manageCalendars)controls.append(button(t('日历'),'today-button',options.manageCalendars));
 if(options.changeView){
  const wrapper=el('div','calendar-view-control');
  const trigger=button(t(views.find(([value])=>value===options.view)![1]),'today-button calendar-view-trigger',()=>{});
  trigger.append(icon('down'));trigger.title=t('日历视图');
  trigger.setAttribute('aria-label',t('日历视图'));trigger.setAttribute('aria-haspopup','menu');
  trigger.setAttribute('aria-expanded','false');
  const menu=el('div','calendar-view-menu');menu.id=`calendar-view-menu-${++nextId}`;
  menu.setAttribute('popover','auto');menu.setAttribute('role','menu');menu.setAttribute('aria-label',t('日历视图'));
  trigger.setAttribute('popovertarget',menu.id);trigger.setAttribute('aria-controls',menu.id);
  const close=(restoreFocus:boolean)=>{if(menu.matches(':popover-open'))menu.hidePopover();if(restoreFocus)trigger.focus({preventScroll:true});};
  for(const [value,label] of views){
   const item=button(t(label),'context-menu-item calendar-view-option',()=>{close(true);options.changeView!(value);});
   item.setAttribute('role','menuitemradio');item.setAttribute('aria-checked',String(value===options.view));item.tabIndex=-1;
   const check=icon('check');check.classList.add('calendar-view-check');item.append(check);menu.append(item);
  }
  const focusSelected=()=>menu.querySelector<HTMLElement>('[aria-checked="true"]')?.focus({preventScroll:true});
  menu.addEventListener('beforetoggle',event=>{
   const opening=(event as ToggleEvent).newState==='open';trigger.setAttribute('aria-expanded',String(opening));
   if(!opening)return;
   requestAnimationFrame(()=>{
    if(!menu.matches(':popover-open'))return;
    const anchor=trigger.getBoundingClientRect(),box=menu.getBoundingClientRect();
    menu.style.left=`${Math.max(8,Math.min(anchor.left,innerWidth-box.width-8))}px`;
    menu.style.top=`${Math.max(8,Math.min(anchor.bottom+6,innerHeight-box.height-8))}px`;
    focusSelected();
   });
  });
  trigger.addEventListener('keydown',event=>{if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();if(!menu.matches(':popover-open'))menu.showPopover();else focusSelected();}});
  menu.addEventListener('keydown',event=>{
   if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close(true);return;}
   if(event.key==='Tab'){close(false);return;}
   const items=[...menu.querySelectorAll<HTMLButtonElement>('button')];const current=items.indexOf(document.activeElement as HTMLButtonElement);
   const index=event.key==='ArrowDown'?(current+1)%items.length:event.key==='ArrowUp'?(current-1+items.length)%items.length:event.key==='Home'?0:event.key==='End'?items.length-1:-1;
   if(index>=0){event.preventDefault();items[index].focus({preventScroll:true});}
  });
  wrapper.append(trigger,menu);controls.append(wrapper);
 }
 controls.append(
  iconButton('left',t(options.view==='week'?'上一周':options.view==='month'?'上个月':'上一年'),()=>options.navigate(-1)),
  button(t('今天'),'today-button',options.today),
  iconButton('right',t(options.view==='week'?'下一周':options.view==='month'?'下个月':'下一年'),()=>options.navigate(1)),
 );
 toolbar.append(title,controls);return toolbar;
}
