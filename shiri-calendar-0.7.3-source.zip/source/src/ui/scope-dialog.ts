import { t, formatDate } from '../i18n.ts';
import { button, el } from "./dom.ts";

export function scopeDialog(action: "edit" | "delete", title: string, date: string, choose: (single: boolean) => void, cancel: () => void,options:{allLabel?:string;hint?:string}={}): HTMLElement {
  const overlay = el("div", "confirm-overlay");
  const dialog = el("div", "confirm-dialog scope-dialog");
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");
  dialog.setAttribute("aria-label", action === "edit" ? t("选择修改范围") : t("选择删除范围"));
  dialog.append(el("h2", "", action === "edit" ? t("要修改哪些安排？") : t("要删除哪些安排？")), el("p", "truncate", title),
    el("span", "scope-caption", t('本次：{date}', {date:formatDate(date,true)})));
  const actions = el("div", "scope-actions");
  if(options.hint)dialog.append(el('p','field-hint',options.hint));
  actions.append(button(t("仅本次"), "secondary-button", () => choose(true)), button(options.allLabel??t("整个系列"), "secondary-button", () => choose(false)), button(t("取消"), "text-button", cancel));
  dialog.append(actions); overlay.append(dialog);
  const controls = Array.from(dialog.querySelectorAll<HTMLButtonElement>("button"));
  dialog.addEventListener("keydown", e => {
    if (e.key === "Escape") { e.preventDefault(); cancel(); }
    if (e.key === "Tab") {
      e.preventDefault();
      const i = controls.indexOf(document.activeElement as HTMLButtonElement);
      controls[(i + (e.shiftKey ? -1 : 1) + controls.length) % controls.length].focus();
    }
  });
  requestAnimationFrame(() => { if (dialog.isConnected) controls[0].focus(); });
  return overlay;
}
