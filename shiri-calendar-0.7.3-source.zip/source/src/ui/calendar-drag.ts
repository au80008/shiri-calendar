import type {CalendarItem} from '../model.ts';
import type {DragChange} from '../event-drag.ts';
import {clockTime,eventRange,minutes} from '../timetable.ts';
import {t} from '../i18n.ts';
import {el} from './dom.ts';

/** Pointer gestures keep native clicks/context menus and commit only a valid drop. */
export function enableCalendarDrag(section:HTMLElement,items:CalendarItem[],options:{
 kind:'week'|'month';allowed:()=>boolean;commit:(item:CalendarItem,change:DragChange)=>void;
 create?:(date:string,time:string,endTime:string)=>void;
}):void{
 const byId=new Map(items.map(item=>[item.id,item]));let suppressClick=false;
 section.addEventListener('click',event=>{if(suppressClick){suppressClick=false;event.preventDefault();event.stopImmediatePropagation();}},true);
 section.addEventListener('dragstart',event=>event.preventDefault());
 section.addEventListener('pointerdown',down=>{
  if(down.button!==0||!down.isPrimary||!options.allowed())return;
  const target=down.target as Element;
  const card=target.closest<HTMLElement>('[data-item-id]');const item=card?byId.get(card.dataset.itemId!):undefined;
  const originalColumn=target.closest<HTMLElement>('.time-day');
  const create=!item&&options.kind==='week'&&originalColumn&&options.create;
  if(!item&&!create)return;
  const resize=!!target.closest('.event-resize-handle');
  const timed=options.kind==='week'&&!!item?.time;
  const scroller=section.querySelector<HTMLElement>(options.kind==='week'?'.time-scroll':'.overview-body')!;
  const startScroll=scroller.scrollTop;
  const startMinute=create?Math.max(0,Math.min(1425,Math.floor((down.clientY-originalColumn!.getBoundingClientRect().top)/52*60/15)*15)):0;
  let current:DragChange|undefined,ghost:HTMLElement|undefined,highlight:HTMLElement|undefined;
  let active=false,cancelled=false,lastX=down.clientX,lastY=down.clientY,frame=0;
  const controller=new AbortController(),signal=controller.signal;
  const setHighlight=(node:HTMLElement|undefined)=>{highlight?.classList.remove('calendar-drop-target');highlight=node;highlight?.classList.add('calendar-drop-target');};
  const update=()=>{
   if(!active||cancelled)return;
   const hit=document.elementFromPoint(lastX,lastY);
   const column=hit?.closest<HTMLElement>(options.kind==='month'?'.overview-month-cell':timed||create?'.time-day':'.untimed-cell,.time-day,.week-day');
   if(!column||!section.contains(column)||lastY<scroller.getBoundingClientRect().top&&(timed||create)){
    current=undefined;ghost!.hidden=true;setHighlight(undefined);return;
   }
   if(create&&column!==originalColumn){current=undefined;ghost!.hidden=true;return;}
   ghost!.hidden=false;
   if(timed||create){
    const range=item?eventRange(item):{start:startMinute,end:startMinute+15};
    const delta=(lastY-down.clientY+scroller.scrollTop-startScroll)/52*60;
    const snappedStart=Math.round((range.start+delta)/15)*15;
    const start=resize?range.start:create?Math.min(startMinute,Math.max(0,Math.min(1425,snappedStart))):Math.max(0,Math.min(1440-(range.end-range.start),snappedStart));
    const end=resize?Math.min(1440,Math.max(start+15,Math.round((range.end+delta)/15)*15)):create?Math.max(startMinute+15,Math.min(1440,snappedStart)):start+range.end-range.start;
    const owner=resize?originalColumn!:column;
    current={mode:resize?'resize':'move',date:owner.dataset.date!,time:clockTime(start),endTime:clockTime(end)};
    owner.append(ghost!);ghost!.style.cssText=`top:${start/60*52}px;height:${Math.max(12,(end-start)/60*52-2)}px;left:3px;right:3px;width:auto;`;
    ghost!.querySelector('.event-time')!.textContent=`${clockTime(start)}–${clockTime(end)}`;
    setHighlight(owner);
   }else{
    current={mode:'move',date:column.dataset.date!};
    ghost!.style.left=`${Math.min(innerWidth-160,Math.max(8,lastX+12))}px`;ghost!.style.top=`${Math.min(innerHeight-45,Math.max(8,lastY+12))}px`;
    ghost!.querySelector('.event-time')!.textContent=current.date;setHighlight(column);
   }
  };
  const cleanup=()=>{
   controller.abort();cancelAnimationFrame(frame);ghost?.remove();setHighlight(undefined);card?.classList.remove('calendar-drag-source');
   section.removeAttribute('data-calendar-interacting');
   if(section.hasPointerCapture(down.pointerId))section.releasePointerCapture(down.pointerId);
   if(active){suppressClick=true;setTimeout(()=>{suppressClick=false;},300);}
  };
  const tick=()=>{
   if(!section.isConnected){cleanup();return;}
   if(active&&!cancelled){
    const bounds=scroller.getBoundingClientRect();
    if(lastX>=bounds.left&&lastX<=bounds.right&&lastY>=bounds.top-10&&lastY<=bounds.bottom+10){
     const speed=lastY<bounds.top+28?-9:lastY>bounds.bottom-28?9:0;
     if(speed){scroller.scrollTop+=speed;update();}
    }
   }
   frame=requestAnimationFrame(tick);
  };
  frame=requestAnimationFrame(tick);
  document.addEventListener('pointermove',event=>{
   if(event.pointerId!==down.pointerId)return;lastX=event.clientX;lastY=event.clientY;
   if(cancelled)return;
   if(!active&&Math.hypot(lastX-down.clientX,lastY-down.clientY)<5)return;
   if(!active){
    active=true;section.setPointerCapture(down.pointerId);section.dataset.calendarInteracting='true';card?.classList.add('calendar-drag-source');
    ghost=el('div',`calendar-drag-preview ${timed||create?'timetable-event':'calendar-drag-floating'}`);
    ghost.setAttribute('aria-live','polite');ghost.append(el('span','event-name',item?.title??t('新日程')),el('span','event-time'));
    if(!timed&&!create)document.body.append(ghost);
   }
   event.preventDefault();update();
  },{signal,passive:false});
  document.addEventListener('pointerup',event=>{
   if(event.pointerId!==down.pointerId)return;
   lastX=event.clientX;lastY=event.clientY;if(active&&!cancelled)update();
   const change=cancelled?undefined:current;cleanup();
   if(!change||!options.allowed())return;
   if(create){options.create!(change.date,change.time!,change.endTime!);return;}
   const unchanged=change.date===item!.date&&(change.time===undefined||change.time===item!.time)&&(change.mode!=='resize'||change.endTime===item!.endTime);
   if(!unchanged)options.commit(item!,change);
  },{signal});
  document.addEventListener('pointercancel',cleanup,{signal});
  section.addEventListener('lostpointercapture',cleanup,{signal});
  window.addEventListener('blur',cleanup,{signal});
  document.addEventListener('keydown',event=>{
   if(event.key!=='Escape'||!active)return;
   event.preventDefault();event.stopPropagation();cancelled=true;current=undefined;ghost?.remove();setHighlight(undefined);card?.classList.remove('calendar-drag-source');
  },{signal,capture:true});
 });
}
