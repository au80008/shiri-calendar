/** Keep live controls mounted until their actual content changes. */
export class RenderParts {
  private parts=new Map<string,{key:string;node:HTMLElement}>();
  private used=new Set<string>();
  begin(){this.used.clear();}
  use(name:string,values:unknown[],create:()=>HTMLElement):HTMLElement {
    this.used.add(name);
    const key=JSON.stringify(values),previous=this.parts.get(name);
    if(previous?.key===key)return previous.node;
    const node=create();this.parts.set(name,{key,node});return node;
  }
  commit(parent:HTMLElement,children:HTMLElement[]){
    // Appending a cached child to a fragment would detach it and lose focus.
    const wanted=new Set(children);
    for(const child of [...parent.children])if(!wanted.has(child as HTMLElement))child.remove();
    let cursor:ChildNode|null=parent.firstChild;
    for(const child of children){
      if(child===cursor)cursor=cursor.nextSibling;
      else parent.insertBefore(child,cursor);
    }
    while(cursor){const next=cursor.nextSibling;cursor.remove();cursor=next;}
    for(const name of this.parts.keys())if(!this.used.has(name))this.parts.delete(name);
  }
}
