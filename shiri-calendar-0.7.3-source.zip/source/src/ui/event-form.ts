import { t, translateError } from '../i18n.ts';
import type { CalendarItem, ItemInput } from "../model.ts";
import { button, el, iconButton } from "./dom.ts";
import { recurrenceFields, type RecurrenceDraft } from "./recurrence-fields.ts";
import { temporalControl, normalizeTemporal, validTime } from './temporal-control.ts';
import { validDate } from '../recurrence.ts';
export function eventForm(
  date: string,
  item: CalendarItem | null,
  save: (data: ItemInput) => Promise<void>,
  cancel: () => void,
  draft?: ItemInput,
  onChange?: (input: ItemInput, recurrenceDraft?: RecurrenceDraft) => void,
  scope?: "occurrence" | "series",
  recurrenceDraft?: RecurrenceDraft,
  saveState?:{pending:boolean;error?:string},
): HTMLElement {
  const initial = draft ?? item;
  const kind = initial?.kind ?? "event";
  const name = kind === "note" ? t("备忘") : kind === "task" ? t("待办事项") : t("日程");
  const wrapper = el("section", "form-view");
  const heading = el("div", "form-heading");
  heading.append(iconButton("back", t("返回日历"), cancel), el("h1", "", t(item ? '编辑{name}' : '新建{name}', {name})));
  const form = el("form", "event-form");
  form.noValidate = true;
  if (scope) form.append(el("p", "scope-note", scope === "occurrence" ? t("仅修改本次，其他安排保持原规则。") : t("正在编辑整个系列；日期为系列的开始日期。")));
  function field(text: string, control: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement) {
    const label = el("label", "field");
    control.setAttribute("aria-label", text);
    label.append(el("span", "field-label", text), control);
    form.append(label);
    return label;
  }
  const title = el("input");
  title.name = "title"; title.required = true; title.maxLength = 240;
  title.placeholder = kind === "note" ? t("给这条备忘起个标题") : kind === "task" ? t("有什么需要完成？") : t("请输入日程名称");
  title.value = initial?.title ?? "";
  field(kind === "note" ? t("备忘标题") : kind === "task" ? t("待办事项") : t("日程名称"), title);
  const day = el("input");
  day.type = "text"; day.required = true;
  day.value = initial?.date ?? date;
  field(t("日期"), day);
  temporalControl(day, 'date', t('日期选择器'), t('选择日程日期'));
  const time = el("input"), end = el("input"), reminder = el("select");
  time.value = initial?.time ?? "";
  end.value = initial?.endTime ?? "";
  for (const [value, label] of [["", t("不提醒")], ["0", t("准时提醒")], ["5", t("提前 5 分钟")], ["10", t("提前 10 分钟")], ["30", t("提前 30 分钟")]]) {
    const option = el("option", "", label); option.value = value; reminder.append(option);
  }
  reminder.value = initial?.reminderMinutes?.toString() ?? "";
  if (kind !== "note") {
    const startLabel = field(t("开始时间（可选）"), time);
    if (kind === "event") {
      const endLabel = field(t("结束时间（可选）"), end);
      const row = el("div", "time-fields"); row.append(startLabel, endLabel); form.append(row);
      form.append(el("p", "field-hint", t("结束时间为当天；留空时按 1 小时显示，最晚至当天结束。")));
    }
    field(t("提醒"), reminder);
    temporalControl(time, 'time', t('开始时间选择器'), t('选择开始时刻'));
    if (kind === 'event') temporalControl(end, 'time', t('结束时间选择器'), t('选择结束时刻'));
  }
  time.addEventListener("input", () => {
    if (!time.value) { reminder.value = ""; end.value = ""; }
  });
  const repeat = kind !== "note" && scope !== "occurrence" ? recurrenceFields(initial?.recurrence, () => day.value, recurrenceDraft) : null;
  if (repeat) {
    form.append(repeat.element);
    day.addEventListener("input", () => { if (validDate(day.value)) repeat.updateAnchor(); });
  }
  const notes = el("textarea");
  notes.rows = kind === "note" ? 7 : 3; notes.maxLength = 4000;
  notes.placeholder = kind === "note" ? t("记下想法、灵感或重要信息…") : t("添加备注内容");
  notes.value = initial?.notes ?? "";
  field(kind === "note" ? t("备忘内容") : t("备注（可选）"), notes);
  const error = el("p", "form-error"); error.setAttribute("role", "alert");
  if(saveState?.error)error.textContent=t('保存失败：{error}',{error:translateError(saveState.error)});
  const actions = el("div", "form-actions");
  const cancelButton = button(t("取消"), "secondary-button", cancel), submit = el("button", "primary-button", t("保存"));
  submit.type = "submit"; actions.append(cancelButton, submit); form.append(error, actions);
  let saving = false;
  const previousDisabled=new Map<HTMLInputElement|HTMLTextAreaElement|HTMLSelectElement|HTMLButtonElement,boolean>();
  const setSaving=(pending:boolean)=>{
    saving=pending;
    for(const control of wrapper.querySelectorAll<HTMLInputElement|HTMLTextAreaElement|HTMLSelectElement|HTMLButtonElement>('button,input,select,textarea')){
      if(pending){previousDisabled.set(control,control.disabled);control.disabled=true;}else control.disabled=previousDisabled.get(control)??false;
    }
    submit.textContent=pending?t('正在保存…'):t('保存');
  };
  const readInput = (): ItemInput => {
    const recurrence = repeat?.read() ?? null;
    return {
    kind, title: title.value, date: day.value,
    time: kind === "note" ? null : time.value || null,
    endTime: kind === "event" ? end.value || null : null,
    notes: notes.value,
    reminderMinutes: kind === "note" || reminder.value === "" ? null : Number(reminder.value),
    completed: kind === "note" || recurrence ? false : initial?.completed ?? false,
    recurrence,
    };
  };
  form.addEventListener("input", () => onChange?.(readInput(), repeat?.state()));
  onChange?.(readInput(), repeat?.state());
  form.addEventListener("submit", async event => {
    event.preventDefault();
    if (saving) return;
    if (!title.value.trim()) { error.textContent = t('请填写标题'); title.focus(); return; }
    day.value = normalizeTemporal(day.value, 'date');
    time.value = normalizeTemporal(time.value, 'time');
    end.value = normalizeTemporal(end.value, 'time');
    if (!validDate(day.value)) { error.textContent = t('请输入有效日期（YYYY-MM-DD）'); day.focus(); return; }
    repeat?.updateAnchor();
    if (kind !== 'note' && time.value && !validTime(time.value)) { error.textContent = t('请输入有效时间（00:00–23:59）'); time.focus(); return; }
    if (kind === 'event' && end.value && !validTime(end.value)) { error.textContent = t('请输入有效时间（00:00–23:59）'); end.focus(); return; }
    if ([...title.value.trim()].length > 120) { error.textContent = t("标题最多 120 字"); return; }
    if ([...notes.value].length > 2000) { error.textContent = t("内容最多 2000 字"); return; }
    const input = readInput();
    const repeatError = repeat?.error();
    if (repeatError) { error.textContent = repeatError; return; }
    if (input.reminderMinutes !== null && !input.time) {
      error.textContent = t("设置提醒前，请先填写时间"); time.focus(); return;
    }
    if (input.endTime && (!input.time || input.endTime <= input.time)) {
      error.textContent = t("结束时间需晚于开始时间（同一天）"); end.focus(); return;
    }
    setSaving(true);error.textContent = "";
    try { await save(input); }
    catch (e) { error.textContent = t('保存失败：{error}', {error:translateError(e)}); }
    finally { setSaving(false); }
  });
  wrapper.append(heading, form);
  if(saveState?.pending)setSaving(true);
  requestAnimationFrame(() => { if (title.isConnected) title.focus(); });
  return wrapper;
}
