import {el} from './dom.ts';
export function mountDialog(content:HTMLElement,label:string,closed:()=>void=()=>{}):()=>void {
 document.querySelector<HTMLElement>('[data-portal-dialog]')?.dispatchEvent(new Event('portal-close'));
 const previous=document.activeElement as HTMLElement|null;
 const app=document.getElementById('app');const inert=app?.inert??false;if(app)app.inert=true;
 const overlay=el('div','portal-overlay');overlay.dataset.portalDialog='true';
 content.classList.add('portal-dialog');content.setAttribute('role','dialog');content.setAttribute('aria-label',label);content.setAttribute('aria-modal','true');overlay.append(content);
 const close=()=>{if(!overlay.isConnected)return;document.removeEventListener('keydown',onKey,true);overlay.remove();if(app)app.inert=inert;closed();if(previous?.isConnected)previous.focus();};
 overlay.addEventListener('portal-close',close);overlay.addEventListener('click',e=>{if(e.target===overlay)close();});
 const onKey=(e:KeyboardEvent)=>{if(e.key==='Escape'){if(content.querySelector(':popover-open'))return;e.preventDefault();e.stopPropagation();close();}if(e.key==='Tab'){const controls=[...content.querySelectorAll<HTMLElement>('button,input,select,textarea,[tabindex="0"]')].filter(e=>!e.hasAttribute('disabled')&&e.offsetParent!==null);const first=controls[0],last=controls.at(-1);if(!first){e.preventDefault();return;}if(!content.contains(document.activeElement)){e.preventDefault();first.focus();}else if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}};
 document.addEventListener('keydown',onKey,true);
 document.body.append(overlay);requestAnimationFrame(()=>content.querySelector<HTMLElement>('button,input,select')?.focus());return close;
}
