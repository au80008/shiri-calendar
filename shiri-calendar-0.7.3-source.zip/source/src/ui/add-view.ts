import { t } from '../i18n.ts';
import type { ItemKind } from "../model.ts";
import { button, el, icon, iconButton } from "./dom.ts";

export interface AddContext { date: string; time: string | null; endTime?:string|null; }
const choices: { kind: ItemKind; label: string; detail: string; icon: string }[] = [
  { kind: "event", label: "添加日程", detail: "安排时间，设置提醒", icon: "calendar" },
  { kind: "note", label: "添加备忘", detail: "记下想法、灵感与重要信息", icon: "note" },
  { kind: "task", label: "添加待办事项", detail: "列出要做的事，完成后勾选", icon: "check" },
];
export function addView(choose: (kind: ItemKind) => void, cancel: () => void): HTMLElement {
  const view = el("section", "add-view");
  const heading = el("div", "form-heading");
  heading.append(iconButton("back", t("返回日历"), cancel), el("h1", "", t("添加")));
  view.append(heading, el("p", "add-intro", t("想在这一天记下什么？")));
  for (const choice of choices) {
    const control = button("", "add-choice", () => choose(choice.kind));
    control.setAttribute("aria-label", t(choice.label));
    const text = el("span", "add-choice-text");
    text.append(el("strong", "", t(choice.label)), el("span", "", t(choice.detail)));
    control.append(icon(choice.icon), text, icon("right"));
    view.append(control);
  }
  return view;
}

let closeCurrent: (() => void) | undefined;
export function closeAddMenu() { closeCurrent?.(); }
export function showAddMenu(x: number, y: number, choose: (kind: ItemKind) => void) {
  showContextMenu(x,y,t('添加'),choices.map(choice=>({label:t(choice.label),icon:choice.icon,action:()=>choose(choice.kind)})));
}
export function showContextMenu(x:number,y:number,label:string,choices:{label:string;icon:string;action:()=>void}[]) {
  closeAddMenu();
  const menu = el("div", "add-context-menu");
  menu.setAttribute("role", "menu");
  menu.setAttribute("aria-label", label);
  const previous = document.activeElement as HTMLElement | null;
  const controller = new AbortController();
  const close = () => {
    controller.abort(); menu.remove();
    if (closeCurrent === close) closeCurrent = undefined;
  };
  closeCurrent = close;
  for (const choice of choices) {
    const control = button(choice.label, "context-menu-item", () => {
      close(); choice.action();
    });
    control.setAttribute("role", "menuitem");
    control.prepend(icon(choice.icon));
    menu.append(control);
  }
  document.body.append(menu);
  const bounds = menu.getBoundingClientRect();
  menu.style.left = `${Math.max(6, Math.min(x, innerWidth - bounds.width - 6))}px`;
  menu.style.top = `${Math.max(6, Math.min(y, innerHeight - bounds.height - 6))}px`;
  const options = Array.from(menu.querySelectorAll<HTMLButtonElement>("button"));
  options[0].focus();
  document.addEventListener("pointerdown", e => {
    if (!menu.contains(e.target as Node)) close();
  }, { signal: controller.signal });
  menu.addEventListener("keydown", e => {
    if (e.key === "Escape" || e.key === "Tab") {
      close(); if (e.key === "Escape") { e.preventDefault(); previous?.focus(); }
    }
    if (e.key === "ArrowDown" || e.key === "ArrowUp" || e.key === "Home" || e.key === "End") {
      e.preventDefault();
      const current = options.indexOf(document.activeElement as HTMLButtonElement);
      const next = e.key === "Home" ? 0 : e.key === "End" ? options.length - 1 : (current + (e.key === "ArrowDown" ? 1 : -1) + options.length) % options.length;
      options[next].focus();
    }
  }, { signal: controller.signal });
  window.addEventListener("resize", close, { signal: controller.signal });
  window.addEventListener("blur", close, { signal: controller.signal });
}
