import { t, translateError } from '../i18n.ts';
import type {DisplayItem,ImportedInput} from '../subscriptions.ts';
import {clockInZone} from '../clock.ts';
import {button,el,iconButton} from './dom.ts';
import {calendarField} from './calendar-fields.ts';
import {temporalControl,normalizeTemporal} from './temporal-control.ts';

export function externalEventDetails(item:DisplayItem,copyDay:()=>void,close:()=>void,save:(input:ImportedInput|null)=>Promise<void>,zone:string):HTMLElement {
 const e=item.external!;const section=el('section','external-detail');const head=el('div','dialog-heading');
 head.append(el('strong','',t('编辑导入日程')),iconButton('close',t('关闭详情'),close));
 section.append(head,el('p','source-caption',`${e.sourceName} · ${e.locallyEdited?t('已本地修改'):t('已导入')}`),el('p','field-hint',t('只在拾日保存，不自动更新或回写来源。重复安排仅修改这一次。')));
 const form=el('form','source-form');form.noValidate=true;const fields=el('fieldset','source-fields');form.append(fields);
 const field=(text:string,value:string,multiline=false)=>{const input=multiline?el('textarea'):el('input');input.value=value;fields.append(calendarField(text,input));return input;};
 const title=field(t('日程名称'),item.title);title.maxLength=120;
 const start=e.startUtc?clockInZone(new Date(e.startUtc),zone):null,end=e.endUtc?clockInZone(new Date(e.endUtc),zone):null;
 const clock=(t:{hour:number;minute:number}|null)=>t?`${String(t.hour).padStart(2,'0')}:${String(t.minute).padStart(2,'0')}`:'';
 const allDay=el('input');allDay.type='checkbox';allDay.checked=e.allDay;const check=el('label','source-check');check.append(allDay,el('span','',t('全天')));allDay.setAttribute('aria-label',t('全天'));fields.append(check);
 const startDate=field(t('开始日期'),start?.date||e.startDate||item.date) as HTMLInputElement;
 const endDate=field(t('结束日期'),end?.date||e.endDate||item.date) as HTMLInputElement;
 const startTime=field(t('开始时间'),clock(start)) as HTMLInputElement;
 const endTime=field(t('结束时间'),clock(end)) as HTMLInputElement;
 temporalControl(startDate,'date',t('开始日期选择器'),t('选择开始日期'));temporalControl(endDate,'date',t('结束日期选择器'),t('选择结束日期'));
 temporalControl(startTime,'time',t('开始时间选择器'),t('选择开始时间'));temporalControl(endTime,'time',t('结束时间选择器'),t('选择结束时间'));
 const toggle=()=>{for(const input of [startTime,endTime]){input.disabled=allDay.checked;input.closest('label')!.hidden=allDay.checked;}};allDay.addEventListener('change',toggle);toggle();
 const location=field(t('地点'),e.location);location.maxLength=300;
 const notes=field(t('备注'),e.description,true);notes.maxLength=2000;(notes as HTMLTextAreaElement).rows=3;
 const error=el('p','form-error');error.setAttribute('role','alert');
 const actions=el('div','form-actions');const cancel=button(t('取消'),'secondary-button',close);const submit=el('button','primary-button',t('保存'));submit.type='submit';actions.append(cancel,submit);form.append(error,actions);section.append(form);
 let busy=false;
 async function commit(input:ImportedInput|null){if(busy)return;busy=true;fields.disabled=true;submit.disabled=true;cancel.disabled=true;error.textContent='';try{await save(input);close();}catch(err){error.textContent=translateError(err);}finally{busy=false;fields.disabled=false;submit.disabled=false;cancel.disabled=false;toggle();}}
 form.addEventListener('submit',event=>{event.preventDefault();void commit({title:title.value,description:notes.value,location:location.value,startDate:normalizeTemporal(startDate.value,'date'),endDate:normalizeTemporal(endDate.value,'date'),startTime:allDay.checked?null:normalizeTemporal(startTime.value,'time'),endTime:allDay.checked?null:normalizeTemporal(endTime.value,'time'),allDay:allDay.checked,displayZone:zone});});
 if(e.locallyEdited)section.append(button(t('恢复导入版本'),'secondary-button',()=>void commit(null)));
 section.append(button(e.continuedBefore||e.continuesAfter?t('复制当天安排到拾日'):t('复制到拾日'),'text-button',copyDay));
 return section;
}
