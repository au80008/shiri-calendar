import { t, translateError } from '../i18n.ts';
import type {SourceInput,PreviewResult} from '../subscriptions.ts';
import {sourceColors} from '../subscriptions.ts';
import {button,el,iconButton} from './dom.ts';
import {calendarField,timezoneSelect} from './calendar-fields.ts';

export function subscriptionForm(initial:SourceInput|undefined,inspect:(input:SourceInput)=>Promise<PreviewResult>,save:(input:SourceInput,ticket?:string)=>Promise<void>,cancel:()=>void,remove?:()=>void,reimport=false):HTMLElement {
 const section=el('section','subscription-form');const head=el('div','dialog-heading');head.append(iconButton('back',t('返回日历列表'),cancel),el('strong','',reimport?t('重新导入日历'):initial?t('管理日历'):t('添加日历')));section.append(head);
 const form=el('form','source-form');const fields=el('fieldset','source-fields');
 const name=el('input');name.value=initial?.name??'';name.required=true;name.maxLength=80;name.placeholder=t('例如：学校课表');
 const url=el('input');url.type='password';url.value=initial?.url??'';url.required=!initial||reimport;url.maxLength=16384;url.autocomplete='off';url.spellcheck=false;url.placeholder=t('粘贴 iCal / ICS 订阅链接');
 const show=button(t('显示链接'),'text-button',()=>{url.type=url.type==='password'?'text':'password';show.textContent=url.type==='password'?t('显示链接'):t('隐藏链接');});
 const color=el('select');const names=[t('蓝色'),t('绿色'),t('紫色'),t('金色'),t('粉色'),t('橙色')];sourceColors.forEach((value,i)=>{const option=el('option','',names[i]);option.value=value;color.append(option);});color.value=initial?.color??sourceColors[0];
 const zone=timezoneSelect(initial?.fallbackZone??'Europe/Copenhagen');
 const visible=el('input');visible.type='checkbox';visible.checked=initial?.visible??true;visible.setAttribute('aria-label',t('显示此日历'));
 const override=el('input');override.type='checkbox';override.checked=initial?.overrideUnknownZone??false;override.setAttribute('aria-label',t('用解释时区替代订阅中的 TZID 时区'));
 const reminder=el('select');for(const [value,label] of [['',t('关闭提醒')],['0',t('准时提醒')],['5',t('提前 5 分钟')],['10',t('提前 10 分钟')],['30',t('提前 30 分钟')]]){const option=el('option','',label);option.value=value;reminder.append(option);}reminder.value=initial?.reminderMinutes?.toString()??'';
 const visibleLabel=el('label','source-check');visibleLabel.append(visible,el('span','',t('显示此日历')));
 const overrideLabel=el('label','source-check');overrideLabel.append(override,el('span','',t('用解释时区替代订阅中的 TZID 时区')));
 fields.append(calendarField(t('日历名称'),name),calendarField(t('订阅链接'),url),show,el('p','field-hint',t('使用 iCal / ICS 链接一次导入，不自动更新。重新导入需再次填写链接；仅改设置可留空。')),calendarField(t('日历颜色'),color),calendarField(t('解释时区'),zone),el('p','field-hint',t('日历没有注明时区时，按此时区解释。')),overrideLabel,calendarField(t('订阅提醒'),reminder),el('p','field-hint',t('隐藏日历不会关闭提醒。')),visibleLabel);
 const check=button(t('检查链接'),'secondary-button',()=>void doCheck());const preview=el('div','calendar-preview');const error=el('p','form-error');error.setAttribute('role','alert');
 const actions=el('div','form-actions');const back=button(t('取消'),'secondary-button',cancel);const submit=el('button','primary-button',initial?t('保存设置'):t('确认导入'));submit.type='submit';actions.append(back,submit);
 const warning=el('p','field-hint',t('重新导入将替换此日历的所有安排和本地修改，其他个人日程保留。'));form.append(fields,warning,check,preview,error,actions);section.append(form);
 if(remove)section.append(button(t('移除日历'),'danger-text-button',remove));
 let checked:{input:string;result:PreviewResult}|undefined;let checking=false,saving=false;
 const read=():SourceInput=>({name:name.value,url:url.value,color:color.value,visible:visible.checked,fallbackZone:zone.value,overrideUnknownZone:override.checked,reminderMinutes:reminder.value===''?null:Number(reminder.value)});
 function needsCheck(){const i=read();return !initial||reimport||!!i.url.trim()||i.fallbackZone!==initial.fallbackZone||i.overrideUnknownZone!==initial.overrideUnknownZone;}
 function update(){warning.hidden=!initial||(!reimport&&!url.value.trim());submit.textContent=initial?(reimport||url.value.trim()?t('重新导入并替换'):t('保存设置')):t('确认导入');const validPreview=checked?.input===JSON.stringify(read());submit.disabled=checking||saving||(needsCheck()&&!validPreview);check.disabled=checking||saving;check.textContent=checking?t('正在检查…'):t('检查链接');fields.disabled=saving;back.disabled=saving;}
 form.addEventListener('input',()=>{checked=undefined;preview.replaceChildren();error.textContent='';update();});
 form.addEventListener('change',()=>{checked=undefined;preview.replaceChildren();error.textContent='';update();});
 async function doCheck(){
  if(checking||saving||!form.reportValidity())return;if(!url.value.trim()){error.textContent=t('请重新输入日历链接');return;}const input=read(),signature=JSON.stringify(input);checking=true;error.textContent='';update();
  try{const result=await inspect(input);if(!section.isConnected||signature!==JSON.stringify(read()))return;checked={input:signature,result};preview.replaceChildren(el('strong','',t('{count} 个事件／系列', {count:result.eventCount})),el('p','source-caption',`${result.calendarName??result.canonicalHost}${result.firstDate?` · ${result.firstDate} — ${result.lastDate??t('含重复安排')}`:''}`));
   for(const item of result.samples)preview.append(el('p','preview-sample',`${item.date} ${item.time??t('全天')} · ${item.title}${item.location?` · ${item.location}`:''}`));
   for(const message of result.warnings)preview.append(el('p','field-hint',translateError(message)));if(result.unsupportedCount)preview.append(el('p','field-hint',t('{count} 项待办或日志不包含在本次订阅中。', {count:result.unsupportedCount})));
  }catch(e){error.textContent=translateError(e);}finally{checking=false;update();}
 }
 form.addEventListener('submit',async e=>{e.preventDefault();if(submit.disabled||saving)return;const input=read();saving=true;error.textContent='';update();try{await save(input,checked?.input===JSON.stringify(input)?checked.result.ticket:undefined);}catch(e){error.textContent=translateError(e);if(String(e).includes('预览已过期')){checked=undefined;preview.replaceChildren();}}finally{saving=false;update();}});
 update();requestAnimationFrame(()=>name.focus());return section;
}
