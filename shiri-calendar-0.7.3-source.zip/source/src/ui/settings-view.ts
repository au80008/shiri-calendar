import type {AppSettings} from '../model.ts';
import {getLanguage,t,translateError,type Language} from '../i18n.ts';
import {button,el,iconButton} from './dom.ts';
import {calendarField} from './calendar-fields.ts';

export function settingsView(settings:AppSettings,save:(language:Language)=>Promise<void>,close:()=>void):HTMLElement{
 const section=el('section','settings-view');
 const render=()=>{
  section.replaceChildren();section.setAttribute('aria-label',t('设置'));
  const head=el('div','dialog-heading');head.append(el('strong','',t('设置')),iconButton('close',t('关闭设置'),close));section.append(head);
  const language=el('select');for(const [value,label] of [['zh-CN','简体中文'],['en','English']]){const option=el('option','',t(label));option.value=value;language.append(option);}language.value=getLanguage();
  const error=el('p','form-error');error.setAttribute('role','alert');section.append(calendarField(t('语言'),language),error);
  language.addEventListener('change',async()=>{language.disabled=true;try{await save(language.value as Language);render();}catch(err){error.textContent=translateError(err);language.value=getLanguage();language.disabled=false;}});
 };render();return section;
}
export function windowModes(current:string,choose:(mode:'compact'|'timetable'|'fullscreen')=>void,close:()=>void):HTMLElement{
 const section=el('section','window-modes');const head=el('div','dialog-heading');head.append(el('strong','',t('窗口模式')),iconButton('close',t('关闭'),close));section.append(head);
 for(const [value,label] of [['compact','小日历'],['timetable','展开时间表'],['fullscreen','全屏时间表']] as const){const control=button(t(label),'window-mode-choice',()=>choose(value));control.setAttribute('aria-pressed',String(current===value));section.append(control);}
 return section;
}
