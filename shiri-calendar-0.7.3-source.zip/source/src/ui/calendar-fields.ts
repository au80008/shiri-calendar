import { t } from '../i18n.ts';
import {el} from './dom.ts';
export function calendarField(text:string,control:HTMLElement):HTMLLabelElement {
 const label=el('label','field');control.setAttribute('aria-label',text);label.append(el('span','field-label',text),control);return label;
}
export function timezoneSelect(value:string|null,includeSystem=false):HTMLSelectElement {
 const select=el('select');
 if(includeSystem){const option=el('option','',t('跟随系统'));option.value='system';select.append(option);}
 const common=['UTC','Europe/Copenhagen','Asia/Shanghai','America/New_York'];
 const all=typeof Intl.supportedValuesOf==='function'?Intl.supportedValuesOf('timeZone'):[];
 const labels:Record<string,string>={'UTC':'UTC','Europe/Copenhagen':t('哥本哈根 · Europe/Copenhagen'),'Asia/Shanghai':t('中国 · Asia/Shanghai'),'America/New_York':t('纽约 · America/New_York')};
 for(const zone of new Set([...common,...all])){const option=el('option','',labels[zone]??zone);option.value=zone;select.append(option);}
 select.value=value??'system';return select;
}
