import {getLanguage,t} from '../i18n.ts';
import type {CalendarItem} from '../model.ts';
import {groupItemsByDate,monthDays,yearMonths,type OverviewKind} from '../overview.ts';
import type {AddContext} from './add-view.ts';
import {button,el} from './dom.ts';
import {calendarToolbar} from './calendar-toolbar.ts';
import {enableCalendarDrag} from './calendar-drag.ts';
import type {DragChange} from '../event-drag.ts';

export interface OverviewOptions {
  view:OverviewKind;
  selected:string;
  year:number;
  month:number;
  items:CalendarItem[];
  today:string;
  chooseDate:(date:string)=>void;
  navigate:(delta:number)=>void;
  edit:(item:CalendarItem)=>void;
  add:(context:AddContext,x:number,y:number)=>void;
  itemMenu:(item:CalendarItem,x:number,y:number)=>void;
  manageCalendars:()=>void;
  changeView:(view:'week'|'month'|'year')=>void;
  selectMonth:(year:number,month:number)=>void;
  canDrag?:()=>boolean;
  reschedule?:(item:CalendarItem,change:DragChange)=>void;
}

const weekdayNames = ['周一','周二','周三','周四','周五','周六','周日'];

function weekdays():HTMLElement {
  const row=el('div','overview-weekdays');
  for(const name of weekdayNames)row.append(el('span','',t(name)));
  return row;
}

function monthLabel(year:number,month:number,includeYear=true):string {
  return new Intl.DateTimeFormat(getLanguage(),{year:includeYear?'numeric':undefined,month:'long'}).format(new Date(year,month,1,12));
}

function dateButton(date:string,options:OverviewOptions,className:string):HTMLButtonElement {
  const control=button(String(Number(date.slice(8))),`${className}${date===options.selected?' selected':''}${date===options.today?' is-today':''}`,()=>{
    options.chooseDate(date);
    if(options.view==='year')options.changeView('week');
  });
  control.dataset.date=date;
  control.setAttribute('aria-label',t(options.view==='month'?'月视图 {date}':'年视图 {date}',{date}));
  control.setAttribute('aria-pressed',String(date===options.selected));
  if(date===options.today)control.setAttribute('aria-current','date');
  return control;
}

function eventSummary(item:CalendarItem,edit:OverviewOptions['edit']):HTMLElement {
  const control=button('',`overview-event ${item.kind??'event'}${item.completed?' completed':''}${item.external?' external':''}`,()=>edit(item));
  control.dataset.itemId=item.id;
  if(item.external)control.style.setProperty('--source-color',item.external.color);
  const time=item.time??(item.external?.allDay?t('全天'):'');
  if(time)control.append(el('span','overview-event-time',time));
  control.append(el('span','overview-event-title',item.title));
  control.title=[time,item.title,item.external?.sourceName,item.notes].filter(Boolean).join(' · ');
  return control;
}

function monthGrid(options:OverviewOptions,grouped:Map<string,CalendarItem[]>):HTMLElement {
  const sheet=el('div','overview-month-sheet');
  sheet.append(weekdays());
  const grid=el('div','overview-month-grid');
  for(const date of monthDays(options.year,options.month)){
    const outside=Number(date.slice(5,7))!==options.month+1;
    const cell=el('div',`overview-month-cell${outside?' outside':''}${date===options.selected?' selected':''}`);
    cell.dataset.date=date;
    const head=el('div','overview-cell-heading');
    head.append(dateButton(date,options,'overview-date'));
    const items=grouped.get(date)??[];
    if(items.length)head.append(el('span','overview-day-count',String(items.length)));
    cell.append(head);
    for(const item of items.slice(0,3))cell.append(eventSummary(item,options.edit));
    if(items.length>3)cell.append(button(t('另有 {count} 项安排',{count:items.length-3}),'overview-more',()=>options.chooseDate(date)));
    grid.append(cell);
  }
  sheet.append(grid);
  return sheet;
}

function yearGrid(options:OverviewOptions,grouped:Map<string,CalendarItem[]>):HTMLElement {
  const grid=el('div','overview-year-grid');
  for(const {year,month,days} of yearMonths(options.year)){
    const mini=el('section','overview-mini-month');
    const monthHeading=el('div','overview-mini-heading');
    const heading=button(monthLabel(year,month,false),'overview-month-heading',()=>options.selectMonth(year,month));
    monthHeading.append(heading);
    const prefix=`${year}-${String(month+1).padStart(2,'0')}-`;
    const count=[...grouped].reduce((total,[date,items])=>total+(date.startsWith(prefix)?items.length:0),0);
    if(count)monthHeading.append(el('span','overview-month-count',t('{count} 项安排',{count})));
    mini.append(monthHeading,weekdays());
    const dates=el('div','overview-mini-days');
    for(const date of days){
      if(!date.startsWith(prefix)){
        const blank=el('span','overview-year-blank');
        blank.setAttribute('aria-hidden','true');dates.append(blank);continue;
      }
      const day=dateButton(date,options,'overview-year-day');
      const items=grouped.get(date)??[];
      if(items.length){
        day.classList.add('has-items');
        day.title=t('{date} · {count} 项安排',{date,count:items.length});
        const dots=el('span','overview-dots');dots.setAttribute('aria-hidden','true');
        for(const color of [...new Set(items.map(item=>item.external?.color??'var(--accent)'))].slice(0,3)){
          const dot=el('span','overview-dot');dot.style.backgroundColor=color;dots.append(dot);
        }
        day.append(dots);
      }
      dates.append(day);
    }
    mini.append(dates);grid.append(mini);
  }
  return grid;
}

export function overviewView(options:OverviewOptions):HTMLElement {
  const section=el('section',`overview overview-${options.view}`);
  section.setAttribute('role','region');
  section.setAttribute('aria-label',t(options.view==='month'?'月视图':'年视图'));
  const toolbar=calendarToolbar({view:options.view,title:t(options.view==='month'?'月视图':'年视图'),
    subtitle:options.view==='month'?monthLabel(options.year,options.month):new Intl.DateTimeFormat(getLanguage(),{year:'numeric'}).format(new Date(options.year,0,1,12)),
    navigate:options.navigate,today:()=>options.chooseDate(options.today),manageCalendars:options.manageCalendars,changeView:options.changeView});
  toolbar.classList.add('overview-toolbar');
  const body=el('div','overview-body');
  const grouped=groupItemsByDate(options.items);
  body.append(options.view==='month'?monthGrid(options,grouped):yearGrid(options,grouped));
  const byId=new Map(options.items.map(item=>[item.id,item]));
  body.addEventListener('contextmenu',event=>{
    const target=event.target;
    if(!(target instanceof Element))return;
    const card=target.closest<HTMLElement>('[data-item-id]');
    const item=card&&byId.get(card.dataset.itemId!);
    const date=target.closest<HTMLElement>('[data-date]')?.dataset.date;
    if(!item&&!date)return;
    event.preventDefault();
    if(item)options.itemMenu(item,event.clientX,event.clientY);
    else options.add({date:date!,time:null},event.clientX,event.clientY);
  });
  section.append(toolbar,body,el('footer','timetable-footer overview-footer',t(options.view==='month'?'点击内容编辑 · 右键添加':'点击月份查看月历 · 点击日期查看周日程')));
  if(options.view==='month'&&options.reschedule)enableCalendarDrag(section,options.items,{kind:'month',allowed:options.canDrag??(()=>true),commit:options.reschedule});
  return section;
}
