import { t, formatMonth, weekdayLabels } from '../i18n.ts';
import { buildMonthGrid, localDateKey } from "../calendar.ts";
import type { CalendarItem } from "../model.ts";
import { button, el, iconButton } from "./dom.ts";
export function calendarView(
  year: number,
  month: number,
  selected: string,
  items: CalendarItem[],
  navigate: (delta: number) => void,
  today: () => void,
  select: (key: string) => void,
  current = localDateKey(new Date()),
): HTMLElement {
  const section = el("section", "calendar");
  section.setAttribute("aria-label", t("月历"));
  const head = el("div", "month-header");
  const title = el("h1", "", formatMonth(year, month));
  const controls = el("div", "month-controls");
  controls.append(
    iconButton("left", t("上个月"), () => navigate(-1)),
    button(t("今天"), "today-button", today),
    iconButton("right", t("下个月"), () => navigate(1)),
  );
  head.append(title, controls);
  const week = el("div", "weekdays");
  for (const day of weekdayLabels())
    week.append(el("span", "", day));
  const grid = el("div", "days");
  const occupied = new Set(
    items.filter((x) => !x.completed).map((x) => x.date),
  );
  for (const key of buildMonthGrid(year, month)) {
    const b = button(
      String(Number(key.slice(8))),
      `day${Number(key.slice(5, 7)) !== month + 1 ? " outside" : ""}${key === selected ? " selected" : ""}${key === current ? " is-today" : ""}`,
      () => select(key),
    );
    b.setAttribute("aria-label", key);
    b.setAttribute("aria-pressed", String(key === selected));
    if (key === current) b.setAttribute("aria-current", "date");
    if (occupied.has(key)) {
      const colors=[...new Set(items.filter(i=>!i.completed&&i.date===key).map(i=>i.external?.color??'local'))].slice(0,3);
      const dots=el('span','event-dots');for(const color of colors){const dot=el('span','event-dot');if(color!=='local')dot.style.backgroundColor=color;dots.append(dot);}b.append(dots);
    }
    grid.append(b);
  }
  section.append(head, week, grid);
  return section;
}
