import "./styles.css";
import "./theme.css";
import "./form-controls.css";
import './overview.css';
import './window-modes.css';
import './calendar-toolbar.css';
import './event-interactions.css';
import {localDragInput,importedDragInput,type DragChange} from './event-drag.ts';
import {getLanguage,setLanguage,t,translateError} from './i18n.ts';
import {overviewRange} from './overview.ts';
import {overviewView} from './ui/overview-view.ts';
import {settingsView,windowModes} from './ui/settings-view.ts';
import { buildMonthGrid, dateLabel, localDateKey, shiftMonth } from "./calendar.ts";
import {dateKeyInZone,nextInZone} from './clock.ts';
import {ExternalQuery,defaultView,mergeDisplayItems,copyDayInput,type OccurrenceRange,type OccurrenceBatch} from './subscriptions.ts';
import {externalEventDetails} from './ui/external-event.ts';
import {mountDialog} from './ui/modal.ts';
import {calendarSources} from './ui/calendar-sources.ts';
import type {SourceInput,PreviewResult,CalendarViewPrefs} from './subscriptions.ts';
import { command, subscribe } from "./bridge.ts";
import type { AppSnapshot, AppSettings, CalendarItem, ItemInput, ItemKind } from "./model.ts";
import { button, el, icon, iconButton } from "./ui/dom.ts";
import { calendarView } from "./ui/calendar-view.ts";
import { agendaView } from "./ui/agenda-view.ts";
import { eventForm } from "./ui/event-form.ts";
import { addView, closeAddMenu, showAddMenu, showContextMenu, type AddContext } from "./ui/add-view.ts";
import { scopeDialog } from "./ui/scope-dialog.ts";
import type { RecurrenceDraft } from "./ui/recurrence-fields.ts";
import { expandItems, nextOccurrence } from "./recurrence.ts";
import { timetableView } from "./ui/timetable-view.ts";
import { shiftDate, weekDates } from "./timetable.ts";
import { enableWindowDrag } from './ui/window-drag.ts';
import {RenderParts} from './ui/render-parts.ts';
import {updateCalendarSelection,updateCurrentTime} from './ui/calendar-selection.ts';

const shell = document.querySelector<HTMLElement>("#app")!;
const root = el("main", "widget");
shell.append(root);
const parts=new RenderParts();
let leftView:{key:string;node:HTMLElement}|undefined;
const timetableScroll = new Map<string, number>();
const overviewScroll=new Map<string,number>();
let overviewFocusToday=true;
let viewChangeSequence=0;
let snapshot: AppSnapshot;
let selected = localDateKey(new Date());
let previousToday = selected;
let year = new Date().getFullYear(),
  month = new Date().getMonth();
let editing: CalendarItem | null | undefined;
let draft: { item: CalendarItem | null; input: ItemInput; occurrenceDate?: string | null; recurrenceDraft?: RecurrenceDraft } | undefined;
let deleting: CalendarItem | null = null;
let deletingAllImported=false;
let deletingRelated=false;
let deletingOccurrenceDate: string | null = null;
let editingOccurrenceDate: string | null = null;
let scopeChoice: { action: "edit" | "delete"; item: CalendarItem } | null = null;
let adding: AddContext | undefined;
let error = "";
let savingItem=false;
let savingDrag=false;
let saveFailure='';
const originalError=(value:unknown)=>value instanceof Error?value.message:String(value);
let mutationQueue: Promise<void> = Promise.resolve();
const externalQuery=new ExternalQuery();
let sourcePanel:ReturnType<typeof calendarSources>|undefined;
const viewPrefs=()=>snapshot?.calendarView??defaultView;
const settings=():AppSettings=>snapshot?.settings??{language:'zh-CN',calendarView:'week'};
function applyLocale(){setLanguage(settings().language);document.documentElement.lang=getLanguage();document.title=getLanguage()==='en'?'Shiri · Desktop calendar':'拾日 · 桌面日历';shell.setAttribute('aria-label',t('拾日日历'));}
function leftRange(){const days=weekDates(selected);const view=settings().calendarView;return view==='week'?{from:days[0],to:days[6]}:overviewRange(view,year,month);}
const todayKey=()=>dateKeyInZone(new Date(),viewPrefs().displayZone);
function displayItems(from:string,to:string):CalendarItem[]{return mergeDisplayItems(expandItems(snapshot.items,from,to),externalQuery.items.filter(i=>i.date>=from&&i.date<=to),viewPrefs());}
function ensureExternal(){
  const queryZone=viewPrefs().displayZone??Intl.DateTimeFormat().resolvedOptions().timeZone;
  const grid=buildMonthGrid(year,month);
  const spans=[{from:grid[0],to:grid[41]},{from:selected,to:selected}];
  if(snapshot.window.timetableOpen&&!snapshot.window.collapsed)spans.push(leftRange());
  if(snapshot.window.collapsed)spans.push({from:todayKey(),to:shiftDate(todayKey(),125)});
  spans.sort((a,b)=>a.from.localeCompare(b.from));const merged:typeof spans=[];
  for(const span of spans){const last=merged.at(-1);if(last&&span.from<=shiftDate(last.to,1)){if(span.to>last.to)last.to=span.to;}else merged.push({...span});}
  const ranges:OccurrenceRange[]=[];
  for(const span of merged){let from=span.from;while(from<=span.to){const end=shiftDate(from,125);const to=end<span.to?end:span.to;ranges.push({from,to,displayZone:queryZone});from=shiftDate(to,1);}}
  const sources=snapshot.calendarSources??[];const version=JSON.stringify(sources.map(s=>[s.id,s.revision,s.feedVersion,s.visible]));
  void externalQuery.load(JSON.stringify(ranges),version,sources,async()=>{
    if(!sources.some(s=>s.visible))return {items:[],warnings:[]};
    const results=await Promise.all(ranges.map(range=>command<OccurrenceBatch>('get_calendar_occurrences',{range})));
    return {items:results.flatMap(r=>r.items),warnings:results.flatMap(r=>r.warnings)};
  },()=>{if(editing===undefined)render();else updateChrome();});
}
function showExternal(item:CalendarItem){
  let close=()=>{};
  const content=externalEventDetails(item,()=>{
    close();if(draft){error='有未保存的内容，请先继续编辑或取消';updateChrome();return;}
    draft={item:null,input:copyDayInput(item)};selected=item.date;[year,month]=[Number(selected.slice(0,4)),Number(selected.slice(5,7))-1];editing=null;editingOccurrenceDate=null;render();
  },()=>close(),async input=>{
    const e=item.external!;
    const data=await command<AppSnapshot>('edit_imported_event',{sourceId:e.sourceId,uid:e.uid,recurrenceKey:e.recurrenceKey,input});
    acceptSnapshot(data);
  },viewPrefs().displayZone??Intl.DateTimeFormat().resolvedOptions().timeZone);
  close=mountDialog(content,t('日程详情'));
}
function acceptSnapshot(data:AppSnapshot){
  const languageChanged=getLanguage()!==(data.settings?.language??'zh-CN');
  const oldToday=todayKey();const follow=editing===undefined&&!adding&&selected===oldToday;
  snapshot=data;applyLocale();const today=todayKey();if(follow&&today!==oldToday){selected=today;[year,month]=[Number(today.slice(0,4)),Number(today.slice(5,7))-1];}previousToday=today;
  sourcePanel?.update(data);if(editing===undefined||languageChanged)render();else updateChrome();
}
async function changeView(view:AppSettings['calendarView'],followToday=true){
  const sequence=++viewChangeSequence;overviewFocusToday=false;
  await mutate('set_settings',{settings:{...settings(),calendarView:view}});
  // Old snapshots can redraw while settings are saving. Position only after the
  // requested view has committed, and let any newer date/view choice take priority.
  if(sequence!==viewChangeSequence||settings().calendarView!==view||!followToday||view==='week')return;
  selected=todayKey();[year,month]=[Number(selected.slice(0,4)),Number(selected.slice(5,7))-1];
  overviewFocusToday=true;render();
}
function openSettings(){let close=()=>{};const content=settingsView(settings(),async language=>{const data=await command<AppSnapshot>('set_settings',{settings:{...settings(),language}});acceptSnapshot(data);},()=>close());close=mountDialog(content,t('设置'));}
function openWindowModes(){let close=()=>{};const current=snapshot.window.fullscreen?'fullscreen':snapshot.window.timetableOpen?'timetable':'compact';close=mountDialog(windowModes(current,mode=>{close();void mutate('set_window_mode',{mode});},()=>close()),t('窗口模式'));}
function itemMenu(item:CalendarItem,x:number,y:number){showContextMenu(x,y,t('日程操作'),[{label:t('编辑'),icon:'edit',action:()=>editItem(item)},{label:t('删除'),icon:'trash',action:()=>requestDelete(item)}]);}
const canDrag=()=>!savingDrag&&!savingItem&&!draft&&editing===undefined&&!adding&&!deleting&&!scopeChoice&&!document.querySelector('[data-portal-dialog],.confirm-overlay,:popover-open,[role="menu"]:not([popover])');
async function reschedule(item:CalendarItem,change:DragChange){
  if(!canDrag())return;savingDrag=true;const navigation=viewChangeSequence;
  try{
    const e=item.external;
    if(e)await command<AppSnapshot>('edit_imported_event',{sourceId:e.sourceId,uid:e.uid,recurrenceKey:e.recurrenceKey,input:importedDragInput(item,change,viewPrefs().displayZone??Intl.DateTimeFormat().resolvedOptions().timeZone)});
    else await command<AppSnapshot>('update_item',{id:item.seriesId??item.id,occurrenceDate:item.occurrenceDate??null,input:localDragInput(item,change)});
    if(navigation===viewChangeSequence&&editing===undefined&&!draft){selected=change.date;[year,month]=[Number(selected.slice(0,4)),Number(selected.slice(5,7))-1];overviewFocusToday=false;}
    acceptSnapshot(await command<AppSnapshot>('get_snapshot'));
  }catch(err){showError(err);}finally{savingDrag=false;}
}
function openCalendars(){
  let close=()=>{};
  const receive=async(promise:Promise<AppSnapshot>)=>{const data=await promise;acceptSnapshot(data);return data;};
  sourcePanel=calendarSources(snapshot,{
    close:()=>close(),link:id=>command<string>('get_calendar_link',{id}),inspect:input=>command<PreviewResult>('inspect_calendar',{input}),
    save:(id,input,ticket)=>receive(command<AppSnapshot>('save_subscription',{id,input,ticket:ticket??null})),
    remove:id=>receive(command<AppSnapshot>('remove_subscription',{id})),
    view:prefs=>receive(command<AppSnapshot>('set_calendar_view',{prefs})),
  });
  close=mountDialog(sourcePanel.element,t('日历管理'),()=>{sourcePanel=undefined;});
}

async function mutate(name: string, args: Record<string, unknown>) {
  mutationQueue = mutationQueue.then(async () => {
    try {
      const data=await command<AppSnapshot>(name,args);const languageChanged=getLanguage()!==(data.settings?.language??'zh-CN');snapshot=data;applyLocale();
      error = "";
      if (editing === undefined || name === "set_collapsed" || name === "set_timetable_open" || name==='set_window_mode'||languageChanged) render();
      else updateChrome();
    } catch (e) {
      error = originalError(e);
      if (editing === undefined || name === "set_collapsed" || name === "set_timetable_open" || name==='set_window_mode') render();
      else updateChrome();
    }
  });
  return mutationQueue;
}
function chooseDate(date: string) {
  if(savingItem){error='正在保存，请稍候';updateChrome();return;}
  viewChangeSequence++;
  closeAddMenu();
  adding = undefined;
  selected = date;
  overviewFocusToday=date===todayKey();
  [year, month] = [Number(date.slice(0, 4)), Number(date.slice(5, 7)) - 1];
  editing = undefined;
  deleting = null;
  scopeChoice = null;
  if (snapshot) render();
}
function updateChrome() {
  renderTimetable();
  const pin = root.querySelector<HTMLButtonElement>('[data-action="pin"]');
  if (pin) {
    const label = snapshot.window.pinned ? t("取消置顶") : t("置顶窗口");
    pin.title = label;
    pin.setAttribute("aria-label", label);
    pin.classList.toggle("active", snapshot.window.pinned);
  }
  root.querySelector(".warning")?.remove();
  const text = (error?translateError(error):'') || snapshot.warnings.map(translateError).join(getLanguage()==='en'?'; ':'；');
  if (text) {
    const warning = el("div", "warning", text);
    warning.setAttribute("role", "alert");
    root.querySelector(".toolbar")?.after(warning);
  }
}
function editItem(item: CalendarItem) {
  if(item.external){showExternal(item);return;}
  if (draft && draft.item?.id !== item.id) {
    error = "有未保存的内容，请先继续编辑或取消";
    updateChrome();
    return;
  }
  if (item.seriesId && item.occurrenceDate && !draft) {
    scopeChoice = { action: "edit", item };
    render();
    return;
  }
  beginEdit(item, item.occurrenceDate ?? null);
}
function beginEdit(item: CalendarItem, occurrenceDate: string | null) {
  if(savingItem){error='正在保存，请稍候';updateChrome();return;}
  saveFailure='';
  selected = item.date;
  year = Number(selected.slice(0, 4));
  month = Number(selected.slice(5, 7)) - 1;
  editing = item;
  editingOccurrenceDate = occurrenceDate;
  scopeChoice = null;
  adding = undefined;
  deleting = null;
  render();
}
function requestDelete(item: CalendarItem) {
  if(editing!==undefined||draft){error='有未保存的内容，请先继续编辑或取消';updateChrome();return;}
  adding=undefined;
  deletingAllImported=false;
  deletingRelated=false;
  if ((item.seriesId && item.occurrenceDate)||item.external?.recurring||hasRelated(item)) scopeChoice = { action: "delete", item };
  else { deleting = item; deletingOccurrenceDate = null; }
  render();
}
const hasRelated=(item:CalendarItem)=>!!item.external&&!item.external.recurring&&!!item.external.relatedSlot&&(item.external.relatedCount??0)>1;
function relatedSlotLabel(item:CalendarItem){const slot=item.external?.relatedSlot??'';if(!slot.startsWith('all-day:'))return slot;const days=Number(slot.slice(8));return days>1?t('全天 · {count}天',{count:days}):t('全天');}
function startAdd(kind: ItemKind, context: AddContext) {
  if (draft) {
    error = "有未保存的内容，请先继续编辑或取消";
    updateChrome();
    return;
  }
  selected = context.date;
  year = Number(selected.slice(0, 4));
  month = Number(selected.slice(5, 7)) - 1;
  draft = { item: null, input: {
    kind, title: "", date: context.date, time: kind === "note" ? null : context.time,
    endTime: kind==='note'?null:context.endTime??null, notes: "", reminderMinutes: null, completed: false,
  } };
  adding = undefined;
  deleting = null;
  editing = null;
  editingOccurrenceDate = null;
  error = "";
  render();
}
function renderTimetable() {
  ensureExternal();
  if(leftView){
    const view=leftView.node,body=view.querySelector<HTMLElement>('.overview-body');
    if(body&&view.dataset.scrollKey)overviewScroll.set(view.dataset.scrollKey,body.scrollTop);
    const scroller=view.querySelector<HTMLElement>('.time-scroll');
    if(scroller&&view.dataset.weekKey)timetableScroll.set(view.dataset.weekKey,scroller.scrollTop);
  }
  const open = !!snapshot.window.timetableOpen && !snapshot.window.collapsed;
  shell.classList.toggle("timetable-open", open);
  if (!open) {leftView?.node.remove();leftView=undefined;return;}
  const range=leftRange(),items=displayItems(range.from,range.to);
  // Selection and the minute hand change in place; data/range/locale changes
  // rebuild this view and restore its scroll before the browser can paint it.
  const signature=JSON.stringify([getLanguage(),settings().calendarView,range,todayKey(),viewPrefs().displayZone,items]);
  if(leftView?.key===signature){
    updateCalendarSelection(leftView.node,selected);updateCurrentTime(leftView.node,viewPrefs().displayZone??null);
    positionOverview(leftView.node,false);return;
  }
  const mount=(view:HTMLElement)=>{
    if(leftView)leftView.node.replaceWith(view);else shell.prepend(view);
    leftView={key:signature,node:view};
    updateCalendarSelection(view,selected);
  };
  if(settings().calendarView!=='week'){
    const view=overviewView({view:settings().calendarView as 'month'|'year',selected,year,month,items,today:todayKey(),chooseDate,navigate:delta=>{viewChangeSequence++;overviewFocusToday=false;if(settings().calendarView==='year')year=Math.max(1900,Math.min(9999,year+delta));else({year,month}=shiftMonth(year,month,delta));render();},edit:editItem,add:(context,x,y)=>showAddMenu(x,y,kind=>startAdd(kind,context)),itemMenu,manageCalendars:openCalendars,changeView:view=>void changeView(view),canDrag,reschedule:(item,change)=>void reschedule(item,change),selectMonth:(nextYear,nextMonth)=>{year=nextYear;month=nextMonth;void changeView('month',false);}});
    const key=`${settings().calendarView}|${year}|${settings().calendarView==='month'?month:''}`;
    view.dataset.scrollKey=key;mount(view);positionOverview(view,true);return;
  }
  const key = weekDates(selected)[0];
  const view=timetableView(selected, items, chooseDate, editItem,
    timetableScroll.get(key), value => timetableScroll.set(key, value),
    (context, x, y) => showAddMenu(x, y, kind => startAdd(kind, context)),{zone:viewPrefs().displayZone,onManageCalendars:openCalendars,onItemMenu:itemMenu,onChangeView:view=>void changeView(view),canDrag,onReschedule:(item,change)=>void reschedule(item,change),onCreateRange:(date,time,endTime)=>startAdd('event',{date,time,endTime:endTime==='24:00'?'23:59':endTime})});
  view.dataset.weekKey=key;mount(view);
  const scroller=view.querySelector<HTMLElement>('.time-scroll')!;
  scroller.scrollTop=timetableScroll.get(key)??7*52-10;scroller.dataset.scrollReady='true';
}
function positionOverview(view:HTMLElement,restore:boolean){
  const body=view.querySelector<HTMLElement>('.overview-body');if(!body)return;
  if(restore)body.scrollTop=overviewScroll.get(view.dataset.scrollKey!)??0;
  if(overviewFocusToday){
    const target=view.querySelector<HTMLElement>('.is-today')?.closest<HTMLElement>('.overview-mini-month,.overview-month-cell');
    if(target)body.scrollTop+=target.getBoundingClientRect().top-body.getBoundingClientRect().top-Math.max(0,(body.clientHeight-target.clientHeight)/2);
  }
  overviewFocusToday=false;
}
function render() {
  document.documentElement.classList.toggle('window-fullscreen',!!snapshot.window.fullscreen&&!snapshot.window.collapsed);
  parts.begin();
  const children:HTMLElement[]=[];
  const append=(...nodes:HTMLElement[])=>children.push(...nodes);
  const commit=()=>parts.commit(root,children);
  root.className = snapshot.window.collapsed ? "widget collapsed" : "widget";
  renderTimetable();
  const toolbar=parts.use('toolbar',[getLanguage(),snapshot.window.collapsed,snapshot.window.collapsed?[snapshot.items,externalQuery.items,viewPrefs(),Math.floor(Date.now()/60000)]:null],()=>{
  const toolbar = el("header", "toolbar");
  enableWindowDrag(toolbar, showError);
  const brand = el("div", "brand");
  brand.append(icon("calendar"), el("span", "", t("拾日")));
  const drag = el("div", "drag-area");
  drag.append(brand);
  toolbar.append(drag);
  if (snapshot.window.collapsed) {
    const now = new Date(), today = todayKey();
    const candidates = (viewPrefs().localVisible?snapshot.items:[]).flatMap(item => {
      const next = nextInZone(expandItems([item], today, today), now,viewPrefs().displayZone)
        ?? nextOccurrence(item, shiftDate(today, 1));
      return next ? [next] : [];
    });
    const next = nextInZone([...candidates,...mergeDisplayItems([],externalQuery.items,viewPrefs())],now,viewPrefs().displayZone),
      summary = el("div", "collapsed-summary");
    summary.append(
      el("span", "muted", dateLabel(today)),
      el(
        "span",
        "truncate",
        next ? `${next.time ?? t("待办")}  ${next.title}` : t("今天，也有新的可能"),
      ),
    );
    toolbar.append(summary);
  }
  const controls = el("div", "window-controls");
  if (!snapshot.window.collapsed) {
    controls.append(iconButton('settings',t('设置'),openSettings),iconButton('fullscreen',t('切换窗口模式'),openWindowModes));
    controls.append(iconButton('calendar',t('管理日历'),openCalendars));
    const pin = iconButton(
      "pin",
      snapshot.window.pinned ? t("取消置顶") : t("置顶窗口"),
      () => void mutate("set_pinned", { pinned: !snapshot.window.pinned }),
    );
    pin.dataset.action = "pin";
    pin.classList.toggle("active", snapshot.window.pinned);
    controls.append(pin);
  }
  controls.append(
    iconButton(
      snapshot.window.collapsed ? "up" : "down",
      snapshot.window.collapsed ? t("展开窗口") : t("折叠窗口"),
      () => {
        void mutate("set_collapsed", { collapsed: !snapshot.window.collapsed });
      },
    ),
    iconButton(
      "hide",
      t("隐藏到托盘"),
      () => void command("hide_main").catch(showError),
    ),
  );
  toolbar.append(controls);
  return toolbar;
  });
  const pin=toolbar.querySelector<HTMLButtonElement>('[data-action="pin"]');
  if(pin){const label=snapshot.window.pinned?t('取消置顶'):t('置顶窗口');pin.title=label;pin.setAttribute('aria-label',label);pin.classList.toggle('active',snapshot.window.pinned);}
  append(toolbar);
  if (snapshot.window.collapsed) {commit();return;}
  const toggle=parts.use('toggle',[getLanguage(),snapshot.window.timetableOpen],()=>iconButton(
    snapshot.window.timetableOpen ? "right" : "left",
    snapshot.window.timetableOpen ? t("收起周时间表") : t("展开周时间表"),
    () => void mutate("set_timetable_open", { open: !snapshot.window.timetableOpen }),
  ));
  toggle.classList.add("timetable-toggle");
  toggle.setAttribute("aria-expanded", String(!!snapshot.window.timetableOpen));
  append(toggle);
  if (error || snapshot.warnings.length || externalQuery.warnings.length) {
    const warning = el("div", "warning", (error?translateError(error):'') || snapshot.warnings.map(translateError).join(getLanguage()==='en'?'; ':'；') || externalQuery.warnings.map(w=>translateError(w.message)).join(getLanguage()==='en'?'; ':'；'));
    warning.setAttribute("role", "alert");
    append(warning);
  }
  if (adding) {
    const context = adding;
    append(parts.use('add',[getLanguage(),context],()=>addView(kind => startAdd(kind, context), () => {
      adding = undefined;
      render();
    })));
    commit();return;
  }
  if (editing !== undefined) {
    const current = editing;
    const occurrenceDate = editingOccurrenceDate;
    append(
      parts.use('editor',[getLanguage(),current?.id??null,selected,occurrenceDate,savingItem,saveFailure],()=>eventForm(
        selected,
        current,
        async (input: ItemInput) => {
          if(savingItem)return;
          savingItem=true;saveFailure='';
          try {
          await command<AppSnapshot>(
            current ? "update_item" : "create_item",
            current ? { id: current.seriesId ?? current.id, input, occurrenceDate } : { input },
          );
          snapshot=await command<AppSnapshot>('get_snapshot');applyLocale();
          selected = input.date;
          year = Number(selected.slice(0, 4));
          month = Number(selected.slice(5, 7)) - 1;
          editing = undefined;
          draft = undefined;
          editingOccurrenceDate = null;
          error = "";
          } catch(error){saveFailure=originalError(error);throw error;}finally{savingItem=false;render();}
        },
        () => {
          if(savingItem)return;
          editing = undefined;
          draft = undefined;
          editingOccurrenceDate = null;
          saveFailure='';
          render();
        },
        draft?.input,
        (input, recurrenceDraft) => {
          draft = { item: current, input, occurrenceDate, recurrenceDraft };
        },
        occurrenceDate ? "occurrence" : current?.recurrence ? "series" : undefined,
        draft?.recurrenceDraft,
        {pending:savingItem,error:saveFailure},
      )),
    );
    commit();return;
  }
  const grid=buildMonthGrid(year,month),calendarItems=displayItems(grid[0],grid[41]);
  const calendar=parts.use('calendar',[getLanguage(),year,month,todayKey(),calendarItems],()=>calendarView(
      year,
      month,
      selected,
      calendarItems,
      (delta) => {
        viewChangeSequence++;overviewFocusToday=false;
        ({ year, month } = shiftMonth(year, month, delta));
        render();
      },
      () => chooseDate(todayKey()),
      chooseDate,
      todayKey(),
    ));
  updateCalendarSelection(calendar,selected);append(calendar);
  const agendaItems=displayItems(selected,selected);
  const oldAgenda=root.querySelector<HTMLElement>('.agenda');
  const oldList=oldAgenda?.dataset.date===selected?oldAgenda.querySelector<HTMLElement>('.agenda-list'):null;
  const agenda=parts.use('agenda',[getLanguage(),selected,todayKey(),agendaItems],()=>agendaView(
      selected,
      agendaItems,
      (item) =>
        void mutate("set_completed", {
          id: item.seriesId ?? item.id,
          completed: !item.completed,
          occurrenceDate: item.occurrenceDate ?? null,
        }),
      editItem,
      requestDelete,
      todayKey(),
    ));
  agenda.dataset.date=selected;append(agenda);
  const footer=parts.use('footer',[getLanguage(),!!draft],()=>{
  const footer = el("footer", "footer"),
    add = button(
      draft ? t("继续编辑") : t("添加"),
      "primary-button add-button",
      () => {
        if (draft) { editing = draft.item; editingOccurrenceDate = draft.occurrenceDate ?? null; }
        else adding = { date: selected, time: null };
        render();
      },
    );
  add.prepend(icon("plus"));
  footer.append(add, el("span", "shortcut", t("Ctrl+Alt+C 显示 / 隐藏")));
  return footer;
  });
  append(footer);
  if (scopeChoice) {
    const { action, item } = scopeChoice;
    append(scopeDialog(action, item.title, item.occurrenceDate??item.date, single => {
      scopeChoice = null;
      if(item.external&&action==='delete'){deleting=item;deletingOccurrenceDate=null;deletingRelated=!single&&hasRelated(item);deletingAllImported=!single&&!deletingRelated;render();return;}
      const target = single ? item : snapshot.items.find(base => base.id === item.seriesId);
      if (!target) { error = "这个重复系列已不存在"; render(); return; }
      const occurrenceDate = single ? item.occurrenceDate! : null;
      if (action === "edit") beginEdit(target, occurrenceDate);
      else { deleting = target; deletingOccurrenceDate = occurrenceDate; render(); }
    }, () => { scopeChoice = null; render(); },hasRelated(item)?{allLabel:t('此安排的全部重复（{count}项）',{count:item.external!.relatedCount!}),hint:t('按原课表标题“{title}”和时段 {slot} 匹配，共 {count} 项。其他时段同名安排保留。',{title:item.external!.relatedTitle??item.title,slot:relatedSlotLabel(item),count:item.external!.relatedCount!})}:{}));
  }
  if (deleting) {
    const overlay = el("div", "confirm-overlay"),
      dialog = el("div", "confirm-dialog");
    dialog.setAttribute("role", "alertdialog");
    dialog.setAttribute("aria-label", t("删除日程"));
    dialog.append(
      el("h2", "", deletingRelated?t('删除此安排的全部重复？'):deletingAllImported||deleting.recurrence?t("删除整个重复系列？"):deletingOccurrenceDate||deleting.external?t("删除本次安排？"):t("删除这条日程？")),
      el("p", "truncate", deleting.title),
    );
    if(deleting.external)dialog.append(el('p','field-hint',deletingRelated?t('仅删除本日历中原始标题“{title}”、原始时段 {slot} 的 {count} 项重复安排，包含本地改名或改期的记录。其他时段和其他日历保留。',{title:deleting.external.relatedTitle??deleting.title,slot:relatedSlotLabel(deleting),count:deleting.external.relatedCount!}):t(deletingAllImported?'仅在拾日删除此日历中该日程的所有重复，不更改来源日历。重新导入可恢复。':'仅从拾日删除这次导入安排，不更改来源日历。重新导入可恢复。')));
    const actions = el("div", "form-actions");
    actions.append(
      button(t("保留"), "secondary-button", () => {
        deleting = null;
        render();
      }),
      button(t("确认删除"), "primary-button", () => {
        if (!deleting) return;
        const id = deleting.seriesId ?? deleting.id;
        const occurrenceDate = deletingOccurrenceDate;
        const external=deleting.external;
        const allOccurrences=deletingAllImported;deletingAllImported=false;
        const allRelated=deletingRelated;deletingRelated=false;
        deleting = null;
        overlay.remove();
        void (external?mutate('delete_imported_event',{sourceId:external.sourceId,uid:external.uid,recurrenceKey:external.recurrenceKey,allOccurrences,allRelated}):mutate("delete_item", { id, occurrenceDate }));
      }),
    );
    dialog.append(actions);
    overlay.append(dialog);
    append(overlay);
    requestAnimationFrame(() => dialog.querySelector("button")?.focus());
  }
  const listScroll=oldList?.scrollTop??0;
  commit();
  if(oldList&&!oldList.isConnected)agenda.querySelector<HTMLElement>('.agenda-list')!.scrollTop=listScroll;
}
function showError(e: unknown) {
  error = originalError(e);
  if (snapshot) render();
}
try {
  await subscribe<AppSnapshot>("calendar://state-changed", (data) => {
    acceptSnapshot(data);
  });
  await subscribe<string>("calendar://select-date", chooseDate);
  snapshot = await command<AppSnapshot>("get_snapshot");
  applyLocale();
  if(selected===previousToday){selected=todayKey();previousToday=selected;[year,month]=[Number(selected.slice(0,4)),Number(selected.slice(5,7))-1];}
  render();
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!event.defaultPrevented&&snapshot.window.fullscreen&&!snapshot.window.collapsed&&!document.querySelector('[data-portal-dialog],.confirm-overlay,:popover-open,[role="menu"]:not([popover])')){event.preventDefault();void mutate('set_window_mode',{mode:snapshot.window.restoreTimetableOpen?'timetable':'compact'});}});
  setInterval(() => {
    ensureExternal();
    const today = todayKey();
    if (editing === undefined && !deleting && !scopeChoice) {
      if (selected === previousToday && today !== previousToday)
        chooseDate(today);
      else render();
    } else renderTimetable();
    previousToday = today;
  }, 60000);
} catch (e) {
  root.append(el("div", "startup-error", t('暂时无法打开拾日：{error}',{error:translateError(e)})));
}
