// Browser-only development adapter. Desktop always uses Rust storage.
import type { AppSnapshot, ItemInput } from "./model.ts";
import { occurrenceForDate, validDate, validRecurrence } from "./recurrence.ts";
import type {ExternalOccurrence,CalendarSourceSummary} from './subscriptions.ts';
import {clockInZone} from './clock.ts';
import {shiftDate} from './timetable.ts';
import {inspectPreview,applySubscriptionPreview,originalTitlePreview,originalSlotPreview,relatedMetadataPreview} from './preview-subscriptions.ts';
import {editImportedPreview} from './preview-imports.ts';
import type {SourceInput} from './subscriptions.ts';
const key = "shiri-browser-preview";
let state: AppSnapshot & {externalItems?:ExternalOccurrence[];previewLinks?:Record<string,string>} = JSON.parse(localStorage.getItem(key) ?? "null") ?? {
  items: [],
  window: { x: null, y: null, pinned: true, collapsed: false },
  warnings: [],
};
state.calendarSources??=[];state.calendarView??={displayZone:null,localVisible:true};state.settings??={language:'zh-CN',calendarView:'week'};
function snapshot():AppSnapshot{return structuredClone({items:state.items,window:state.window,warnings:state.warnings,calendarSources:state.calendarSources,calendarView:state.calendarView,settings:state.settings});}

function validateInput(input: ItemInput): void {
  if (!input || !validDate(input.date)) throw new Error("日期无效");
  if (input.recurrence != null) {
    if (!validRecurrence(input.recurrence)) throw new Error("重复规则无效");
    if (input.kind === "note") throw new Error("便签不能重复");
    if (input.completed) throw new Error("重复事项请逐次完成");
    if (input.recurrence.until && input.recurrence.until < input.date) throw new Error("结束日期不能早于开始日期");
  }
}
export async function command<T>(
  name: string,
  args: Record<string, unknown>,
): Promise<T> {
  if (name === "get_snapshot") return snapshot() as T;
  if(name==='get_language')return state.settings!.language as T;
  if(name==='inspect_calendar')return await inspectPreview(args.input as SourceInput) as T;
  if(name==='get_calendar_link')return '' as T;
  if(name==='get_calendar_occurrences'){
    const r=args.range as {from:string;to:string;displayZone:string|null};const sources=new Map((state.calendarSources??[]).filter(s=>s.visible).map(s=>[s.id,s]));const items:ExternalOccurrence[]=[];
    for(const item of relatedMetadataPreview(state)){const source=sources.get(item.sourceId);if(!source)continue;
      if(item.allDay||!item.startUtc||!item.endUtc){const first=item.startDate||item.date,last=item.endDate||item.date;let day=first>r.from?first:r.from;while(day<=last&&day<=r.to){items.push({...item,date:day,time:null,endTime:null,continuedBefore:day>first,continuesAfter:day<last,color:source.color,sourceName:source.name});day=shiftDate(day,1);}continue;}
      const start=clockInZone(new Date(item.startUtc),r.displayZone),end=clockInZone(new Date(item.endUtc),r.displayZone);let day=start.date>r.from?start.date:r.from;
      const last=(end.hour===0&&end.minute===0&&end.date>start.date)?shiftDate(end.date,-1):end.date;
      while(day<=last&&day<=r.to){items.push({...item,date:day,time:day===start.date?`${String(start.hour).padStart(2,'0')}:${String(start.minute).padStart(2,'0')}`:'00:00',endTime:day<end.date?'24:00':`${String(end.hour).padStart(2,'0')}:${String(end.minute).padStart(2,'0')}`,continuedBefore:day>start.date,continuesAfter:day<last,color:source.color,sourceName:source.name});day=shiftDate(day,1);}
    }
    return {items,warnings:[]} as T;
  }
  if (localStorage.getItem("shiri-preview-fail-next")) {
    localStorage.removeItem("shiri-preview-fail-next");
    throw new Error("磁盘写入失败（预览测试）");
  }
  if(['create_item','update_item'].includes(name)&&localStorage.getItem('shiri-preview-save-delay')){
    const delay=Number(localStorage.getItem('shiri-preview-save-delay'));localStorage.removeItem('shiri-preview-save-delay');await new Promise(resolve=>setTimeout(resolve,Math.max(0,Math.min(5000,delay))));
  }
  if(name==='edit_imported_event'){state=editImportedPreview(state,args);localStorage.setItem(key,JSON.stringify(state));return snapshot() as T;}
  if(name==='delete_imported_event'){
    if(args.allOccurrences===true&&args.allRelated===true)throw new Error('请选择一种删除范围');
    const next=structuredClone(state);const source=next.calendarSources?.find(s=>s.id===args.sourceId);if(!source)throw new Error('日历已移除');
    const selected=(e:ExternalOccurrence)=>e.sourceId===args.sourceId&&e.uid===args.uid&&e.recurrenceKey===args.recurrenceKey;
    const item=next.externalItems?.find(selected);if(!item)throw new Error('导入安排已不存在');
    const title=originalTitlePreview(next,item);
    const slot=originalSlotPreview(next,item);
    const related=(e:ExternalOccurrence)=>e.sourceId===args.sourceId&&!e.recurring&&!!title.trim()&&originalTitlePreview(next,e)===title&&originalSlotPreview(next,e)===slot;
    if(args.allRelated===true&&(item.recurring||new Set(next.externalItems!.filter(related).map(e=>e.uid)).size<2))throw new Error('没有可一起删除的相同时段安排，请重新打开');
    const same=(e:ExternalOccurrence)=>args.allRelated===true?related(e):e.sourceId===args.sourceId&&e.uid===args.uid&&(args.allOccurrences===true||e.recurrenceKey===args.recurrenceKey);
    next.externalItems=next.externalItems!.filter(e=>!same(e));source.revision++;state=next;localStorage.setItem(key,JSON.stringify(state));return snapshot() as T;
  }
  if(['save_subscription','remove_subscription','refresh_calendar','set_calendar_view'].includes(name)){
    state=applySubscriptionPreview(name,args,state);localStorage.setItem(key,JSON.stringify(state));
    if(name==='refresh_calendar')window.dispatchEvent(new CustomEvent('calendar://state-changed',{detail:snapshot()}));
    return snapshot() as T;
  }
  const next = structuredClone(state),
    now = new Date().toISOString();
  if(name==='set_settings'){
    const prefs=args.settings as AppSnapshot['settings'];if(!prefs||!['zh-CN','en'].includes(prefs.language)||!['week','month','year'].includes(prefs.calendarView))throw new Error('设置无效');
    next.settings=prefs;window.dispatchEvent(new CustomEvent('calendar://language-changed',{detail:prefs.language}));
  }
  if(name==='set_window_mode'){
    const mode=String(args.mode);if(!['compact','timetable','fullscreen'].includes(mode))throw new Error('窗口模式无效');
    if(mode==='fullscreen'&&!next.window.fullscreen)next.window.restoreTimetableOpen=!!next.window.timetableOpen;
    next.window.fullscreen=mode==='fullscreen';next.window.timetableOpen=mode!=='compact';next.window.collapsed=false;
  }
  if (name === "create_item") {
    validateInput(args.input as ItemInput);
    next.items.push({
      ...(args.input as ItemInput),
      id: crypto.randomUUID(),
      createdAt: now,
      updatedAt: now,
    });
  }
  if (["update_item", "delete_item", "set_completed"].includes(name)) {
    const target = next.items.find(item => item.id === args.id);
    if (!target) throw new Error("事项不存在");
    const nominal = args.occurrenceDate;
    if (nominal != null && typeof nominal !== "string") throw new Error("重复日期无效");
    if (name === "set_completed" && typeof args.completed !== "boolean") throw new Error("完成状态无效");
    if (nominal != null) {
      if (!occurrenceForDate(target, nominal as string)) throw new Error("重复事项不存在");
      const exception = { ...target.exceptions?.[nominal as string] };
      if (name === "update_item") {
        const input = args.input as ItemInput;
        validateInput(input);
        if (input.recurrence != null) throw new Error("单次事项不能包含重复规则");
        exception.input = { ...input, recurrence: null };
        // A subsequent edit may change the occurrence's completion checkbox.
        exception.completed = input.completed;
      }
      if (name === "delete_item") exception.deleted = true;
      if (name === "set_completed") exception.completed = args.completed as boolean;
      target.exceptions = { ...target.exceptions, [nominal as string]: exception };
      target.updatedAt = now;
    } else if (name === "update_item") {
      const input = args.input as ItemInput;
      validateInput(input);
      Object.assign(target, input, { updatedAt: now });
      if (!input.recurrence) delete target.exceptions;
      else if (target.exceptions) {
        const unmodified = { ...target, exceptions: undefined };
        target.exceptions = Object.fromEntries(Object.entries(target.exceptions)
          .filter(([date]) => occurrenceForDate(unmodified, date)));
      }
    } else if (name === "delete_item") {
      next.items = next.items.filter(item => item.id !== args.id);
    } else {
      if (target.recurrence) throw new Error("重复事项请逐次完成");
      target.completed = args.completed as boolean;
      target.updatedAt = now;
    }
  }
  if (name === "set_timetable_open") {next.window.timetableOpen = args.open as boolean;next.window.fullscreen=false;}
  if (name === "set_pinned") next.window.pinned = args.pinned as boolean;
  if (name === "set_collapsed")
    next.window.collapsed = args.collapsed as boolean;
  state = next;
  localStorage.setItem(key, JSON.stringify(state));
  return snapshot() as T;
}
