import { formatDate } from './i18n.ts';
import type { CalendarItem } from "./model.ts";
export function localDateKey(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
export function buildMonthGrid(year: number, monthIndex: number): string[] {
  const first = new Date(year, monthIndex, 1, 12);
  const offset = (first.getDay() + 6) % 7;
  return Array.from({ length: 42 }, (_, i) =>
    localDateKey(new Date(year, monthIndex, 1 - offset + i, 12)),
  );
}
export function shiftMonth(year: number, month: number, delta: number) {
  const target = new Date(year, month + delta, 1, 12);
  return { year: target.getFullYear(), month: target.getMonth() };
}
export function sortItems(items: CalendarItem[]): CalendarItem[] {
  return [...items].sort(
    (a, b) =>
      Number(a.completed) - Number(b.completed) ||
      (a.time ?? "99:99").localeCompare(b.time ?? "99:99") ||
      a.createdAt.localeCompare(b.createdAt),
  );
}
export function nextItem(
  items: CalendarItem[],
  now = new Date(),
): CalendarItem | undefined {
  const today = localDateKey(now);
  const time = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  return [...items]
    .filter(
      (x) =>
        !x.completed &&
        (x.date > today || (x.date === today && (!x.time || x.time >= time))),
    )
    .sort(
      (a, b) =>
        a.date.localeCompare(b.date) ||
        (a.time ?? "99:99").localeCompare(b.time ?? "99:99"),
    )[0];
}
export function dateLabel(date: string): string {
  return formatDate(date);
}
