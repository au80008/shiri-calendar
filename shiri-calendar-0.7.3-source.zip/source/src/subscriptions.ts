import type {CalendarItem,ItemInput} from './model.ts';
export interface CalendarViewPrefs {displayZone:string|null;localVisible:boolean}
export interface CalendarSourceSummary {id:string;name:string;host:string;color:string;visible:boolean;fallbackZone:string;overrideUnknownZone:boolean;reminderMinutes:number|null;revision:number;feedVersion:number;eventCount:number;lastAttemptAt:string|null;lastSuccessAt:string|null;lastError:string|null;refreshing:boolean}
export interface SourceInput {name:string;url:string;color:string;visible:boolean;fallbackZone:string;overrideUnknownZone:boolean;reminderMinutes:number|null}
export interface OccurrenceRange {from:string;to:string;displayZone:string|null}
export interface ExternalOccurrence {id:string;sourceId:string;sourceName:string;color:string;uid:string;recurrenceKey:string;startUtc:string|null;endUtc:string|null;allDay:boolean;date:string;time:string|null;endTime:string|null;title:string;description:string;location:string;continuedBefore:boolean;continuesAfter:boolean;startDate?:string;endDate?:string;locallyEdited?:boolean;recurring?:boolean;relatedTitle?:string|null;relatedSlot?:string|null;relatedCount?:number}
export interface ImportedInput {title:string;description:string;location:string;startDate:string;endDate:string;startTime:string|null;endTime:string|null;allDay:boolean;displayZone:string}
export interface OccurrenceBatch {items:ExternalOccurrence[];warnings:{sourceId:string;message:string}[]}
export interface PreviewResult {ticket:string;canonicalHost:string;calendarName:string|null;eventCount:number;unsupportedCount:number;firstDate:string|null;lastDate:string|null;samples:{title:string;date:string;time:string|null;location:string}[];warnings:string[]}
export type DisplayItem=CalendarItem;
export const sourceColors=['#5594c8','#7b8f65','#9d7abb','#c99c49','#d27b91','#ed714e'];
export const defaultView:CalendarViewPrefs={displayZone:null,localVisible:true};
export function toDisplayItems(items:ExternalOccurrence[]):DisplayItem[]{return items.map(external=>({id:`${external.id}@${external.date}`,kind:'event',title:external.title,date:external.date,time:external.time,endTime:external.endTime,notes:external.description,reminderMinutes:null,completed:false,createdAt:'',updatedAt:'',external}));}
export function mergeDisplayItems(local:CalendarItem[],external:ExternalOccurrence[],prefs:CalendarViewPrefs):DisplayItem[]{return [...(prefs.localVisible?local:[]),...toDisplayItems(external)];}
export function copyDayInput(item:DisplayItem):ItemInput {
 const e=item.external;
 const end=item.endTime==='24:00'?'23:59':item.endTime??null;
 return {kind:'event',title:item.title,date:item.date,time:item.time,endTime:end&&item.time&&end>item.time?end:null,notes:[e?.description,e?.location?`地点：${e.location}`:'',e?.sourceName?`来自：${e.sourceName}${e.continuedBefore||e.continuesAfter?'（仅复制当天安排）':''}`:''].filter(Boolean).join('\n'),reminderMinutes:null,completed:false,recurrence:null};
}
export class ExternalQuery {
 items:ExternalOccurrence[]=[];warnings:OccurrenceBatch['warnings']=[];loading=false;
 private generation=0;private requestKey='';private rangeKey='';private cache=new Map<string,ExternalOccurrence[]>();
 async load(rangeKey:string,version:string,sources:CalendarSourceSummary[],fetcher:()=>Promise<OccurrenceBatch>,changed:()=>void=()=>{}):Promise<void>{
  const key=JSON.stringify([rangeKey,version]);if(key===this.requestKey)return;
  const gen=++this.generation;this.requestKey=key;
  const visible=new Set(sources.filter(s=>s.visible).map(s=>s.id));
  const previous=(this.rangeKey===rangeKey?this.items:this.cache.get(rangeKey)??[]).filter(i=>visible.has(i.sourceId));
  this.items=previous;this.rangeKey=rangeKey;this.warnings=[];this.loading=true;
  try {
   const batch=await fetcher();if(gen!==this.generation)return;
   const failed=new Set(batch.warnings.map(w=>w.sourceId));
   const merged=[...batch.items.filter(i=>visible.has(i.sourceId)&&!failed.has(i.sourceId)),...previous.filter(i=>failed.has(i.sourceId))];
   this.items=[...new Map(merged.map(i=>[`${i.id}@${i.date}`,i])).values()];this.warnings=batch.warnings;
   this.cache.delete(rangeKey);this.cache.set(rangeKey,this.items);while(this.cache.size>3)this.cache.delete(this.cache.keys().next().value!);
  }catch(e){if(gen!==this.generation)return;this.items=previous;this.warnings=[{sourceId:'',message:String(e)}];}
  if(gen===this.generation){this.loading=false;changed();}
 }
}
