// Browser QA adapter; desktop validation and persistence are in Rust.
import {clockInZone} from './clock.ts';
import {validDate} from './recurrence.ts';
import {validTime} from './ui/temporal-control.ts';
import type {ImportedInput,ExternalOccurrence} from './subscriptions.ts';
import type {PreviewProfile} from './preview-subscriptions.ts';
export function wallInstant(day:string,time:string,zone:string):Date {
 const nominal=Date.parse(`${day}T${time}:00Z`);let instant=nominal;
 for(let i=0;i<4;i++){const c=clockInZone(new Date(instant),zone);const projected=Date.parse(`${c.date}T${String(c.hour).padStart(2,'0')}:${String(c.minute).padStart(2,'0')}:00Z`);instant+=nominal-projected;}
 const matches=(at:number)=>{const c=clockInZone(new Date(at),zone);return c.date===day&&`${String(c.hour).padStart(2,'0')}:${String(c.minute).padStart(2,'0')}`===time;};
 if(!matches(instant)||matches(instant-3600000)||matches(instant+3600000))throw new Error('时间处于夏令时缺失或重复时段，请调整时间');
 return new Date(instant);
}
export function editImportedPreview(profile:PreviewProfile,args:Record<string,unknown>):PreviewProfile {
 const next=structuredClone(profile);const source=next.calendarSources?.find(s=>s.id===args.sourceId);if(!source)throw new Error('日历已移除');
 const same=(e:ExternalOccurrence)=>e.sourceId===args.sourceId&&e.uid===args.uid&&e.recurrenceKey===args.recurrenceKey;
 const item=next.externalItems?.find(same);if(!item)throw new Error('导入安排已不存在');
 next.importedOriginals??={};const key=JSON.stringify([args.sourceId,args.uid,args.recurrenceKey]);
 if(args.input===null){const original=next.importedOriginals[key];if(original){Object.assign(item,original);delete next.importedOriginals[key];}}
 else {
  const input=args.input as ImportedInput;
  if(!input.title.trim()||input.title.length>120)throw new Error('日程名称需为 1–120 字');
  if(input.description.length>2000||input.location.length>300)throw new Error('备注或地点过长');
  if(!validDate(input.startDate)||!validDate(input.endDate)||input.endDate<input.startDate)throw new Error('起止日期无效');
  let start:string|null=null,end:string|null=null;
  if(!input.allDay){if(!validTime(input.startTime??'')||!validTime(input.endTime??''))throw new Error('请填写开始和结束时间');start=wallInstant(input.startDate,input.startTime!,input.displayZone).toISOString();end=wallInstant(input.endDate,input.endTime!,input.displayZone).toISOString();if(end<start)throw new Error('结束时间不能早于开始时间');}
  next.importedOriginals[key]??=structuredClone(item);
  Object.assign(item,{title:input.title.trim(),description:input.description,location:input.location,startDate:input.startDate,endDate:input.endDate,date:input.startDate,startUtc:start,endUtc:end,time:input.startTime,endTime:input.endTime,allDay:input.allDay,locallyEdited:true});
 }
 source.revision++;return next;
}
