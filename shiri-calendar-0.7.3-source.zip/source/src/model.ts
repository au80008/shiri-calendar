export type ItemKind = "event" | "note" | "task";
import type {ExternalOccurrence,CalendarSourceSummary,CalendarViewPrefs} from './subscriptions.ts';
export interface Recurrence {
  frequency: "daily" | "weekly" | "monthly" | "yearly";
  interval: number;
  weekdays?: number[]; // ISO weekdays: Monday=1, Sunday=7; weekly rules only.
  until?: string | null; // Inclusive civil date. Mutually exclusive with count.
  count?: number | null; // Planned valid dates, before deleted/moved exceptions.
}
export interface OccurrenceException {
  deleted?: boolean;
  completed?: boolean | null;
  input?: ItemInput | null; // Overrides have recurrence=null.
}
export interface CalendarItem {
  kind?: ItemKind;
  id: string;
  title: string;
  date: string;
  time: string | null;
  endTime?: string | null;
  notes: string;
  reminderMinutes: number | null;
  completed: boolean;
  createdAt: string;
  updatedAt: string;
  recurrence?: Recurrence | null;
  exceptions?: Record<string, OccurrenceException>;
  seriesId?: string | null;
  occurrenceDate?: string | null; // Original scheduled date, even if moved.
  external?: ExternalOccurrence;
}
export type ItemInput = Omit<CalendarItem, "id" | "createdAt" | "updatedAt" | "exceptions" | "seriesId" | "occurrenceDate" | "external">;
export interface WindowPrefs {
  x: number | null;
  y: number | null;
  pinned: boolean;
  collapsed: boolean;
  timetableOpen?: boolean;
  fullscreen?: boolean;
  restoreRight?:number|null;
  restoreTop?:number|null;
  restoreTimetableOpen?:boolean;
}
export interface AppSettings {language:'zh-CN'|'en';calendarView:'week'|'month'|'year'}
export interface AppSnapshot {
  items: CalendarItem[];
  window: WindowPrefs;
  warnings: string[];
  calendarSources?: CalendarSourceSummary[];
  calendarView?: CalendarViewPrefs;
  settings?:AppSettings;
}
export interface Reminder {
  key: string;
  item: CalendarItem;
}
