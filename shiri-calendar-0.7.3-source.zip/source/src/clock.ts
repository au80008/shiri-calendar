const formatters = new Map<string, Intl.DateTimeFormat>();
export function clockInZone(now: Date, zone: string | null = null): {date:string;hour:number;minute:number} {
  const resolvedZone=zone ?? Intl.DateTimeFormat().resolvedOptions().timeZone;
  const key=resolvedZone;
  let formatter=formatters.get(key);
  if (!formatter) {
    formatter=new Intl.DateTimeFormat('en-CA',{timeZone:resolvedZone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
    formatters.set(key,formatter);
  }
  const parts=Object.fromEntries(formatter.formatToParts(now).map(p=>[p.type,p.value]));
  return {date:`${parts.year}-${parts.month}-${parts.day}`,hour:Number(parts.hour),minute:Number(parts.minute)};
}
export function dateKeyInZone(now: Date,zone:string|null=null): string {return clockInZone(now,zone).date;}
export function nextInZone<T extends {date:string;time:string|null;completed:boolean}>(items:T[],now:Date,zone:string|null): T|undefined {
  const clock=clockInZone(now,zone);const time=`${String(clock.hour).padStart(2,'0')}:${String(clock.minute).padStart(2,'0')}`;
  return items.filter(i=>!i.completed&&(i.date>clock.date||(i.date===clock.date&&(!i.time||i.time>=time)))).sort((a,b)=>a.date.localeCompare(b.date)||(a.time??'99:99').localeCompare(b.time??'99:99'))[0];
}
