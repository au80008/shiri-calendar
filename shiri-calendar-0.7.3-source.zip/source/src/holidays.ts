import { Solar } from "lunar-typescript";

export interface Holiday {
  country: "CN" | "DK";
  name: string;
  localName?: string;
}

const DAY_MS = 86_400_000;
const CHINESE_SOLAR: Record<string, string> = {
  "1-1": "元旦", "5-1": "劳动节", "10-1": "国庆节",
};
const CHINESE_LUNAR: Record<string, string> = {
  "1-1": "春节", "1-15": "元宵节", "5-5": "端午节", "8-15": "中秋节",
};
const DANISH_FIXED: Record<string, [string, string]> = {
  "1-1": ["新年", "Nytårsdag"],
  "12-25": ["圣诞节", "Juledag"],
  "12-26": ["圣诞节翌日", "2. juledag"],
};
const DANISH_EASTER: Record<number, [string, string]> = {
  [-3]: ["圣周四", "Skærtorsdag"],
  [-2]: ["耶稣受难日", "Langfredag"],
  0: ["复活节", "Påskedag"],
  1: ["复活节翌日", "2. påskedag"],
  39: ["耶稣升天节", "Kristi himmelfartsdag"],
  49: ["圣灵降临节", "Pinsedag"],
  50: ["圣灵降临节翌日", "2. pinsedag"],
};

// Gregorian ecclesiastical computus, as published by the US Naval Observatory.
function easterUtc(year: number): number {
  const century = Math.floor(year / 100);
  const golden = year % 19;
  const correction = Math.floor((century - 17) / 25);
  let epact = century - Math.floor(century / 4)
    - Math.floor((century - correction) / 3) + 19 * golden + 15;
  epact %= 30;
  epact -= Math.floor(epact / 28) * (1 - Math.floor(epact / 28)
    * Math.floor(29 / (epact + 1)) * Math.floor((21 - golden) / 11));
  const weekday = (year + Math.floor(year / 4) + epact + 2
    - century + Math.floor(century / 4)) % 7;
  const offset = epact - weekday;
  const month = 3 + Math.floor((offset + 40) / 44);
  const day = offset + 28 - 31 * Math.floor(month / 4);
  return Date.UTC(year, month - 1, day);
}

/**
 * Festival dates for civil YYYY-MM-DD values in 1900–2100, inclusive.
 * Chinese dates use the traditional calendar's China civil dates, independent
 * of the device timezone. These labels do not describe leave or makeup workdays.
 * Invalid or unsupported dates return an empty list. See docs/holidays-sources.md.
 */
export function holidaysForDate(date: string): Holiday[] {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return [];
  const [year, month, day] = date.split("-").map(Number);
  if (year < 1900 || year > 2100 || month < 1 || month > 12 || day < 1) return [];
  const utc = Date.UTC(year, month - 1, day);
  if (new Date(utc).getUTCMonth() !== month - 1) return [];

  const holidays: Holiday[] = [];
  const solarKey = `${month}-${day}`;
  const fixedChinese = CHINESE_SOLAR[solarKey];
  if (fixedChinese) holidays.push({ country: "CN", name: fixedChinese });

  // Pass calendar fields directly: converting a JS Date would involve the host timezone.
  const solar = Solar.fromYmd(year, month, day);
  const lunar = solar.getLunar();
  // 6tail represents leap months as negative numbers, so they cannot match these keys.
  const lunarFestival = CHINESE_LUNAR[`${lunar.getMonth()}-${lunar.getDay()}`];
  if (lunarFestival) holidays.push({ country: "CN", name: lunarFestival });
  if (lunar.getMonth() === 12 && lunar.getDay() >= 29) {
    const tomorrow = solar.next(1).getLunar();
    if (tomorrow.getMonth() === 1 && tomorrow.getDay() === 1) {
      holidays.push({ country: "CN", name: "除夕" });
    }
  }
  if (lunar.getJieQi() === "清明") holidays.push({ country: "CN", name: "清明节" });

  const danish = DANISH_FIXED[solarKey] ?? DANISH_EASTER[(utc - easterUtc(year)) / DAY_MS];
  if (danish) holidays.push({ country: "DK", name: danish[0], localName: danish[1] });
  return holidays;
}
