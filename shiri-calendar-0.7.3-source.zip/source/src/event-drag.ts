import type {CalendarItem,ItemInput} from './model.ts';
import type {ImportedInput} from './subscriptions.ts';
import {clockInZone} from './clock.ts';
import {clockTime,eventRange,minutes} from './timetable.ts';

export interface DragChange {mode:'move'|'resize';date:string;time?:string;endTime?:string}

export function localDragInput(item:CalendarItem,change:DragChange):ItemInput {
 let time=item.time,endTime=item.endTime??null;
 if(change.mode==='resize')endTime=change.endTime!;
 else if(change.time!==undefined&&item.time){time=change.time;endTime=clockTime(Math.min(1440,minutes(time)+eventRange(item).end-eventRange(item).start));}
 if(endTime==='24:00')endTime=time==='23:59'?null:'23:59';
 return {kind:item.kind??'event',title:item.title,date:change.date,time,endTime,notes:item.notes,reminderMinutes:item.reminderMinutes,completed:item.completed,recurrence:item.seriesId?null:item.recurrence??null};
}
const dayDifference=(first:string,last:string)=>(Date.parse(`${last}T00:00:00Z`)-Date.parse(`${first}T00:00:00Z`))/86400000;
function shiftWall(date:string,time:string,delta:number):{date:string;time:string}{
 const wall=new Date(Date.parse(`${date}T${time}:00Z`)+delta*60000).toISOString();return {date:wall.slice(0,10),time:wall.slice(11,16)};
}
export function importedDragInput(item:CalendarItem,change:DragChange,zone:string):ImportedInput {
 const e=item.external!;
 const wall=(instant:string)=>{const value=clockInZone(new Date(instant),zone);return {date:value.date,time:clockTime(value.hour*60+value.minute)};};
 let start=e.startUtc?wall(e.startUtc):{date:e.startDate??item.date,time:'00:00'};
 let end=e.endUtc?wall(e.endUtc):{date:e.endDate??item.date,time:'00:00'};
 if(change.mode==='move'){
  const delta=dayDifference(item.date,change.date)*1440+(!e.allDay&&change.time!==undefined?minutes(change.time)-minutes(item.time??'00:00'):0);
  start=shiftWall(start.date,start.time,delta);end=shiftWall(end.date,end.time,delta);
 }else end=shiftWall(change.date,'00:00',minutes(change.endTime!));
 return {title:item.title,description:e.description,location:e.location,startDate:start.date,endDate:end.date,startTime:e.allDay?null:start.time,endTime:e.allDay?null:end.time,allDay:e.allDay,displayZone:zone};
}
