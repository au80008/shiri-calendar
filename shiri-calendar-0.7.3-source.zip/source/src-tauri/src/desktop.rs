use crate::{
    model::{AppSnapshot, Language, WindowMode},
    state::AppState,
};
use std::sync::atomic::Ordering;
use tauri::{
    menu::{Menu, MenuItem},
    tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent},
    AppHandle, Emitter, Manager, PhysicalPosition, PhysicalSize,
};
use tauri_plugin_global_shortcut::{GlobalShortcutExt, ShortcutState};

const WIDGET_WIDTH: f64 = 320.;
const WIDGET_HEIGHT: f64 = 480.;
const TIMETABLE_WIDTH: f64 = 960.;
const COLLAPSED_HEIGHT: f64 = 56.;

pub fn clamp_position(
    position: (f64, f64),
    size: (f64, f64),
    area: (f64, f64, f64, f64),
) -> (f64, f64) {
    (
        position
            .0
            .max(area.0)
            .min((area.0 + area.2 - size.0).max(area.0)),
        position
            .1
            .max(area.1)
            .min((area.1 + area.3 - size.1).max(area.1)),
    )
}
pub fn physical_placement(
    desired: (f64, f64),
    size: (f64, f64),
    monitors: &[(f64, f64, f64, f64, f64)],
) -> (f64, f64, f64) {
    let Some(area) = monitors
        .iter()
        .find(|a| {
            desired.0 >= a.0 && desired.1 >= a.1 && desired.0 < a.0 + a.2 && desired.1 < a.1 + a.3
        })
        .or(monitors.first())
    else {
        return (desired.0, desired.1, 1.);
    };
    let (x, y) = clamp_position(
        desired,
        (size.0 * area.4, size.1 * area.4),
        (area.0, area.1, area.2, area.3),
    );
    (x, y, area.4)
}
pub fn publish(app: &AppHandle) {
    if let Ok(snapshot) = crate::subscriptions::service::app_snapshot(app) {
        let _ = app.emit_to("main", "calendar://state-changed", snapshot);
    }
}
/// The outer right edge anchors both layouts. Frame is logical; returned size is physical client size.
pub fn timetable_placement(
    anchor: (f64, f64),
    open: bool,
    collapsed: bool,
    frame: (f64, f64),
    monitors: &[(f64, f64, f64, f64, f64)],
) -> (f64, f64, f64, f64, f64) {
    let area = monitors
        .iter()
        .find(|a| {
            anchor.0 - 1. >= a.0
                && anchor.0 - 1. < a.0 + a.2
                && anchor.1 >= a.1
                && anchor.1 < a.1 + a.3
        })
        .or(monitors.first())
        .copied()
        .unwrap_or((0., 0., 1920., 1080., 1.));
    let frame = (frame.0 * area.4, frame.1 * area.4);
    let width = ((if open && !collapsed {
        TIMETABLE_WIDTH
    } else {
        WIDGET_WIDTH
    }) * area.4)
        .min((area.2 - frame.0).max(1.));
    let height = ((if collapsed {
        COLLAPSED_HEIGHT
    } else {
        WIDGET_HEIGHT
    }) * area.4)
        .min((area.3 - frame.1).max(1.));
    let (x, y) = clamp_position(
        (anchor.0 - width - frame.0, anchor.1),
        (width + frame.0, height + frame.1),
        (area.0, area.1, area.2, area.3),
    );
    (x, y, width, height, area.4)
}
pub fn initial_anchor(
    prefs: &crate::model::WindowPrefs,
    frame: (f64, f64),
    areas: &[(f64, f64, f64, f64, f64)],
) -> (f64, f64) {
    if prefs.fullscreen && !prefs.collapsed {
        if let Some(anchor) = prefs.restore_right.zip(prefs.restore_top) {
            return anchor;
        }
    }
    let default = areas.first().copied().unwrap_or((0., 0., 1920., 1080., 1.));
    if let Some((x, y)) = prefs.x.zip(prefs.y) {
        let area = areas
            .iter()
            .find(|a| x >= a.0 && x < a.0 + a.2 && y >= a.1 && y < a.1 + a.3)
            .copied()
            .unwrap_or(default);
        let width = ((if prefs.timetable_open && !prefs.collapsed {
            TIMETABLE_WIDTH
        } else {
            WIDGET_WIDTH
        } + frame.0)
            * area.4)
            .min(area.2);
        (x + width, y)
    } else {
        (
            default.0 + default.2 - 20. * default.4,
            default.1 + 24. * default.4,
        )
    }
}
pub fn configure(app: &AppHandle, initial: bool) -> Result<(), String> {
    let w = app.get_webview_window("main").ok_or("主窗口不存在")?;
    let prefs = {
        let state = app.state::<AppState>();
        let guard = state.inner.lock().map_err(|_| "状态忙")?;
        guard
            .repository
            .as_ref()
            .map(|r| r.data.window.clone())
            .unwrap_or_default()
    };
    w.set_always_on_top(prefs.pinned)
        .map_err(|e| e.to_string())?;
    let was_fullscreen = w.is_fullscreen().map_err(|e| e.to_string())?;
    let fullscreen = prefs.fullscreen && !prefs.collapsed;
    if fullscreen && was_fullscreen {
        crate::window_bounds::set_fullscreen_bounds(true);
        return Ok(());
    }
    if was_fullscreen {
        w.set_fullscreen(false).map_err(|e| e.to_string())?;
        // Read through the window dispatcher after the write, before measuring its normal frame.
        let _ = w.is_fullscreen().map_err(|e| e.to_string())?;
    }
    crate::window_bounds::set_fullscreen_bounds(false);
    let mut monitors = w.available_monitors().map_err(|e| e.to_string())?;
    if let Ok(Some(primary)) = w.primary_monitor() {
        monitors.sort_by_key(|m| m.position() != primary.position());
    }
    let areas: Vec<_> = monitors
        .iter()
        .map(|m| {
            let a = m.work_area();
            (
                a.position.x as f64,
                a.position.y as f64,
                a.size.width as f64,
                a.size.height as f64,
                m.scale_factor(),
            )
        })
        .collect();
    let Some(default) = areas.first().copied() else {
        return Ok(());
    };
    let scale = w.scale_factor().map_err(|e| e.to_string())?;
    let outer = w.outer_size().map_err(|e| e.to_string())?;
    let inner = w.inner_size().map_err(|e| e.to_string())?;
    let frame = (
        outer.width.saturating_sub(inner.width) as f64 / scale,
        outer.height.saturating_sub(inner.height) as f64 / scale,
    );
    let anchor = if was_fullscreen {
        prefs.restore_right.zip(prefs.restore_top).unwrap_or((
            default.0 + default.2 - 20. * default.4,
            default.1 + 24. * default.4,
        ))
    } else if initial {
        initial_anchor(&prefs, frame, &areas)
    } else {
        let position = w.outer_position().map_err(|e| e.to_string())?;
        let size = w.outer_size().map_err(|e| e.to_string())?;
        (position.x as f64 + size.width as f64, position.y as f64)
    };
    let (x, y, width, height, _) =
        timetable_placement(anchor, prefs.timetable_open, prefs.collapsed, frame, &areas);
    // Resize first so bounds checks use the new layout's outer size when
    // placing it against the same right-edge anchor.
    w.set_size(PhysicalSize::new(
        width.round() as u32,
        height.round() as u32,
    ))
    .map_err(|e| e.to_string())?;
    w.set_position(PhysicalPosition::new(x.round() as i32, y.round() as i32))
        .map_err(|e| e.to_string())?;
    if fullscreen {
        crate::window_bounds::set_fullscreen_bounds(true);
        if let Err(error) = w.set_fullscreen(true) {
            crate::window_bounds::set_fullscreen_bounds(false);
            return Err(error.to_string());
        }
        let _ = w.is_fullscreen().map_err(|e| e.to_string())?;
    }
    Ok(())
}
pub fn show_main(app: &AppHandle, date: Option<String>) -> Result<(), String> {
    if date.is_some() {
        set_collapsed(app, false)?;
    }
    configure(app, false)?;
    let w = app.get_webview_window("main").ok_or("主窗口不存在")?;
    let _ = w.unminimize();
    w.show().map_err(|e| e.to_string())?;
    w.set_focus().map_err(|e| e.to_string())?;
    if let Some(date) = date {
        let _ = app.emit_to("main", "calendar://select-date", date);
    }
    Ok(())
}
pub fn hide_main(app: &AppHandle) -> Result<(), String> {
    let w = app.get_webview_window("main").ok_or("主窗口不存在")?;
    if app.state::<AppState>().can_hide.load(Ordering::SeqCst) {
        w.hide().map_err(|e| e.to_string())
    } else {
        w.minimize().map_err(|e| e.to_string())
    }
}
pub fn toggle(app: &AppHandle) {
    if let Some(w) = app.get_webview_window("main") {
        if w.is_visible().unwrap_or(false) && !w.is_minimized().unwrap_or(false) {
            let _ = hide_main(app);
        } else {
            let _ = show_main(app, None);
        }
    }
}
pub fn set_pinned(app: &AppHandle, pinned: bool) -> Result<AppSnapshot, String> {
    let state = app.state::<AppState>();
    let mut guard = state.inner.lock().map_err(|_| "状态忙")?;
    let repo = guard.repository.as_mut().map_err(|e| e.clone())?;
    let w = app.get_webview_window("main").ok_or("主窗口不存在")?;
    let old = repo.data.window.pinned;
    w.set_always_on_top(pinned).map_err(|e| e.to_string())?;
    let mut next = repo.data.clone();
    next.window.pinned = pinned;
    if let Err(e) = repo.commit(next) {
        let _ = w.set_always_on_top(old);
        return Err(e);
    }
    Ok(repo.snapshot())
}
fn set_layout(
    app: &AppHandle,
    collapsed: Option<bool>,
    open: Option<bool>,
    mode: Option<WindowMode>,
) -> Result<AppSnapshot, String> {
    let state = app.state::<AppState>();
    let window = app.get_webview_window("main").ok_or("主窗口不存在")?;
    let position = window.outer_position().map_err(|e| e.to_string())?;
    let size = window.outer_size().map_err(|e| e.to_string())?;
    let old = {
        let mut guard = state.inner.lock().map_err(|_| "状态忙")?;
        let repo = guard.repository.as_mut().map_err(|e| e.clone())?;
        let old = repo.data.window.clone();
        let mut next = repo.data.clone();
        if let Some(value) = collapsed {
            next.window.collapsed = value;
        }
        if let Some(value) = open {
            next.window.timetable_open = value;
            next.window.fullscreen = false;
        }
        if let Some(mode) = mode {
            next.window.collapsed = false;
            next.window.timetable_open = !matches!(mode, WindowMode::Compact);
            next.window.fullscreen = matches!(mode, WindowMode::Fullscreen);
        }
        if next.window.fullscreen && !next.window.collapsed && !(old.fullscreen && !old.collapsed) {
            next.window.x = Some(f64::from(position.x));
            next.window.y = Some(f64::from(position.y));
            next.window.restore_right = Some(f64::from(position.x) + f64::from(size.width));
            next.window.restore_top = Some(f64::from(position.y));
            if !old.fullscreen {
                next.window.restore_timetable_open = old.timetable_open;
            }
            next.window.timetable_open = true;
        }
        repo.commit(next)?;
        old
    };
    if let Err(error) = configure(app, false) {
        if let Ok(mut guard) = state.inner.lock() {
            if let Ok(repo) = guard.repository.as_mut() {
                let mut next = repo.data.clone();
                next.window = old;
                let _ = repo.commit(next);
            }
        }
        let _ = configure(app, false);
        publish(app);
        return Err(error);
    }
    publish(app);
    let guard = state.inner.lock().map_err(|_| "状态忙")?;
    Ok(guard.repository.as_ref().map_err(|e| e.clone())?.snapshot())
}
pub fn set_collapsed(app: &AppHandle, collapsed: bool) -> Result<AppSnapshot, String> {
    set_layout(app, Some(collapsed), None, None)
}
pub fn set_timetable_open(app: &AppHandle, open: bool) -> Result<AppSnapshot, String> {
    set_layout(app, None, Some(open), None)
}
pub fn set_window_mode(app: &AppHandle, mode: WindowMode) -> Result<AppSnapshot, String> {
    set_layout(app, None, None, Some(mode))
}
fn tray_menu(app: &AppHandle, language: Language) -> Result<Menu<tauri::Wry>, String> {
    let en = language == Language::En;
    let show = MenuItem::with_id(
        app,
        "show",
        if en { "Show / hide" } else { "显示 / 隐藏" },
        true,
        None::<&str>,
    )
    .map_err(|e| e.to_string())?;
    let pin = MenuItem::with_id(
        app,
        "pin",
        if en {
            "Toggle always on top"
        } else {
            "切换置顶"
        },
        true,
        None::<&str>,
    )
    .map_err(|e| e.to_string())?;
    let quit = MenuItem::with_id(
        app,
        "quit",
        if en { "Quit Shiri" } else { "退出拾日" },
        true,
        None::<&str>,
    )
    .map_err(|e| e.to_string())?;
    Menu::with_items(app, &[&show, &pin, &quit]).map_err(|e| e.to_string())
}
pub fn apply_language(app: &AppHandle, language: Language) -> Result<(), String> {
    let en = language == Language::En;
    if let Some(tray) = app.tray_by_id("shiri-main") {
        tray.set_menu(Some(tray_menu(app, language)?))
            .map_err(|e| e.to_string())?;
        tray.set_tooltip(Some(if en {
            "Shiri · Ctrl+Alt+C Show / hide"
        } else {
            "拾日 · Ctrl+Alt+C 显示 / 隐藏"
        }))
        .map_err(|e| e.to_string())?;
    }
    if let Some(window) = app.get_webview_window("main") {
        window
            .set_title(if en {
                "Shiri · Desktop calendar"
            } else {
                "拾日 · 桌面日历"
            })
            .map_err(|e| e.to_string())?;
    }
    Ok(())
}
pub fn init(app: &AppHandle) -> Result<(), String> {
    let language = app
        .state::<AppState>()
        .inner
        .lock()
        .ok()
        .and_then(|g| g.repository.as_ref().ok().map(|r| r.data.settings.language))
        .unwrap_or_default();
    let menu = tray_menu(app, language)?;
    TrayIconBuilder::with_id("shiri-main")
        .icon(app.default_window_icon().ok_or("应用图标不存在")?.clone())
        .tooltip("拾日 · Ctrl+Alt+C 显示 / 隐藏")
        .menu(&menu)
        .show_menu_on_left_click(false)
        .on_tray_icon_event(|tray, event| {
            if matches!(
                event,
                TrayIconEvent::Click {
                    button: MouseButton::Left,
                    button_state: MouseButtonState::Up,
                    ..
                }
            ) {
                toggle(tray.app_handle());
            }
        })
        .on_menu_event(|app, event| match event.id.as_ref() {
            "quit" => app.exit(0),
            "show" => toggle(app),
            "pin" => {
                let pinned = app
                    .state::<AppState>()
                    .inner
                    .lock()
                    .ok()
                    .and_then(|g| g.repository.as_ref().ok().map(|r| !r.data.window.pinned));
                if let Some(value) = pinned {
                    if let Err(e) = set_pinned(app, value) {
                        warn(app, e);
                    }
                    publish(app);
                }
            }
            _ => {}
        })
        .build(app)
        .map_err(|e| e.to_string())?;
    apply_language(app, language)?;
    app.state::<AppState>()
        .can_hide
        .store(true, Ordering::SeqCst);
    if let Some(w) = app.get_webview_window("main") {
        let _ = w.set_skip_taskbar(true);
    }
    if let Err(e) = app
        .global_shortcut()
        .on_shortcut("Ctrl+Alt+C", |app, _, event| {
            if event.state == ShortcutState::Pressed {
                toggle(app);
            }
        })
    {
        warn(app, format!("Ctrl+Alt+C 被占用，请通过托盘唤回窗口（{e}）"));
    }
    configure(app, true)?;
    app.get_webview_window("main")
        .ok_or("主窗口不存在")?
        .show()
        .map_err(|e| e.to_string())?;
    // The first show finalizes the invisible shadow frame on Windows. Apply
    // the layout again using that frame so startup matches later toggles.
    configure(app, false)?;
    Ok(())
}
pub fn warn(app: &AppHandle, message: String) {
    if let Ok(mut g) = app.state::<AppState>().inner.lock() {
        if let Ok(repo) = g.repository.as_mut() {
            if !repo.warnings.contains(&message) {
                repo.warnings.push(message);
            }
        }
    }
    publish(app);
}
pub fn moved(app: &AppHandle, x: f64, y: f64) {
    // Windows can emit Moved while constructing the initial windows, before setup manages state.
    let Some(state) = app.try_state::<AppState>() else {
        return;
    };
    let sequence = state.move_sequence.fetch_add(1, Ordering::SeqCst) + 1;
    if crate::window_bounds::fullscreen_bounds() {
        return;
    }
    let app = app.clone();
    std::thread::spawn(move || {
        std::thread::sleep(std::time::Duration::from_millis(500));
        let state = app.state::<AppState>();
        if state.move_sequence.load(Ordering::SeqCst) != sequence {
            return;
        }
        let error = if let Ok(mut guard) = state.inner.lock() {
            if let Ok(repo) = guard.repository.as_mut() {
                if repo.data.window.fullscreen && !repo.data.window.collapsed {
                    return;
                }
                let mut next = repo.data.clone();
                next.window.x = Some(x);
                next.window.y = Some(y);
                repo.commit(next).err()
            } else {
                None
            }
        } else {
            None
        };
        if let Some(error) = error {
            warn(&app, format!("窗口位置保存失败：{error}"));
        }
    });
}
