use crate::{model::Reminder, storage::Repository};
use std::{
    collections::BTreeSet,
    sync::{
        atomic::{AtomicBool, AtomicU64},
        Mutex,
    },
};
pub struct RuntimeState {
    pub repository: Result<Repository, String>,
    pub active: Vec<Reminder>,
    pub session_delivered: BTreeSet<String>,
}
pub struct AppState {
    pub inner: Mutex<RuntimeState>,
    pub move_sequence: AtomicU64,
    pub can_hide: AtomicBool,
    pub subscriptions: crate::subscriptions::service::CalendarService,
    pub reminder_preparing: AtomicBool,
}
impl AppState {
    pub fn new(repository: Result<Repository, String>) -> Self {
        Self {
            inner: Mutex::new(RuntimeState {
                repository,
                active: Vec::new(),
                session_delivered: BTreeSet::new(),
            }),
            move_sequence: AtomicU64::new(0),
            can_hide: AtomicBool::new(false),
            subscriptions: Default::default(),
            reminder_preparing: AtomicBool::new(false),
        }
    }
}
