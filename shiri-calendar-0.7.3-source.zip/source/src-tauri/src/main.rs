#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
fn main() {
    shiri_calendar_lib::run();
}
