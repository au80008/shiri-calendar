use crate::subscriptions::{
    expand::display_zone,
    reminders::{is_external, prepare_external, PreparedExternal},
};
use crate::{
    model::{CalendarItem, Reminder},
    state::{AppState, RuntimeState},
    storage::Repository,
};
use chrono::{DateTime, Duration, NaiveDate, NaiveTime, TimeZone, Utc};
use std::collections::BTreeSet;
use tauri::{AppHandle, Emitter, Manager};
pub fn dismiss_pending(
    repo: &mut Repository,
    active: &mut Vec<Reminder>,
    key: &str,
) -> Result<(), String> {
    let mut next = repo.data.clone();
    next.pending.retain(|k| k != key);
    if next.pending != repo.data.pending {
        repo.commit(next)?;
    }
    active.retain(|r| r.key != key);
    Ok(())
}

pub(crate) fn plan_key(item: &CalendarItem) -> String {
    format!(
        "{}|{}|{}|{}",
        item.id,
        item.date,
        item.time.as_deref().unwrap_or(""),
        item.reminder_minutes.unwrap_or(-1)
    )
}
pub fn due_reminders<T: TimeZone>(
    items: &[CalendarItem],
    delivered: &BTreeSet<String>,
    now: DateTime<Utc>,
    zone: &T,
) -> Vec<Reminder> {
    let local_day = now.with_timezone(zone).date_naive();
    let start = local_day.pred_opt().unwrap_or(local_day).to_string();
    let end = local_day.succ_opt().unwrap_or(local_day).to_string();
    let expanded = crate::recurrence::expand_items(items, &start, &end);
    expanded
        .iter()
        .filter_map(|item| {
            if item.completed {
                return None;
            }
            let lead = item.reminder_minutes?;
            let date = NaiveDate::parse_from_str(&item.date, "%Y-%m-%d").ok()?;
            let time = NaiveTime::parse_from_str(item.time.as_deref()?, "%H:%M").ok()?;
            let start = zone
                .from_local_datetime(&date.and_time(time))
                .earliest()?
                .with_timezone(&Utc);
            let trigger = start.checked_sub_signed(Duration::minutes(lead))?;
            let elapsed = now.signed_duration_since(trigger);
            let since_start = now.signed_duration_since(start);
            let key = plan_key(item);
            if elapsed < Duration::zero()
                || (elapsed > Duration::minutes(15)
                    && (since_start < Duration::zero() || since_start > Duration::minutes(15)))
                || delivered.contains(&key)
            {
                return None;
            }
            Some(Reminder {
                key,
                item: item.clone(),
            })
        })
        .collect()
}
/// A pending plan may outlive the short due scan range by days or weeks.
pub fn resolve_plan(items: &[CalendarItem], key: &str) -> Option<CalendarItem> {
    let id = key.split('|').next()?;
    let item = crate::recurrence::resolve_item(items, id)?;
    (!item.completed && item.reminder_minutes.is_some() && plan_key(&item) == key).then_some(item)
}
pub fn process_due<T: TimeZone>(
    repo: &mut Repository,
    active: &mut Vec<Reminder>,
    session: &mut BTreeSet<String>,
    now: DateTime<Utc>,
    zone: &T,
    display: impl FnMut(&[Reminder]) -> Result<(), String>,
) -> Result<(), String> {
    process_due_prepared(
        repo,
        active,
        session,
        now,
        zone,
        &PreparedExternal::default(),
        display,
    )
}
pub fn process_due_prepared<T: TimeZone>(
    repo: &mut Repository,
    active: &mut Vec<Reminder>,
    session: &mut BTreeSet<String>,
    now: DateTime<Utc>,
    zone: &T,
    external: &PreparedExternal,
    mut display: impl FnMut(&[Reminder]) -> Result<(), String>,
) -> Result<(), String> {
    let resolve = |key: &str| -> Option<Reminder> {
        if is_external(key) {
            external.resolved.get(key).cloned()
        } else {
            resolve_plan(&repo.data.items, key).map(|item| Reminder {
                key: key.into(),
                item,
            })
        }
    };
    let old = active.clone();
    *active = active
        .iter()
        .filter_map(|r| {
            resolve(&r.key).or_else(|| {
                external
                    .preserve_pending
                    .contains(&r.key)
                    .then(|| r.clone())
            })
        })
        .collect();
    // Restore unfinished notifications even if their catch-up window has elapsed.
    for key in &repo.data.pending {
        if !active.iter().any(|r| r.key == *key) {
            if let Some(reminder) = resolve(key) {
                active.push(reminder);
            }
        }
    }
    let mut seen = repo.data.delivered.clone();
    seen.extend(session.iter().cloned());
    let mut due = due_reminders(&repo.data.items, &seen, now, zone);
    due.extend(
        external
            .due
            .iter()
            .filter(|r| !seen.contains(&r.key))
            .cloned(),
    );
    for reminder in due {
        if !active.iter().any(|r| r.key == reminder.key) {
            active.push(reminder);
        }
    }
    let changed = serde_json::to_string(&old).ok() != serde_json::to_string(&active).ok();
    let unseen_front = active.first().is_some_and(|r| !seen.contains(&r.key));
    if changed || unseen_front {
        if let Err(error) = display(active) {
            *active = old;
            return Err(error);
        }
        if let Some(front) = active.first() {
            session.insert(front.key.clone());
        }
    }
    let mut pending: Vec<_> = active.iter().map(|r| r.key.clone()).collect();
    for key in &external.preserve_pending {
        if repo.data.pending.contains(key) && !pending.contains(key) {
            pending.push(key.clone());
        }
    }
    if !session.is_subset(&repo.data.delivered) || pending != repo.data.pending {
        let mut next = repo.data.clone();
        next.delivered.extend(session.iter().cloned());
        next.pending = pending;
        repo.commit(next)?;
    }
    Ok(())
}
fn display(app: &AppHandle, queue: &[Reminder]) -> Result<(), String> {
    if queue.is_empty() {
        if let Some(w) = app.get_webview_window("reminder") {
            w.hide().map_err(|e| e.to_string())?;
        }
        return Ok(());
    }
    // Created hidden at application startup: WebView2 creation in synchronous
    // event handlers can deadlock on Windows. Showing an existing window is safe.
    let w = app.get_webview_window("reminder").ok_or("提醒窗口未就绪")?;
    if let Ok(Some(m)) = w.primary_monitor() {
        let area = m.work_area();
        let size = w.outer_size().map_err(|e| e.to_string())?;
        let x = area.position.x + area.size.width as i32 - size.width as i32 - 20;
        let y = area.position.y + area.size.height as i32 - size.height as i32 - 20;
        let _ = w.set_position(tauri::PhysicalPosition::new(x, y));
    }
    w.show().map_err(|e| e.to_string())?;
    app.emit_to("reminder", "calendar://reminders-changed", queue)
        .map_err(|e| e.to_string())?;
    Ok(())
}
fn apply_tick(
    app: &AppHandle,
    external: &PreparedExternal,
    expected_sources: &[crate::subscriptions::model::StoredSubscription],
    expected_prefs: &crate::subscriptions::model::CalendarViewPrefs,
) {
    let state = app.state::<AppState>();
    let Ok(mut guard) = state.inner.lock() else {
        return;
    };
    let RuntimeState {
        repository,
        active,
        session_delivered,
    } = &mut *guard;
    let Ok(repo) = repository else { return };
    if !crate::subscriptions::reminders::plans_current(
        &repo.data.subscriptions,
        expected_sources,
        &repo.data.calendar_view,
        expected_prefs,
    ) {
        return;
    }
    let before = active.len();
    let Ok(zone) = display_zone(repo.data.calendar_view.display_zone.as_deref()) else {
        return;
    };
    for warning in &external.warnings {
        let message = format!("外部日历提醒：{warning}");
        if !repo.warnings.contains(&message) {
            repo.warnings.push(message);
        }
    }
    if let Err(error) = process_due_prepared(
        repo,
        active,
        session_delivered,
        Utc::now(),
        &zone,
        external,
        |queue| display(app, queue),
    ) {
        let message = format!("提醒异常：{error}");
        if !repo.warnings.contains(&message) {
            repo.warnings.push(message);
            let _ = app.emit_to("main", "calendar://state-changed", repo.snapshot());
        }
    } else if active.len() > before {
        use tauri_plugin_notification::NotificationExt;
        if let Some(r) = active.last() {
            let _ = app
                .notification()
                .builder()
                .title(
                    if repo.data.settings.language == crate::model::Language::En {
                        "Shiri · Event reminder"
                    } else {
                        "拾日 · 日程提醒"
                    },
                )
                .body(format!(
                    "{}  {}",
                    r.item.time.as_deref().unwrap_or(""),
                    r.item.title
                ))
                .show();
        }
    }
}
pub fn tick(app: &AppHandle) {
    use std::sync::atomic::Ordering;
    let state = app.state::<AppState>();
    if state.reminder_preparing.swap(true, Ordering::SeqCst) {
        return;
    }
    let handle = app.clone();
    std::thread::spawn(move || {
        let state = handle.state::<AppState>();
        let captured = (|| {
            let guard = state.inner.lock().ok()?;
            let repo = guard.repository.as_ref().ok()?;
            let mut pending = repo.data.pending.clone();
            for r in &guard.active {
                if !pending.contains(&r.key) {
                    pending.push(r.key.clone());
                }
            }
            Some((
                repo.data.subscriptions.clone(),
                repo.data.calendar_view.clone(),
                pending,
            ))
        })();
        let Some((sources, prefs, pending)) = captured else {
            state.reminder_preparing.store(false, Ordering::SeqCst);
            return;
        };
        let prepared = prepare_external(
            &state.subscriptions,
            &sources,
            &pending,
            Utc::now(),
            prefs.display_zone.as_deref(),
        );
        let on_main = handle.clone();
        if handle
            .run_on_main_thread(move || {
                let state = on_main.state::<AppState>();
                apply_tick(&on_main, &prepared, &sources, &prefs);
                state.reminder_preparing.store(false, Ordering::SeqCst);
            })
            .is_err()
        {
            state.reminder_preparing.store(false, Ordering::SeqCst);
        }
    });
}
pub fn start(app: AppHandle) {
    std::thread::spawn(move || loop {
        std::thread::sleep(std::time::Duration::from_secs(5));
        let handle = app.clone();
        if app.run_on_main_thread(move || tick(&handle)).is_err() {
            break;
        }
    });
}
