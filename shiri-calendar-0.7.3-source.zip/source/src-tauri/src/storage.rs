use crate::model::{AppSnapshot, CalendarItem, ItemInput, StoredData};
use crate::recurrence::{is_planned, resolve_occurrence};
use chrono::Utc;
use rusqlite::{Connection, OpenFlags};
use std::{
    fs,
    path::{Path, PathBuf},
};

pub struct Repository {
    pub data: StoredData,
    pub warnings: Vec<String>,
    directory: PathBuf,
}
fn read_data(path: &Path) -> Result<StoredData, String> {
    // Read/write permits SQLite to recover an interrupted rollback journal.
    let connection = Connection::open_with_flags(path, OpenFlags::SQLITE_OPEN_READ_WRITE)
        .map_err(|e| format!("读取日历失败：{e}"))?;
    let version: i64 = connection
        .pragma_query_value(None, "user_version", |r| r.get(0))
        .map_err(|e| format!("数据库损坏：{e}"))?;
    let tables: Vec<String> = {
        let mut statement = connection
            .prepare(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'",
            )
            .map_err(|e| e.to_string())?;
        let rows = statement
            .query_map([], |r| r.get(0))
            .map_err(|e| e.to_string())?;
        rows.collect::<Result<_, _>>().map_err(|e| e.to_string())?
    };
    if version == 0 && tables.is_empty() {
        return Ok(StoredData::default());
    }
    if version == 0 && tables == ["app_state"] {
        let count: i64 = connection
            .query_row("SELECT count(*) FROM app_state", [], |r| r.get(0))
            .map_err(|e| e.to_string())?;
        if count == 0 {
            return Ok(StoredData::default());
        }
    }
    let payload: String = connection
        .query_row("SELECT payload FROM app_state WHERE id=1", [], |row| {
            row.get(0)
        })
        .map_err(|e| format!("日历数据损坏：{e}"))?;
    let value: serde_json::Value =
        serde_json::from_str(&payload).map_err(|e| format!("数据损坏：{e}"))?;
    if !matches!(
        value.get("schemaVersion").and_then(|v| v.as_u64()),
        Some(1..=7)
    ) {
        return Err("日历版本不兼容，请使用对应版本应用；原文件未改动".into());
    }
    let mut data: StoredData =
        serde_json::from_value(value).map_err(|e| format!("数据格式无效：{e}"))?;
    // Upgrade only in memory on read. The next explicit save publishes schema 7,
    // which older versions refuse rather than dropping recurrence or source data.
    data.schema_version = 7;
    data.calendar_view.validate()?;
    let mut source_ids = std::collections::HashSet::new();
    let mut source_urls = std::collections::HashSet::new();
    for source in &data.subscriptions {
        source.input.validate()?;
        if uuid::Uuid::parse_str(&source.id).is_err()
            || !source_ids.insert(source.id.clone())
            || !source_urls
                .insert(crate::subscriptions::fetch::normalize_url(&source.input.url)?.to_string())
        {
            return Err("日历来源身份无效或重复".into());
        }
        if source.raw_ics.len() > crate::subscriptions::MAX_FEED_BYTES {
            return Err("日历缓存超过大小上限".into());
        }
        if source.local_edits.len() > 10_000 {
            return Err("本地修改数量超过上限".into());
        }
        if source.deleted_series.len() > 10_000 {
            return Err("本地删除数量超过上限".into());
        }
        let mut deleted_uids = std::collections::HashSet::new();
        if source
            .deleted_series
            .iter()
            .any(|uid| uid.is_empty() || !deleted_uids.insert(uid))
        {
            return Err("本地删除标识无效或重复".into());
        }
        let mut edit_keys = std::collections::HashSet::new();
        for edit in &source.local_edits {
            if edit.uid.is_empty() || !edit_keys.insert((&edit.uid, &edit.recurrence_key)) {
                return Err("本地修改标识无效或重复".into());
            }
            if let Some(input) = &edit.input {
                input.event(&edit.uid)?;
            }
        }
    }
    let mut ids = std::collections::HashSet::new();
    for item in &data.items {
        item.input().validate()?;
        if item.series_id.is_some() || item.occurrence_date.is_some() {
            return Err("生成的重复实例不能保存为整组日程".into());
        }
        for (date, exception) in &item.exceptions {
            if !is_planned(item, date) {
                return Err("重复日程例外日期无效".into());
            }
            if let Some(input) = &exception.input {
                input.validate()?;
                if input.recurrence.is_some() {
                    return Err("单次修改不能设置重复规则".into());
                }
                if input.kind == crate::model::ItemKind::Note && exception.completed == Some(true) {
                    return Err("备忘不能标记完成".into());
                }
            }
        }
        if item.id.is_empty() || !ids.insert(&item.id) {
            return Err("日程 ID 无效或重复".into());
        }
    }
    Ok(data)
}
impl Repository {
    fn change_occurrence(
        &mut self,
        id: &str,
        date: &str,
        change: impl FnOnce(&mut crate::model::OccurrenceException),
    ) -> Result<(), String> {
        let mut next = self.data.clone();
        let item = next
            .items
            .iter_mut()
            .find(|i| i.id == id)
            .ok_or("这条日程已不存在")?;
        if resolve_occurrence(item, date).is_none() {
            return Err("这次重复日程已不存在".into());
        }
        change(item.exceptions.entry(date.into()).or_default());
        item.updated_at = Utc::now().to_rfc3339();
        self.commit(next)
    }
    pub fn update_occurrence(
        &mut self,
        id: &str,
        date: &str,
        mut input: ItemInput,
    ) -> Result<(), String> {
        input.validate()?;
        if input.recurrence.is_some() {
            return Err("单次修改不能设置重复规则".into());
        }
        input.title = input.title.trim().into();
        self.change_occurrence(id, date, |exception| {
            exception.completed = Some(input.completed);
            exception.input = Some(input);
        })
    }
    pub fn delete_occurrence(&mut self, id: &str, date: &str) -> Result<(), String> {
        self.change_occurrence(id, date, |exception| exception.deleted = true)
    }
    pub fn set_completed_occurrence(
        &mut self,
        id: &str,
        date: &str,
        completed: bool,
    ) -> Result<(), String> {
        let item = self
            .data
            .items
            .iter()
            .find(|i| i.id == id)
            .ok_or("这条日程已不存在")?;
        let occurrence = resolve_occurrence(item, date).ok_or("这次重复日程已不存在")?;
        let mut input = occurrence.input();
        input.recurrence = None;
        input.completed = completed;
        input.validate()?;
        self.change_occurrence(id, date, |exception| exception.completed = Some(completed))
    }
    pub fn open(directory: PathBuf) -> Result<Self, String> {
        fs::create_dir_all(&directory).map_err(|e| format!("无法创建日历目录：{e}"))?;
        let main = directory.join("calendar.sqlite3");
        let backup = directory.join("calendar.backup.sqlite3");
        if !main.exists() && !backup.exists() {
            return Ok(Self {
                data: StoredData::default(),
                warnings: Vec::new(),
                directory,
            });
        }
        match read_data(&main) {
            Ok(data) => Ok(Self {
                data,
                warnings: Vec::new(),
                directory,
            }),
            Err(error) => {
                // A future schema must never be replaced with an older backup.
                if error.contains("版本不兼容") {
                    return Err(error);
                }
                let data = read_data(&backup)
                    .map_err(|_| format!("{error}；备份也无法读取，请先备份原文件再修复"))?;
                if main.is_file() {
                    let preserved = directory.join(format!(
                        "calendar.corrupt-{}.sqlite3",
                        Utc::now().timestamp_nanos_opt().unwrap_or_default()
                    ));
                    fs::copy(&main, preserved).map_err(|e| format!("无法保留损坏文件：{e}"))?;
                }
                // Keep both the damaged original and the valid backup if recovery is interrupted.
                fs::copy(&backup, &main).map_err(|e| format!("备份恢复失败：{e}"))?;
                Ok(Self {
                    data,
                    warnings: vec!["日历文件异常，已从备份恢复；原文件已保留".into()],
                    directory,
                })
            }
        }
    }
    pub fn snapshot(&self) -> AppSnapshot {
        AppSnapshot {
            items: self.data.items.clone(),
            window: self.data.window.clone(),
            warnings: self.warnings.clone(),
            calendar_sources: self
                .data
                .subscriptions
                .iter()
                .map(|s| s.summary())
                .collect(),
            calendar_view: self.data.calendar_view.clone(),
            settings: self.data.settings.clone(),
        }
    }
    pub fn commit(&mut self, mut next: StoredData) -> Result<(), String> {
        next.schema_version = 7;
        let main = self.directory.join("calendar.sqlite3");
        let backup = self.directory.join("calendar.backup.sqlite3");
        let existed = main.exists();
        if existed {
            read_data(&main)?;
        }
        let mut connection = Connection::open(&main).map_err(|e| format!("保存失败：{e}"))?;
        connection
            .busy_timeout(std::time::Duration::from_secs(3))
            .map_err(|e| e.to_string())?;
        connection
            .pragma_update(None, "journal_mode", "DELETE")
            .map_err(|e| e.to_string())?;
        connection
            .pragma_update(None, "synchronous", "FULL")
            .map_err(|e| e.to_string())?;
        if existed {
            connection
                .backup("main", &backup, None)
                .map_err(|e| format!("更新备份失败：{e}"))?;
        }
        let payload = serde_json::to_string(&next).map_err(|e| e.to_string())?;
        let transaction = connection.transaction().map_err(|e| e.to_string())?;
        transaction.execute("CREATE TABLE IF NOT EXISTS app_state(id INTEGER PRIMARY KEY CHECK(id=1),payload TEXT NOT NULL)",[]).map_err(|e|e.to_string())?;
        transaction.execute("INSERT INTO app_state(id,payload) VALUES(1,?1) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload",[payload]).map_err(|e|e.to_string())?;
        transaction
            .pragma_update(None, "user_version", 7)
            .map_err(|e| e.to_string())?;
        transaction
            .commit()
            .map_err(|e| format!("保存日历失败：{e}"))?;
        if !existed {
            if let Err(e) = connection.backup("main", &backup, None) {
                self.warnings
                    .push(format!("日历已保存，但初始备份未完成：{e}"));
            }
        }
        self.data = next;
        Ok(())
    }
    pub fn create(&mut self, input: ItemInput) -> Result<CalendarItem, String> {
        input.validate()?;
        let now = Utc::now().to_rfc3339();
        let item = CalendarItem {
            kind: input.kind,
            id: uuid::Uuid::new_v4().to_string(),
            title: input.title.trim().into(),
            date: input.date,
            time: input.time,
            end_time: input.end_time,
            notes: input.notes,
            reminder_minutes: input.reminder_minutes,
            completed: input.completed,
            recurrence: input.recurrence,
            exceptions: Default::default(),
            series_id: None,
            occurrence_date: None,
            created_at: now.clone(),
            updated_at: now,
        };
        let mut next = self.data.clone();
        next.items.push(item.clone());
        self.commit(next)?;
        Ok(item)
    }
    pub fn update(&mut self, id: &str, input: ItemInput) -> Result<(), String> {
        input.validate()?;
        let mut next = self.data.clone();
        let old = next
            .items
            .iter_mut()
            .find(|i| i.id == id)
            .ok_or("这条日程已不存在")?;
        old.title = input.title.trim().into();
        old.kind = input.kind;
        old.date = input.date;
        old.time = input.time;
        old.end_time = input.end_time;
        old.notes = input.notes;
        old.reminder_minutes = input.reminder_minutes;
        old.completed = input.completed;
        old.recurrence = input.recurrence;
        let valid: std::collections::BTreeSet<String> = old
            .exceptions
            .keys()
            .filter(|date| is_planned(old, date))
            .cloned()
            .collect();
        old.exceptions.retain(|date, _| valid.contains(date));
        old.updated_at = Utc::now().to_rfc3339();
        self.commit(next)
    }
    pub fn set_completed(&mut self, id: &str, completed: bool) -> Result<(), String> {
        let mut input = self
            .data
            .items
            .iter()
            .find(|i| i.id == id)
            .ok_or("这条日程已不存在")?
            .input();
        if input.recurrence.is_some() {
            return Err("请指定要完成的重复日期".into());
        }
        input.completed = completed;
        self.update(id, input)
    }
    pub fn delete(&mut self, id: &str) -> Result<(), String> {
        if !self.data.items.iter().any(|i| i.id == id) {
            return Err("这条日程已不存在".into());
        }
        let mut next = self.data.clone();
        next.items.retain(|i| i.id != id);
        self.commit(next)
    }
}
