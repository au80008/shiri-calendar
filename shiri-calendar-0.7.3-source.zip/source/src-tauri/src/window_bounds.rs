//! Constrain the proposed rectangle during the Windows move loop, before it is displayed.
use std::sync::atomic::{AtomicBool, Ordering};
static FULLSCREEN_BOUNDS: AtomicBool = AtomicBool::new(false);
pub fn set_fullscreen_bounds(fullscreen: bool) {
    FULLSCREEN_BOUNDS.store(fullscreen, Ordering::SeqCst);
}
pub fn fullscreen_bounds() -> bool {
    FULLSCREEN_BOUNDS.load(Ordering::SeqCst)
}
#[cfg(windows)]
use windows_sys::Win32::{
    Foundation::{HWND, LPARAM, LRESULT, RECT, WPARAM},
    Graphics::Gdi::{
        GetMonitorInfoW, MonitorFromRect, HMONITOR, MONITORINFO, MONITOR_DEFAULTTONEAREST,
    },
    UI::{
        Shell::{DefSubclassProc, RemoveWindowSubclass, SetWindowSubclass},
        WindowsAndMessaging::{
            GetWindowRect, SWP_NOMOVE, SWP_NOSIZE, WINDOWPOS, WM_MOVING, WM_NCDESTROY,
            WM_WINDOWPOSCHANGING,
        },
    },
};

pub fn install(window: &tauri::WebviewWindow) -> Result<(), String> {
    #[cfg(windows)]
    {
        let hwnd = window.hwnd().map_err(|e| e.to_string())?;
        // Setup creates this window on the UI thread and owns it until WM_NCDESTROY.
        unsafe { install_native(hwnd.0 as HWND) }
    }
    #[cfg(not(windows))]
    {
        let _ = window;
        Ok(())
    }
}

#[cfg(windows)]
const SUBCLASS_ID: usize = 0x5348_5249;

#[cfg(windows)]
unsafe fn install_native(hwnd: HWND) -> Result<(), String> {
    if SetWindowSubclass(hwnd, Some(constrain_move), SUBCLASS_ID, 0) == 0 {
        Err("无法启用窗口拖动边界".into())
    } else {
        Ok(())
    }
}

#[cfg(windows)]
fn monitor_area(info: &MONITORINFO, fullscreen: bool) -> RECT {
    if fullscreen {
        info.rcMonitor
    } else {
        info.rcWork
    }
}
#[cfg(windows)]
unsafe fn work_area(monitor: HMONITOR) -> Option<RECT> {
    let mut info = MONITORINFO {
        cbSize: std::mem::size_of::<MONITORINFO>() as u32,
        ..Default::default()
    };
    (GetMonitorInfoW(monitor, &mut info) != 0).then_some(monitor_area(&info, fullscreen_bounds()))
}

#[cfg(windows)]
fn fit_rectangle(rect: RECT, work: RECT) -> RECT {
    let width = rect
        .right
        .saturating_sub(rect.left)
        .max(1)
        .min((work.right - work.left).max(1));
    let height = rect
        .bottom
        .saturating_sub(rect.top)
        .max(1)
        .min((work.bottom - work.top).max(1));
    let (left, top) = crate::desktop::clamp_position(
        (f64::from(rect.left), f64::from(rect.top)),
        (f64::from(width), f64::from(height)),
        (
            f64::from(work.left),
            f64::from(work.top),
            f64::from(work.right - work.left),
            f64::from(work.bottom - work.top),
        ),
    );
    RECT {
        left: left as i32,
        top: top as i32,
        right: (left as i32).saturating_add(width),
        bottom: (top as i32).saturating_add(height),
    }
}

#[cfg(windows)]
fn monitor_reference(current: RECT, proposed: RECT, flags: u32) -> RECT {
    // A resize-only intermediate rectangle must not pull an anchored layout
    // onto a neighboring monitor before its final position is applied.
    if flags & SWP_NOMOVE != 0 {
        current
    } else {
        proposed
    }
}

#[cfg(windows)]
unsafe extern "system" fn constrain_move(
    hwnd: HWND,
    message: u32,
    wparam: WPARAM,
    lparam: LPARAM,
    id: usize,
    _data: usize,
) -> LRESULT {
    if message == WM_WINDOWPOSCHANGING && lparam != 0 {
        // DPI changes and Windows placement can bypass WM_MOVING. Let the
        // existing procedure finish, then constrain the final proposed size
        // and position before Windows applies it. No recursive SetWindowPos.
        let result = DefSubclassProc(hwnd, message, wparam, lparam);
        let position = &mut *(lparam as *mut WINDOWPOS);
        let mut current = RECT::default();
        if GetWindowRect(hwnd, &mut current) != 0 {
            let left = if position.flags & SWP_NOMOVE != 0 {
                current.left
            } else {
                position.x
            };
            let top = if position.flags & SWP_NOMOVE != 0 {
                current.top
            } else {
                position.y
            };
            let width = if position.flags & SWP_NOSIZE != 0 {
                current.right - current.left
            } else {
                position.cx
            };
            let height = if position.flags & SWP_NOSIZE != 0 {
                current.bottom - current.top
            } else {
                position.cy
            };
            let rect = RECT {
                left,
                top,
                right: left.saturating_add(width),
                bottom: top.saturating_add(height),
            };
            let reference = monitor_reference(current, rect, position.flags);
            if let Some(work) = work_area(MonitorFromRect(&reference, MONITOR_DEFAULTTONEAREST)) {
                let bounded = fit_rectangle(rect, work);
                if bounded.left != left || bounded.top != top {
                    position.x = bounded.left;
                    position.y = bounded.top;
                    position.flags &= !SWP_NOMOVE;
                }
                if bounded.right - bounded.left != width || bounded.bottom - bounded.top != height {
                    position.cx = bounded.right - bounded.left;
                    position.cy = bounded.bottom - bounded.top;
                    position.flags &= !SWP_NOSIZE;
                }
            }
        }
        return result;
    }
    if message == WM_MOVING && lparam != 0 {
        // WM_MOVING supplies a live writable RECT for the duration of this callback.
        // No repository locks, allocations or window mutations occur in the move loop.
        let proposed = &mut *(lparam as *mut RECT);
        let width = proposed.right.saturating_sub(proposed.left);
        let height = proposed.bottom.saturating_sub(proposed.top);
        if width > 0 && height > 0 {
            if let Some(work) = work_area(MonitorFromRect(proposed, MONITOR_DEFAULTTONEAREST)) {
                *proposed = fit_rectangle(*proposed, work);
                return 1;
            }
        }
    }
    if message == WM_NCDESTROY {
        RemoveWindowSubclass(hwnd, Some(constrain_move), id);
    }
    DefSubclassProc(hwnd, message, wparam, lparam)
}

#[cfg(all(test, windows))]
mod tests {
    use super::*;
    #[test]
    fn fullscreen_uses_the_monitor_while_normal_windows_avoid_the_taskbar() {
        let info = MONITORINFO {
            rcMonitor: RECT {
                left: -1920,
                top: 0,
                right: 0,
                bottom: 1080,
            },
            rcWork: RECT {
                left: -1920,
                top: 0,
                right: 0,
                bottom: 1032,
            },
            ..Default::default()
        };
        assert_eq!(monitor_area(&info, false).bottom, 1032);
        assert_eq!(monitor_area(&info, true).bottom, 1080);
        assert_eq!(monitor_area(&info, true).left, -1920);
    }
    use windows_sys::Win32::{
        Foundation::RECT,
        Graphics::Gdi::{
            GetMonitorInfoW, MonitorFromWindow, MONITORINFO, MONITOR_DEFAULTTONEAREST,
        },
        UI::WindowsAndMessaging::{
            CreateWindowExW, DestroyWindow, GetWindowRect, SendMessageW, SetWindowPos,
            SWP_NOACTIVATE, SWP_NOZORDER, WM_MOVING, WS_POPUP,
        },
    };

    #[test]
    fn native_moving_message_constrains_every_edge_before_the_move() {
        unsafe {
            let class: Vec<u16> = "STATIC\0".encode_utf16().collect();
            let hwnd = CreateWindowExW(
                0,
                class.as_ptr(),
                class.as_ptr(),
                WS_POPUP,
                100,
                100,
                320,
                480,
                std::ptr::null_mut(),
                std::ptr::null_mut(),
                std::ptr::null_mut(),
                std::ptr::null(),
            );
            assert!(!hwnd.is_null());
            struct OwnedWindow(windows_sys::Win32::Foundation::HWND);
            impl Drop for OwnedWindow {
                fn drop(&mut self) {
                    unsafe {
                        DestroyWindow(self.0);
                    }
                }
            }
            let _owned = OwnedWindow(hwnd);
            install_native(hwnd).unwrap();
            let mut monitor = MONITORINFO {
                cbSize: std::mem::size_of::<MONITORINFO>() as u32,
                ..Default::default()
            };
            assert_ne!(
                GetMonitorInfoW(
                    MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST),
                    &mut monitor
                ),
                0
            );
            let work = monitor.rcWork;
            for (x, y) in [
                (work.left - 200, work.top - 200),
                (work.right - 50, work.bottom - 50),
                (work.left + 30, work.top - 300),
                (work.right - 10, work.top + 20),
            ] {
                let mut proposed = RECT {
                    left: x,
                    top: y,
                    right: x + 320,
                    bottom: y + 480,
                };
                assert_eq!(
                    SendMessageW(hwnd, WM_MOVING, 0, &mut proposed as *mut RECT as isize),
                    1
                );
                assert!(proposed.left >= work.left && proposed.top >= work.top);
                assert!(proposed.right <= work.right && proposed.bottom <= work.bottom);
                assert_eq!(
                    (
                        proposed.right - proposed.left,
                        proposed.bottom - proposed.top
                    ),
                    (320, 480)
                );
            }
        }
    }

    #[test]
    fn post_dpi_setwindowpos_fits_an_enlarged_window_inside_the_work_area() {
        unsafe {
            let class: Vec<u16> = "STATIC\0".encode_utf16().collect();
            let hwnd = CreateWindowExW(
                0,
                class.as_ptr(),
                class.as_ptr(),
                WS_POPUP,
                100,
                100,
                320,
                480,
                std::ptr::null_mut(),
                std::ptr::null_mut(),
                std::ptr::null_mut(),
                std::ptr::null(),
            );
            assert!(!hwnd.is_null());
            struct OwnedWindow(HWND);
            impl Drop for OwnedWindow {
                fn drop(&mut self) {
                    unsafe {
                        DestroyWindow(self.0);
                    }
                }
            }
            let _owned = OwnedWindow(hwnd);
            install_native(hwnd).unwrap();
            let work = work_area(MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST)).unwrap();
            // Tao applies a DPI change through SetWindowPos, without WM_MOVING.
            assert_ne!(
                SetWindowPos(
                    hwnd,
                    std::ptr::null_mut(),
                    work.left,
                    work.top,
                    work.right - work.left + 400,
                    work.bottom - work.top + 300,
                    SWP_NOZORDER | SWP_NOACTIVATE
                ),
                0
            );
            let mut actual = RECT::default();
            assert_ne!(GetWindowRect(hwnd, &mut actual), 0);
            assert!(actual.left >= work.left && actual.top >= work.top);
            assert!(
                actual.right <= work.right && actual.bottom <= work.bottom,
                "scaled window escaped the work area"
            );
            assert_ne!(
                SetWindowPos(
                    hwnd,
                    std::ptr::null_mut(),
                    work.left - 100,
                    work.top - 100,
                    0,
                    0,
                    SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE
                ),
                0
            );
            assert_ne!(GetWindowRect(hwnd, &mut actual), 0);
            assert_eq!((actual.left, actual.top), (work.left, work.top));
            assert_ne!(
                SetWindowPos(
                    hwnd,
                    std::ptr::null_mut(),
                    0,
                    0,
                    320,
                    480,
                    SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE
                ),
                0
            );
            assert_ne!(GetWindowRect(hwnd, &mut actual), 0);
            assert_eq!(
                (actual.right - actual.left, actual.bottom - actual.top),
                (320, 480)
            );
        }
    }

    #[test]
    fn a_dpi_enlarged_timetable_fits_a_smaller_negative_coordinate_monitor() {
        let work = RECT {
            left: -1280,
            top: -50,
            right: 0,
            bottom: 950,
        };
        let scaled = RECT {
            left: -1000,
            top: 50,
            right: 456,
            bottom: 809,
        };
        let result = fit_rectangle(scaled, work);
        assert_eq!(
            (result.left, result.top, result.right, result.bottom),
            (-1280, 50, 0, 809)
        );
    }

    #[test]
    fn resize_only_uses_current_monitor_even_when_expansion_overlaps_a_smaller_neighbor() {
        let current = RECT {
            left: 1600,
            top: 0,
            right: 1920,
            bottom: 480,
        };
        let expanded = RECT {
            left: 1600,
            top: 0,
            right: 2560,
            bottom: 480,
        };
        let reference = monitor_reference(current, expanded, SWP_NOMOVE);
        let primary = RECT {
            left: 0,
            top: 0,
            right: 1920,
            bottom: 1040,
        };
        let secondary = RECT {
            left: 1920,
            top: 0,
            right: 2720,
            bottom: 1040,
        };
        let overlap =
            |r: RECT, area: RECT| (r.right.min(area.right) - r.left.max(area.left)).max(0);
        let selected = if overlap(reference, primary) >= overlap(reference, secondary) {
            primary
        } else {
            secondary
        };
        let result = fit_rectangle(expanded, selected);
        assert_eq!(
            (result.left, result.right, result.right - result.left),
            (960, 1920, 960)
        );
    }
}
