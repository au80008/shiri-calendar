//! Local edits to an imported snapshot. Display and reminders share this projection.
use super::{expand::civil_date, model::*, CalendarError};
use crate::storage::Repository;
use calcard::common::timezone::Tz;
use chrono::{NaiveDate, NaiveDateTime, NaiveTime, TimeZone};
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ImportedInput {
    pub title: String,
    pub description: String,
    pub location: String,
    pub start_date: String,
    pub end_date: String,
    pub start_time: Option<String>,
    pub end_time: Option<String>,
    pub all_day: bool,
    pub display_zone: String,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ImportedEdit {
    pub uid: String,
    pub recurrence_key: String,
    pub input: Option<ImportedInput>,
}
enum ImportChange {
    Save(ImportedInput),
    Delete,
    Restore,
}

fn key_time(key: &str) -> Result<EventTime, CalendarError> {
    let (wall, all_day) = if key.len() == 8 {
        (
            NaiveDate::parse_from_str(key, "%Y%m%d")
                .map_err(|_| "重复实例标识无效")?
                .and_hms_opt(0, 0, 0)
                .ok_or("日期无效")?,
            true,
        )
    } else {
        (
            NaiveDateTime::parse_from_str(key, "%Y%m%dT%H%M%SZ").map_err(|_| "重复实例标识无效")?,
            false,
        )
    };
    Ok(EventTime {
        wall,
        zone: Tz::UTC,
        all_day,
    })
}
impl ImportedInput {
    pub fn event(&self, uid: &str) -> Result<FeedEvent, CalendarError> {
        if self.title.trim().is_empty() || self.title.chars().count() > 120 {
            return Err("日程名称需为 1–120 字".into());
        }
        if self.description.chars().count() > 2000 || self.location.chars().count() > 300 {
            return Err("备注最多 2000 字，地点最多 300 字".into());
        }
        let first = civil_date(&self.start_date)?;
        let last = civil_date(&self.end_date)?;
        let zone = self
            .display_zone
            .parse::<chrono_tz::Tz>()
            .map_err(|_| "显示时区无效")?;
        let parse_time = |raw: &Option<String>| -> Result<NaiveTime, String> {
            let raw = raw.as_deref().ok_or("请填写开始和结束时间")?;
            let time = NaiveTime::parse_from_str(raw, "%H:%M").map_err(|_| "时间需为 HH:mm")?;
            if time.format("%H:%M").to_string() != raw {
                return Err("时间需为 HH:mm".into());
            }
            Ok(time)
        };
        let (start, duration) = if self.all_day {
            if last < first {
                return Err("结束日期不能早于开始日期".into());
            }
            (
                EventTime {
                    wall: first.and_hms_opt(0, 0, 0).ok_or("日期无效")?,
                    zone: Tz::UTC,
                    all_day: true,
                },
                EventDuration {
                    days: (last - first).num_days() + 1,
                    seconds: 0,
                },
            )
        } else {
            let begin = zone
                .from_local_datetime(&first.and_time(parse_time(&self.start_time)?))
                .single()
                .ok_or("开始时间处于夏令时缺失或重复时段，请调整时间")?;
            let end = zone
                .from_local_datetime(&last.and_time(parse_time(&self.end_time)?))
                .single()
                .ok_or("结束时间处于夏令时缺失或重复时段，请调整时间")?;
            if end < begin {
                return Err("结束时间不能早于开始时间".into());
            }
            (
                EventTime {
                    wall: begin.naive_utc(),
                    zone: Tz::UTC,
                    all_day: false,
                },
                EventDuration {
                    days: 0,
                    seconds: (end - begin).num_seconds(),
                },
            )
        };
        Ok(FeedEvent {
            uid: uid.into(),
            title: self.title.trim().into(),
            original_title: self.title.clone(),
            description: self.description.clone(),
            location: self.location.clone(),
            start: Some(start),
            duration,
            rule: None,
            rdates: vec![],
            exdates: vec![],
            recurrence_id: None,
            cancelled: false,
            sequence: i64::MAX,
            stamp: i64::MAX,
            present: [
                "Summary",
                "Description",
                "Location",
                "Dtend",
                "Duration",
                "LocalEdit",
            ]
            .into_iter()
            .map(str::to_string)
            .collect(),
        })
    }
}
fn recurring(calendar: &ParsedCalendar, uid: &str) -> bool {
    calendar.events.iter().any(|e| {
        e.uid == uid && (e.rule.is_some() || !e.rdates.is_empty() || e.recurrence_id.is_some())
    })
}
pub fn apply_edits(
    calendar: &ParsedCalendar,
    edits: &[ImportedEdit],
) -> Result<ParsedCalendar, CalendarError> {
    let mut result = calendar.clone();
    for edit in edits {
        let mut event = if let Some(input) = &edit.input {
            input.event(&edit.uid)?
        } else {
            FeedEvent {
                uid: edit.uid.clone(),
                title: String::new(),
                original_title: String::new(),
                description: String::new(),
                location: String::new(),
                start: Some(key_time(&edit.recurrence_key)?),
                duration: EventDuration::default(),
                rule: None,
                rdates: vec![],
                exdates: vec![],
                recurrence_id: None,
                cancelled: true,
                sequence: i64::MAX,
                stamp: i64::MAX,
                present: Default::default(),
            }
        };
        if recurring(calendar, &edit.uid) {
            let rid = key_time(&edit.recurrence_key)?;
            result.events.retain(|e| {
                e.uid != edit.uid
                    || e.recurrence_id
                        .as_ref()
                        .and_then(|r| r.key().ok())
                        .as_deref()
                        != Some(edit.recurrence_key.as_str())
            });
            event.recurrence_id = Some(rid);
        } else {
            result.events.retain(|e| e.uid != edit.uid);
        }
        result.events.push(event);
    }
    Ok(result)
}
pub fn project(
    calendar: &ParsedCalendar,
    source: &StoredSubscription,
) -> Result<ParsedCalendar, CalendarError> {
    let mut result = apply_edits(calendar, &source.local_edits)?;
    result
        .events
        .retain(|event| !source.deleted_series.contains(&event.uid));
    Ok(result)
}
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub(super) struct RelatedPattern {
    pub title: String,
    pub slot: String,
}
pub(super) fn related_pattern(
    event: &FeedEvent,
    source_zone: &str,
) -> Result<RelatedPattern, CalendarError> {
    let start = event.start.as_ref().ok_or("日程缺少开始时间")?;
    let slot = if start.all_day {
        format!("all-day:{}", event.duration.days)
    } else {
        let zone = source_zone
            .parse::<chrono_tz::Tz>()
            .map_err(|_| "来源解释时区无效")?;
        let first = start.instant()?.with_timezone(&zone);
        let last = event.duration.end(start)?.with_timezone(&zone);
        let span = (last.date_naive() - first.date_naive()).num_days();
        let clock = |value: chrono::DateTime<chrono_tz::Tz>| {
            use chrono::Timelike;
            value
                .format(if value.second() == 0 {
                    "%H:%M"
                } else {
                    "%H:%M:%S"
                })
                .to_string()
        };
        format!(
            "{}–{}{}",
            clock(first),
            clock(last),
            if span == 0 {
                String::new()
            } else {
                format!(" (+{span}d)")
            }
        )
    };
    Ok(RelatedPattern {
        title: event.original_title.clone(),
        slot,
    })
}
pub(super) fn related_groups(
    original: &ParsedCalendar,
    projected: &ParsedCalendar,
    source_zone: &str,
) -> Result<
    std::collections::BTreeMap<RelatedPattern, std::collections::BTreeSet<String>>,
    CalendarError,
> {
    let recurring_uids: std::collections::HashSet<_> = original
        .events
        .iter()
        .filter(|event| {
            event.rule.is_some() || !event.rdates.is_empty() || event.recurrence_id.is_some()
        })
        .map(|event| event.uid.as_str())
        .collect();
    let visible_uids: std::collections::HashSet<_> = projected
        .events
        .iter()
        .filter(|event| {
            !event.cancelled
                && event.start.as_ref().is_some_and(|start| {
                    let Ok(key) = start.key() else { return false };
                    // Like planned(), EXDATE removes the nominal key even without RRULE.
                    !event.exdates.iter().any(|excluded| {
                        excluded.key().is_ok_and(|excluded_key| excluded_key == key)
                    })
                })
        })
        .map(|event| event.uid.as_str())
        .collect();
    let mut groups: std::collections::BTreeMap<RelatedPattern, std::collections::BTreeSet<String>> =
        Default::default();
    for event in &original.events {
        if !event.cancelled
            && event.start.is_some()
            && !event.original_title.trim().is_empty()
            && !recurring_uids.contains(event.uid.as_str())
            && visible_uids.contains(event.uid.as_str())
        {
            groups
                .entry(related_pattern(event, source_zone)?)
                .or_default()
                .insert(event.uid.clone());
        }
    }
    Ok(groups)
}
impl Repository {
    pub fn delete_imported_related(
        &mut self,
        source_id: &str,
        uid: &str,
    ) -> Result<(), CalendarError> {
        let mut next = self.data.clone();
        let source = next
            .subscriptions
            .iter_mut()
            .find(|source| source.id == source_id)
            .ok_or("日历已移除")?;
        let original = super::ics::parse_calendar(
            &source.raw_ics,
            &source.input.fallback_zone,
            source.input.override_unknown_zone,
        )?;
        let selected = original
            .events
            .iter()
            .find(|event| event.uid == uid)
            .ok_or("这次导入安排已不存在，请重新打开")?;
        let projected = project(&original, source)?;
        let groups = related_groups(&original, &projected, &source.input.fallback_zone)?;
        let related = groups
            .get(&related_pattern(selected, &source.input.fallback_zone)?)
            .filter(|uids| uids.len() >= 2 && uids.contains(uid))
            .ok_or("没有可一起删除的相同时段安排，请重新打开")?;
        let mut deleted: std::collections::BTreeSet<_> =
            source.deleted_series.iter().cloned().collect();
        deleted.extend(related.iter().cloned());
        if deleted.len() > 10_000 {
            return Err("本地删除数量超过上限".into());
        }
        source.deleted_series = deleted.into_iter().collect();
        source.revision = source.revision.checked_add(1).ok_or("日历版本超出范围")?;
        self.commit(next)
    }
    pub fn delete_imported_series(
        &mut self,
        source_id: &str,
        uid: &str,
    ) -> Result<(), CalendarError> {
        let mut next = self.data.clone();
        let source = next
            .subscriptions
            .iter_mut()
            .find(|s| s.id == source_id)
            .ok_or("日历已移除")?;
        // A series identity is accepted only from this source's original cached feed.
        let parsed = super::ics::parse_calendar(
            &source.raw_ics,
            &source.input.fallback_zone,
            source.input.override_unknown_zone,
        )?;
        if !parsed.events.iter().any(|event| event.uid == uid) {
            return Err("这组导入安排已不存在，请重新打开".into());
        }
        if !source.deleted_series.iter().any(|deleted| deleted == uid) {
            if source.deleted_series.len() >= 10_000 {
                return Err("本地删除数量超过上限".into());
            }
            source.deleted_series.push(uid.into());
        }
        source.revision = source.revision.checked_add(1).ok_or("日历版本超出范围")?;
        self.commit(next)
    }
    pub fn edit_imported(
        &mut self,
        source_id: &str,
        uid: &str,
        key: &str,
        input: Option<ImportedInput>,
    ) -> Result<(), CalendarError> {
        self.change_imported(
            source_id,
            uid,
            key,
            input
                .map(ImportChange::Save)
                .unwrap_or(ImportChange::Restore),
        )
    }
    pub fn delete_imported(
        &mut self,
        source_id: &str,
        uid: &str,
        key: &str,
    ) -> Result<(), CalendarError> {
        self.change_imported(source_id, uid, key, ImportChange::Delete)
    }
    fn change_imported(
        &mut self,
        source_id: &str,
        uid: &str,
        key: &str,
        change: ImportChange,
    ) -> Result<(), CalendarError> {
        let mut next = self.data.clone();
        let source = next
            .subscriptions
            .iter_mut()
            .find(|s| s.id == source_id)
            .ok_or("日历已移除")?;
        let parsed = super::ics::parse_calendar(
            &source.raw_ics,
            &source.input.fallback_zone,
            source.input.override_unknown_zone,
        )?;
        let multi = recurring(&parsed, uid);
        let same = |edit: &ImportedEdit| edit.uid == uid && (!multi || edit.recurrence_key == key);
        if !matches!(&change, ImportChange::Restore) {
            let input = match change {
                ImportChange::Save(input) => {
                    input.event(uid)?;
                    Some(input)
                }
                ImportChange::Delete => None,
                ImportChange::Restore => unreachable!(),
            };
            // Validate the selected instance against the stored snapshot, not client metadata.
            let existing = source.local_edits.iter().any(same);
            let moved_exception = parsed.events.iter().any(|event| {
                event.uid == uid
                    && !event.cancelled
                    && event.start.is_some()
                    && event
                        .recurrence_id
                        .as_ref()
                        .and_then(|rid| rid.key().ok())
                        .as_deref()
                        == Some(key)
            });
            if !existing && !moved_exception {
                let date = key_time(key)?.wall.date().to_string();
                let range = OccurrenceRange {
                    from: date.clone(),
                    to: date,
                    display_zone: Some("UTC".into()),
                };
                let items = super::expand::expand_calendar(&parsed, &source.summary(), &range)?;
                if !items
                    .iter()
                    .any(|e| e.uid == uid && e.recurrence_key == key)
                {
                    return Err("这次导入安排已不存在，请重新打开".into());
                }
            }
            let original_key = source
                .local_edits
                .iter()
                .find(|e| same(e))
                .map(|e| e.recurrence_key.clone())
                .unwrap_or_else(|| key.into());
            source.local_edits.retain(|e| !same(e));
            if source.local_edits.len() >= 10_000 {
                return Err("本地修改数量超过上限".into());
            }
            source.local_edits.push(ImportedEdit {
                uid: uid.into(),
                recurrence_key: original_key,
                input,
            });
        } else {
            source.local_edits.retain(|e| !same(e));
        }
        source.revision = source.revision.checked_add(1).ok_or("日历版本超出范围")?;
        self.commit(next)
    }
}
