use super::{fetch::normalize_url, model::*, CalendarError};
use crate::storage::Repository;
use chrono::Utc;
impl Repository {
    pub fn save_subscription(
        &mut self,
        id: Option<&str>,
        input: &SourceInput,
        checked: Option<&CheckedFeed>,
    ) -> Result<StoredSubscription, CalendarError> {
        let mut input = input.clone();
        if input.url.trim().is_empty() {
            if let Some(source) =
                id.and_then(|id| self.data.subscriptions.iter().find(|s| s.id == id))
            {
                input.url = source.input.url.clone();
            }
        }
        input.validate()?;
        let mut next = self.data.clone();
        let mut config = input.clone();
        config.name = config.name.trim().to_string();
        config.url = normalize_url(&config.url)?.to_string();
        let existing = id
            .map(|id| {
                next.subscriptions
                    .iter()
                    .find(|s| s.id == id)
                    .cloned()
                    .ok_or_else(|| "这个日历来源已移除".to_string())
            })
            .transpose()?;
        let changed = existing.as_ref().is_none_or(|s| {
            s.input.url != config.url
                || s.input.fallback_zone != config.fallback_zone
                || s.input.override_unknown_zone != config.override_unknown_zone
        });
        if changed && checked.is_none() {
            return Err("请先检查链接，再确认订阅".into());
        }
        if let Some(feed) = checked {
            config.url = feed.canonical_url.clone();
        }
        if next
            .subscriptions
            .iter()
            .any(|s| Some(s.id.as_str()) != id && s.input.url == config.url)
        {
            return Err("这个链接已经订阅，可在原日历上立即刷新".into());
        }
        let now = Utc::now().to_rfc3339();
        let mut source = existing.unwrap_or_else(|| StoredSubscription {
            id: uuid::Uuid::new_v4().to_string(),
            revision: 0,
            feed_version: 0,
            input: config.clone(),
            raw_ics: String::new(),
            event_count: 0,
            etag: None,
            last_modified: None,
            last_attempt_at: None,
            last_success_at: None,
            last_error: None,
            local_edits: Vec::new(),
            deleted_series: Vec::new(),
        });
        source.input = config;
        source.revision = source.revision.checked_add(1).ok_or("来源版本超出范围")?;
        if let Some(feed) = checked {
            source.local_edits.clear();
            source.deleted_series.clear();
            source.raw_ics = feed.raw_ics.clone();
            source.etag = feed.etag.clone();
            source.last_modified = feed.last_modified.clone();
            source.event_count = feed.parsed.events.iter().filter(|e| !e.cancelled).count();
            source.feed_version = source
                .feed_version
                .checked_add(1)
                .ok_or("来源版本超出范围")?;
            source.last_attempt_at = Some(now.clone());
            source.last_success_at = Some(now);
            source.last_error = None;
        }
        next.subscriptions.retain(|s| s.id != source.id);
        next.subscriptions.push(source.clone());
        self.commit(next)?;
        Ok(source)
    }
    pub fn remove_subscription(&mut self, id: &str) -> Result<(), CalendarError> {
        if !self.data.subscriptions.iter().any(|s| s.id == id) {
            return Err("日历来源已移除".into());
        }
        let mut next = self.data.clone();
        next.subscriptions.retain(|s| s.id != id);
        self.commit(next)
    }
    pub fn commit_feed(
        &mut self,
        id: &str,
        revision: u64,
        feed: &CheckedFeed,
    ) -> Result<bool, CalendarError> {
        let mut next = self.data.clone();
        let Some(source) = next
            .subscriptions
            .iter_mut()
            .find(|s| s.id == id && s.revision == revision)
        else {
            return Ok(false);
        };
        if source.input.url != feed.canonical_url {
            return Err("来源链接已变更，请重新刷新".into());
        }
        let now = Utc::now().to_rfc3339();
        source.raw_ics = feed.raw_ics.clone();
        source.etag = feed.etag.clone();
        source.last_modified = feed.last_modified.clone();
        source.event_count = feed.parsed.events.iter().filter(|e| !e.cancelled).count();
        source.last_attempt_at = Some(now.clone());
        source.last_success_at = Some(now);
        source.last_error = None;
        source.feed_version = source
            .feed_version
            .checked_add(1)
            .ok_or("来源版本超出范围")?;
        self.commit(next)?;
        Ok(true)
    }
    pub fn mark_subscription_error(
        &mut self,
        id: &str,
        revision: u64,
        message: String,
    ) -> Result<bool, CalendarError> {
        let mut next = self.data.clone();
        let Some(source) = next
            .subscriptions
            .iter_mut()
            .find(|s| s.id == id && s.revision == revision)
        else {
            return Ok(false);
        };
        source.last_attempt_at = Some(Utc::now().to_rfc3339());
        source.last_error = Some(message);
        self.commit(next)?;
        Ok(true)
    }
    pub fn set_calendar_view(&mut self, prefs: CalendarViewPrefs) -> Result<(), CalendarError> {
        prefs.validate()?;
        let mut next = self.data.clone();
        next.calendar_view = prefs;
        self.commit(next)
    }
}
