use super::{
    expand::{display_zone, expand_calendar},
    model::*,
    service::CalendarService,
    CalendarError,
};
use crate::model::{CalendarItem, ItemKind, Reminder};
use chrono::{DateTime, Duration, Utc};
use std::collections::{BTreeMap, BTreeSet};

#[derive(Default)]
pub struct PreparedExternal {
    pub due: Vec<Reminder>,
    pub resolved: BTreeMap<String, Reminder>,
    pub preserve_pending: BTreeSet<String>,
    pub warnings: Vec<String>,
}
pub fn plans_current(
    current: &[StoredSubscription],
    captured: &[StoredSubscription],
    prefs: &CalendarViewPrefs,
    expected: &CalendarViewPrefs,
) -> bool {
    prefs == expected
        && current.len() == captured.len()
        && captured.iter().all(|s| {
            current.iter().any(|c| {
                c.id == s.id && c.revision == s.revision && c.feed_version == s.feed_version
            })
        })
}
pub fn is_external(key: &str) -> bool {
    key.starts_with("external|")
}
fn key_source(key: &str) -> Option<&str> {
    let mut parts = key.split('|');
    (parts.next() == Some("external"))
        .then(|| parts.next())
        .flatten()
}
fn reminder(
    item: &ExternalOccurrence,
    lead: i64,
    zone: Option<&str>,
) -> Result<Option<Reminder>, CalendarError> {
    let Some(start) = item
        .start_utc
        .as_ref()
        .and_then(|s| DateTime::parse_from_rfc3339(s).ok())
        .map(|d| d.with_timezone(&Utc))
    else {
        return Ok(None);
    };
    let display = display_zone(zone)?;
    let clock = start.with_timezone(&display);
    let end = item
        .end_utc
        .as_ref()
        .and_then(|s| DateTime::parse_from_rfc3339(s).ok())
        .map(|d| d.with_timezone(&display));
    let key = format!(
        "external|{}|{}|{}|{}",
        item.source_id,
        item.id,
        start.to_rfc3339(),
        lead
    );
    Ok(Some(Reminder {
        key,
        item: CalendarItem {
            id: item.id.clone(),
            kind: ItemKind::Event,
            title: item.title.clone(),
            date: clock.date_naive().to_string(),
            time: Some(clock.format("%H:%M").to_string()),
            end_time: end
                .filter(|d| d.date_naive() == clock.date_naive())
                .map(|d| d.format("%H:%M").to_string()),
            notes: format!(
                "{}{}{}",
                item.source_name,
                if item.location.is_empty() { "" } else { " · " },
                item.location
            ),
            reminder_minutes: Some(lead),
            completed: false,
            created_at: String::new(),
            updated_at: String::new(),
            recurrence: None,
            exceptions: Default::default(),
            series_id: None,
            occurrence_date: None,
        },
    }))
}
pub fn resolve_external_plan(
    service: &CalendarService,
    key: &str,
    sources: &[StoredSubscription],
    zone: Option<&str>,
) -> Result<Option<Reminder>, CalendarError> {
    let parts: Vec<_> = key.split('|').collect();
    if parts.len() != 5 || parts[0] != "external" {
        return Ok(None);
    }
    let Some(source) = sources.iter().find(|s| s.id == parts[1]) else {
        return Ok(None);
    };
    let Some(lead) = source.input.reminder_minutes else {
        return Ok(None);
    };
    if parts[4].parse::<i64>().ok() != Some(lead) {
        return Ok(None);
    }
    let Some(at) = DateTime::parse_from_rfc3339(parts[3])
        .ok()
        .map(|d| d.with_timezone(&Utc))
    else {
        return Ok(None);
    };
    let day = at
        .with_timezone(&display_zone(zone)?)
        .date_naive()
        .to_string();
    let range = OccurrenceRange {
        from: day.clone(),
        to: day,
        display_zone: zone.map(str::to_string),
    };
    let parsed = service.parsed(source)?;
    for item in expand_calendar(&parsed, &source.summary(), &range)? {
        if item.id == parts[2] {
            if let Some(r) = reminder(&item, lead, zone)? {
                if r.key == key {
                    return Ok(Some(r));
                }
            }
        }
    }
    Ok(None)
}
pub fn prepare_external(
    service: &CalendarService,
    sources: &[StoredSubscription],
    pending: &[String],
    now: DateTime<Utc>,
    zone: Option<&str>,
) -> PreparedExternal {
    let mut result = PreparedExternal::default();
    let display = match display_zone(zone) {
        Ok(z) => z,
        Err(e) => {
            result.warnings.push(e);
            return result;
        }
    };
    let day = now.with_timezone(&display).date_naive();
    let range = OccurrenceRange {
        from: (day - Duration::days(1)).to_string(),
        to: (day + Duration::days(1)).to_string(),
        display_zone: zone.map(str::to_string),
    };
    let mut failed = BTreeSet::new();
    let mut seen = BTreeSet::new();
    for source in sources
        .iter()
        .filter(|s| s.input.reminder_minutes.is_some())
    {
        let prepare = (|| -> Result<Vec<Reminder>, CalendarError> {
            let parsed = service.parsed(source)?;
            let items = expand_calendar(&parsed, &source.summary(), &range)?;
            let lead = source.input.reminder_minutes.unwrap_or(0);
            let mut reminders = Vec::new();
            for item in items {
                if let Some(r) = reminder(&item, lead, zone)? {
                    let Some(start) = item
                        .start_utc
                        .as_ref()
                        .and_then(|s| DateTime::parse_from_rfc3339(s).ok())
                        .map(|d| d.with_timezone(&Utc))
                    else {
                        continue;
                    };
                    let trigger = start - Duration::minutes(lead);
                    let elapsed = now - trigger;
                    let since_start = now - start;
                    if elapsed >= Duration::zero()
                        && (elapsed <= Duration::minutes(15)
                            || (since_start >= Duration::zero()
                                && since_start <= Duration::minutes(15)))
                    {
                        reminders.push(r);
                    }
                }
            }
            Ok(reminders)
        })();
        match prepare {
            Ok(reminders) => {
                for r in reminders {
                    if seen.insert(r.key.clone()) {
                        result.resolved.insert(r.key.clone(), r.clone());
                        result.due.push(r);
                    }
                }
            }
            Err(e) => {
                failed.insert(source.id.clone());
                result.warnings.push(format!("{}：{e}", source.input.name));
            }
        }
    }
    for key in pending.iter().filter(|k| is_external(k)) {
        match resolve_external_plan(service, key, sources, zone) {
            Ok(Some(r)) => {
                result.resolved.insert(key.clone(), r);
            }
            Ok(None) => {}
            Err(e) => {
                if let Some(id) = key_source(key) {
                    if sources
                        .iter()
                        .any(|s| s.id == id && s.input.reminder_minutes.is_some())
                    {
                        result.preserve_pending.insert(key.clone());
                        if failed.insert(id.into()) {
                            result.warnings.push(e);
                        }
                    }
                }
            }
        }
    }
    result.due.sort_by(|a, b| a.key.cmp(&b.key));
    result
}
