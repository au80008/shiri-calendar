pub mod expand;
pub mod fetch;
pub mod ics;
pub mod imports;
pub mod model;
pub mod reminders;
pub mod repository;
pub mod service;
pub mod timezones;

pub type CalendarError = String;
pub const MAX_FEED_BYTES: usize = 10 * 1024 * 1024;
pub const MAX_COMPONENTS: usize = 50_000;
pub const MAX_OCCURRENCES: usize = 10_000;
