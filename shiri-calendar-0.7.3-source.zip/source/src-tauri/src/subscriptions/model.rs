use super::CalendarError;
use calcard::common::timezone::Tz;
use chrono::{DateTime, Duration, NaiveDateTime, TimeZone, Utc};
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug)]
pub struct EventTime {
    pub wall: NaiveDateTime,
    pub zone: Tz,
    pub all_day: bool,
}
impl EventTime {
    pub fn instant(&self) -> Result<DateTime<Utc>, CalendarError> {
        self.zone
            .from_local_datetime(&self.wall)
            .earliest()
            .map(|v| v.with_timezone(&Utc))
            .ok_or_else(|| "课程时间落在夏令时不存在的时刻，请检查来源时间".into())
    }
    pub fn key(&self) -> Result<String, CalendarError> {
        if self.all_day {
            Ok(self.wall.format("%Y%m%d").to_string())
        } else {
            Ok(self.instant()?.format("%Y%m%dT%H%M%SZ").to_string())
        }
    }
}
#[derive(Clone, Debug, Default)]
pub struct EventDuration {
    pub days: i64,
    pub seconds: i64,
}
impl EventDuration {
    pub fn end(&self, start: &EventTime) -> Result<DateTime<Utc>, CalendarError> {
        let wall = start
            .wall
            .checked_add_signed(Duration::try_days(self.days).ok_or("课程时长超出范围")?)
            .ok_or("课程时长超出范围")?;
        EventTime {
            wall,
            ..start.clone()
        }
        .instant()?
        .checked_add_signed(Duration::try_seconds(self.seconds).ok_or("课程时长超出范围")?)
        .ok_or_else(|| "课程时长超出范围".into())
    }
}
#[derive(Clone, Debug)]
pub struct FeedEvent {
    pub uid: String,
    pub title: String,
    pub original_title: String,
    pub description: String,
    pub location: String,
    pub start: Option<EventTime>,
    pub duration: EventDuration,
    pub rule: Option<String>,
    pub rdates: Vec<EventTime>,
    pub exdates: Vec<EventTime>,
    pub recurrence_id: Option<EventTime>,
    pub cancelled: bool,
    pub sequence: i64,
    pub stamp: i64,
    pub present: std::collections::BTreeSet<String>,
}
#[derive(Clone, Debug)]
pub struct ParsedCalendar {
    pub name: Option<String>,
    pub events: Vec<FeedEvent>,
    pub unsupported_count: usize,
    pub embedded_zones: Vec<super::timezones::EmbeddedZone>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CalendarSourceSummary {
    pub id: String,
    pub name: String,
    pub host: String,
    pub color: String,
    pub visible: bool,
    pub fallback_zone: String,
    pub override_unknown_zone: bool,
    pub reminder_minutes: Option<i64>,
    pub revision: u64,
    pub feed_version: u64,
    pub event_count: usize,
    pub last_attempt_at: Option<String>,
    pub last_success_at: Option<String>,
    pub last_error: Option<String>,
    pub refreshing: bool,
}
impl Default for CalendarSourceSummary {
    fn default() -> Self {
        Self {
            id: String::new(),
            name: String::new(),
            host: String::new(),
            color: "#5594c8".into(),
            visible: true,
            fallback_zone: "Europe/Copenhagen".into(),
            override_unknown_zone: false,
            reminder_minutes: None,
            revision: 0,
            feed_version: 0,
            event_count: 0,
            last_attempt_at: None,
            last_success_at: None,
            last_error: None,
            refreshing: false,
        }
    }
}

pub const COLORS: [&str; 6] = [
    "#5594c8", "#7b8f65", "#9d7abb", "#c99c49", "#d27b91", "#ed714e",
];
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct SourceInput {
    pub name: String,
    pub url: String,
    pub color: String,
    pub visible: bool,
    pub fallback_zone: String,
    #[serde(default)]
    pub override_unknown_zone: bool,
    pub reminder_minutes: Option<i64>,
}
impl Default for SourceInput {
    fn default() -> Self {
        Self {
            name: "日历".into(),
            url: String::new(),
            color: COLORS[0].into(),
            visible: true,
            fallback_zone: "Europe/Copenhagen".into(),
            override_unknown_zone: false,
            reminder_minutes: None,
        }
    }
}
impl SourceInput {
    pub fn validate(&self) -> Result<(), CalendarError> {
        if self.name.trim().is_empty() || self.name.chars().count() > 80 {
            return Err("日历名称需为 1–80 字".into());
        }
        if !COLORS.contains(&self.color.as_str()) {
            return Err("请选择日历颜色".into());
        }
        super::fetch::normalize_url(&self.url)?;
        self.fallback_zone
            .parse::<chrono_tz::Tz>()
            .map_err(|_| "请选择有效的 IANA 解释时区")?;
        if self
            .reminder_minutes
            .is_some_and(|n| ![0, 5, 10, 30].contains(&n))
        {
            return Err("提醒时间无效".into());
        }
        Ok(())
    }
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct StoredSubscription {
    pub id: String,
    pub revision: u64,
    pub feed_version: u64,
    #[serde(flatten)]
    pub input: SourceInput,
    pub raw_ics: String,
    pub event_count: usize,
    pub etag: Option<String>,
    pub last_modified: Option<String>,
    pub last_attempt_at: Option<String>,
    pub last_success_at: Option<String>,
    pub last_error: Option<String>,
    #[serde(default)]
    pub local_edits: Vec<super::imports::ImportedEdit>,
    #[serde(default)]
    pub deleted_series: Vec<String>,
}
impl StoredSubscription {
    pub fn summary(&self) -> CalendarSourceSummary {
        CalendarSourceSummary {
            id: self.id.clone(),
            name: self.input.name.clone(),
            host: super::fetch::normalize_url(&self.input.url)
                .ok()
                .and_then(|u| u.host_str().map(str::to_string))
                .unwrap_or_default(),
            color: self.input.color.clone(),
            visible: self.input.visible,
            fallback_zone: self.input.fallback_zone.clone(),
            override_unknown_zone: self.input.override_unknown_zone,
            reminder_minutes: self.input.reminder_minutes,
            revision: self.revision,
            feed_version: self.feed_version,
            event_count: self.event_count,
            last_attempt_at: self.last_attempt_at.clone(),
            last_success_at: self.last_success_at.clone(),
            last_error: self.last_error.clone(),
            refreshing: false,
        }
    }
}
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct CalendarViewPrefs {
    pub display_zone: Option<String>,
    pub local_visible: bool,
}
impl Default for CalendarViewPrefs {
    fn default() -> Self {
        Self {
            display_zone: None,
            local_visible: true,
        }
    }
}
impl CalendarViewPrefs {
    pub fn validate(&self) -> Result<(), CalendarError> {
        super::expand::display_zone(self.display_zone.as_deref()).map(|_| ())
    }
}

#[derive(Clone, Debug)]
pub struct CheckedFeed {
    pub canonical_url: String,
    pub raw_ics: String,
    pub etag: Option<String>,
    pub last_modified: Option<String>,
    pub parsed: std::sync::Arc<ParsedCalendar>,
    pub corrected: bool,
}
#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PreviewSample {
    pub title: String,
    pub date: String,
    pub time: Option<String>,
    pub location: String,
}
#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PreviewResult {
    pub ticket: String,
    pub canonical_host: String,
    pub calendar_name: Option<String>,
    pub event_count: usize,
    pub unsupported_count: usize,
    pub first_date: Option<String>,
    pub last_date: Option<String>,
    pub samples: Vec<PreviewSample>,
    pub warnings: Vec<String>,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SourceWarning {
    pub source_id: String,
    pub message: String,
}
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct OccurrenceBatch {
    pub items: Vec<ExternalOccurrence>,
    pub warnings: Vec<SourceWarning>,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct OccurrenceRange {
    pub from: String,
    pub to: String,
    pub display_zone: Option<String>,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ExternalOccurrence {
    pub id: String,
    pub source_id: String,
    pub source_name: String,
    pub color: String,
    pub uid: String,
    pub recurrence_key: String,
    pub start_utc: Option<String>,
    pub end_utc: Option<String>,
    pub all_day: bool,
    pub date: String,
    pub time: Option<String>,
    pub end_time: Option<String>,
    pub title: String,
    pub description: String,
    pub location: String,
    pub continued_before: bool,
    pub continues_after: bool,
    #[serde(default)]
    pub start_date: String,
    #[serde(default)]
    pub end_date: String,
    #[serde(default)]
    pub locally_edited: bool,
    #[serde(default)]
    pub recurring: bool,
    #[serde(default)]
    pub related_title: Option<String>,
    #[serde(default)]
    pub related_slot: Option<String>,
    #[serde(default)]
    pub related_count: usize,
}
