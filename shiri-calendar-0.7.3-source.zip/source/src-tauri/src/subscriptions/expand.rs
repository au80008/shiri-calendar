use super::{ics::recurrence_set, model::*, CalendarError, MAX_OCCURRENCES};
use chrono::{DateTime, Datelike, Duration, Local, NaiveDate, TimeZone, Utc};
use std::{collections::BTreeMap, time::Instant};

pub fn display_zone(zone: Option<&str>) -> Result<rrule::Tz, CalendarError> {
    zone.map_or(Ok(rrule::Tz::Local(Local)), |s| {
        s.parse::<chrono_tz::Tz>()
            .map(rrule::Tz::Tz)
            .map_err(|_| "显示时区无效".into())
    })
}
pub fn civil_date(s: &str) -> Result<NaiveDate, CalendarError> {
    let d = NaiveDate::parse_from_str(s, "%Y-%m-%d").map_err(|_| "查询日期无效")?;
    if d.format("%Y-%m-%d").to_string() != s || !("1900-01-01"..="9999-12-31").contains(&s) {
        return Err("查询日期需在 1900–9999 年之间".into());
    }
    Ok(d)
}
pub fn external_id(source_id: &str, uid: &str, recurrence_key: &str) -> String {
    let namespace = uuid::Uuid::parse_str(source_id).unwrap_or(uuid::Uuid::NAMESPACE_URL);
    let tuple = serde_json::to_vec(&(source_id, uid, recurrence_key)).unwrap_or_default();
    format!("ext:{}", uuid::Uuid::new_v5(&namespace, &tuple))
}
fn recurrence_bound(at: DateTime<Utc>, start: &EventTime) -> DateTime<rrule::Tz> {
    rrule::Tz::UTC.from_utc_datetime(&at.with_timezone(&start.zone).naive_local())
}
fn planned(
    event: &FeedEvent,
    lower: DateTime<Utc>,
    upper: DateTime<Utc>,
    began: Instant,
    history_work: &mut usize,
) -> Result<BTreeMap<String, EventTime>, CalendarError> {
    let mut dates = BTreeMap::new();
    let Some(start) = &event.start else {
        return Ok(dates);
    };
    dates.insert(start.key()?, start.clone());
    if event.rule.is_some() {
        let seconds = event
            .duration
            .days
            .checked_mul(90000)
            .and_then(|d| d.checked_add(event.duration.seconds))
            .and_then(|d| d.checked_add(172800))
            .ok_or("课程时长超出范围")?;
        let lower = lower
            .checked_sub_signed(Duration::try_seconds(seconds).ok_or("课程时长超出范围")?)
            .ok_or("课程时长超出范围")?;
        let original = recurrence_set(event)?;
        let count = original.get_rrule()[0].get_count();
        let mut adjusted = count;
        loop {
            if began.elapsed().as_secs() >= 2 {
                return Err("日历展开超时".into());
            }
            let mut set = original.clone();
            if let Some(n) = adjusted {
                let mut adjusted_event = event.clone();
                adjusted_event.rule = event.rule.as_ref().map(|r| {
                    r.split(';')
                        .map(|p| {
                            if p.starts_with("COUNT=") {
                                format!("COUNT={n}")
                            } else {
                                p.to_owned()
                            }
                        })
                        .collect::<Vec<_>>()
                        .join(";")
                });
                set = recurrence_set(&adjusted_event)?;
            }
            // `after()` filters outputs inside rrule, so skipped history would
            // evade all(limit). Count every historical result before filtering.
            let result = set.before(recurrence_bound(upper, start)).all(u16::MAX);
            *history_work = history_work.saturating_add(result.dates.len());
            if began.elapsed().as_secs() >= 2 {
                return Err("日历展开超时，请缩小来源范围".into());
            }
            if result.limited || *history_work >= usize::from(u16::MAX) {
                return Err("日历重复展开超过上限，请缩小来源或查询范围".into());
            }
            let generated = result.dates.len();
            let mut missing = 0u32;
            let mut valid = Vec::new();
            for date in result.dates {
                let time = EventTime {
                    wall: date.naive_utc(),
                    ..start.clone()
                };
                if time.instant().is_ok() {
                    valid.push(time);
                } else {
                    missing += 1;
                }
            }
            if let Some(n) = count {
                if valid.len() < (n as usize)
                    && generated >= adjusted.unwrap_or(n) as usize
                    && missing > 0
                {
                    adjusted = Some(n.checked_add(missing).ok_or("重复次数超出范围")?);
                    continue;
                }
                valid.truncate(n as usize);
            }
            for time in valid {
                if count.is_some() || time.instant()? >= lower {
                    dates.insert(time.key()?, time);
                }
            }
            break;
        }
    }
    for t in &event.rdates {
        dates.insert(t.key()?, t.clone());
    }
    for t in &event.exdates {
        dates.remove(&t.key()?);
    }
    Ok(dates)
}

struct Projection<'a> {
    source: &'a CalendarSourceSummary,
    from: NaiveDate,
    to: NaiveDate,
    zone: rrule::Tz,
    items: Vec<ExternalOccurrence>,
    bytes: usize,
    began: Instant,
}
impl Projection<'_> {
    fn add(
        &mut self,
        master: &FeedEvent,
        event: &FeedEvent,
        start: &EventTime,
        key: &str,
        recurring: bool,
    ) -> Result<(), CalendarError> {
        if self.began.elapsed().as_secs() >= 2 {
            return Err("日历展开超时，请缩小来源范围".into());
        }
        let begin = start.instant()?;
        let duration = if event.recurrence_id.is_some()
            && !event.present.contains("Dtend")
            && !event.present.contains("Duration")
        {
            &master.duration
        } else {
            &event.duration
        };
        let end = duration.end(start)?;
        let first = if start.all_day {
            start.wall.date()
        } else {
            begin.with_timezone(&self.zone).date_naive()
        };
        let last = if start.all_day {
            (start.wall + Duration::days(duration.days.max(1) - 1)).date()
        } else if end > begin {
            (end - Duration::nanoseconds(1))
                .with_timezone(&self.zone)
                .date_naive()
        } else {
            first
        };
        let mut day = first.max(self.from);
        let title = if event.recurrence_id.is_some() && !event.present.contains("Summary") {
            &master.title
        } else {
            &event.title
        };
        let description = if event.recurrence_id.is_some() && !event.present.contains("Description")
        {
            &master.description
        } else {
            &event.description
        };
        let location = if event.recurrence_id.is_some() && !event.present.contains("Location") {
            &master.location
        } else {
            &event.location
        };
        while day <= last.min(self.to) {
            let bytes = title.len()
                + description.len()
                + location.len()
                + master.uid.len()
                + self.source.name.len()
                + 512;
            self.bytes = self
                .bytes
                .checked_add(bytes)
                .ok_or("日历显示内容超过上限")?;
            if self.items.len() >= MAX_OCCURRENCES || self.bytes > 16 * 1024 * 1024 {
                return Err("日历显示内容超过上限，请缩小来源范围".into());
            }
            self.items.push(ExternalOccurrence {
                id: external_id(&self.source.id, &master.uid, key),
                source_id: self.source.id.clone(),
                source_name: self.source.name.clone(),
                color: self.source.color.clone(),
                uid: master.uid.clone(),
                recurrence_key: key.into(),
                start_utc: (!start.all_day).then(|| begin.to_rfc3339()),
                end_utc: (!start.all_day).then(|| end.to_rfc3339()),
                all_day: start.all_day,
                date: day.to_string(),
                time: (!start.all_day).then(|| {
                    if day > first {
                        "00:00".into()
                    } else {
                        begin.with_timezone(&self.zone).format("%H:%M").to_string()
                    }
                }),
                end_time: (!start.all_day).then(|| {
                    if day < last || end.with_timezone(&self.zone).date_naive() > day {
                        "24:00".into()
                    } else {
                        end.with_timezone(&self.zone).format("%H:%M").to_string()
                    }
                }),
                title: title.clone(),
                description: description.clone(),
                location: location.clone(),
                continued_before: day > first,
                continues_after: day < last,
                start_date: first.to_string(),
                end_date: if start.all_day {
                    last.to_string()
                } else {
                    end.with_timezone(&self.zone).date_naive().to_string()
                },
                locally_edited: event.present.contains("LocalEdit"),
                recurring,
                related_title: None,
                related_slot: None,
                related_count: 0,
            });
            let Some(next) = day.succ_opt() else { break };
            day = next;
        }
        Ok(())
    }
}
pub fn expand_calendar(
    calendar: &ParsedCalendar,
    source: &CalendarSourceSummary,
    range: &OccurrenceRange,
) -> Result<Vec<ExternalOccurrence>, CalendarError> {
    let from = civil_date(&range.from)?;
    let to = civil_date(&range.to)?;
    if from > to || (to - from).num_days() >= 126 {
        return Err("每次查询需为 1–126 天".into());
    }
    super::timezones::validate_years(
        &calendar.embedded_zones,
        &(from.year()..=to.year()).collect(),
    )?;
    let zone = display_zone(range.display_zone.as_deref())?;
    let lower = zone
        .from_local_datetime(&from.and_hms_opt(0, 0, 0).ok_or("查询日期无效")?)
        .earliest()
        .ok_or("查询日期无效")?
        .with_timezone(&Utc);
    let upper = zone
        .from_local_datetime(
            &to.succ_opt()
                .ok_or("查询日期超出范围")?
                .and_hms_opt(0, 0, 0)
                .ok_or("查询日期无效")?,
        )
        .earliest()
        .ok_or("查询日期无效")?
        .with_timezone(&Utc);
    let mut groups: BTreeMap<&str, Vec<&FeedEvent>> = BTreeMap::new();
    for event in &calendar.events {
        groups.entry(&event.uid).or_default().push(event);
    }
    let mut projection = Projection {
        source,
        from,
        to,
        zone,
        items: Vec::new(),
        bytes: 0,
        began: Instant::now(),
    };
    let mut history_work = 0;
    for events in groups.values() {
        if projection.began.elapsed().as_secs() >= 2 {
            return Err("日历展开超时，请缩小来源范围".into());
        }
        let master = events.iter().find(|e| e.recurrence_id.is_none()).copied();
        let recurring = events.iter().any(|event| {
            event.rule.is_some() || !event.rdates.is_empty() || event.recurrence_id.is_some()
        });
        if master.is_some_and(|e| e.cancelled) {
            continue;
        }
        let mut exceptions = BTreeMap::new();
        for event in events {
            if let Some(rid) = &event.recurrence_id {
                exceptions.insert(rid.key()?, *event);
            }
        }
        if let Some(master) = master {
            for (key, time) in planned(master, lower, upper, projection.began, &mut history_work)? {
                if !exceptions.contains_key(&key) {
                    projection.add(master, master, &time, &key, recurring)?;
                }
            }
        }
        for (key, event) in exceptions {
            if !event.cancelled {
                if let Some(start) = &event.start {
                    projection.add(master.unwrap_or(event), event, start, &key, recurring)?;
                }
            }
        }
    }
    projection
        .items
        .sort_by(|a, b| (&a.date, &a.time, &a.id).cmp(&(&b.date, &b.time, &b.id)));
    Ok(projection.items)
}
