//! Verify embedded observances before using an IANA/Windows alias. Custom
//! definitions that disagree must never silently inherit another zone's rules.
use super::CalendarError;
use calcard::{
    common::timezone::Tz,
    icalendar::{
        ICalendar, ICalendarComponent, ICalendarComponentType as C, ICalendarProperty as K,
        ICalendarValue as V,
    },
};
use chrono::{Duration, NaiveDate, NaiveDateTime, Offset, TimeZone, Utc};
use rrule::{RRule, RRuleSet, Unvalidated};
use std::collections::BTreeSet;

#[derive(Clone, Debug)]
struct Observance {
    start: NaiveDateTime,
    from: i32,
    to: i32,
    rule: Option<String>,
    dates: Vec<NaiveDateTime>,
}
#[derive(Clone, Debug)]
pub struct EmbeddedZone {
    zone: Tz,
    observances: Vec<Observance>,
}
const ERROR: &str = "内嵌时区定义无法确认或与标准时区不同；请选择解释时区并明确允许替代 TZID 时区";
fn value(c: &ICalendarComponent, k: K) -> Result<&V, CalendarError> {
    if c.properties(&k).count() != 1 {
        return Err(ERROR.into());
    }
    c.property(&k)
        .and_then(|p| p.values.first())
        .ok_or_else(|| ERROR.into())
}
fn wall(v: &V) -> Result<NaiveDateTime, CalendarError> {
    let V::PartialDateTime(p) = v else {
        return Err(ERROR.into());
    };
    if p.hour.is_none() {
        return Err(ERROR.into());
    }
    p.to_date_time()
        .map(|d| d.date_time)
        .ok_or_else(|| ERROR.into())
}
fn offset(v: &V) -> Result<i32, CalendarError> {
    let V::PartialDateTime(p) = v else {
        return Err(ERROR.into());
    };
    let hours = p.tz_hour.ok_or(ERROR)?;
    let minutes = p.tz_minute.ok_or(ERROR)?;
    let seconds = i32::from(hours) * 3600 + i32::from(minutes) * 60;
    if seconds.abs() >= 86400 {
        return Err(ERROR.into());
    }
    Ok(if p.tz_minus { -seconds } else { seconds })
}
pub fn embedded_zones(
    calendar: &ICalendar,
    force: bool,
) -> Result<Vec<EmbeddedZone>, CalendarError> {
    if force {
        return Ok(Vec::new());
    }
    let resolver = calendar.build_tz_resolver();
    let mut zones = Vec::new();
    for c in calendar
        .components
        .iter()
        .filter(|c| c.component_type == C::VTimezone)
    {
        let name = value(c, K::Tzid)?.as_text().ok_or(ERROR)?;
        let Some(zone) = resolver.resolve(name).filter(|z| !z.is_floating()) else {
            continue;
        };
        let mut observances = Vec::new();
        for id in &c.component_ids {
            let obs = calendar.components.get(*id as usize).ok_or(ERROR)?;
            if !matches!(obs.component_type, C::Standard | C::Daylight) {
                return Err(ERROR.into());
            }
            let start = wall(value(obs, K::Dtstart)?)?;
            let from = offset(value(obs, K::Tzoffsetfrom)?)?;
            let to = offset(value(obs, K::Tzoffsetto)?)?;
            let rule = obs
                .property(&K::Rrule)
                .map(|p| match p.values.first() {
                    Some(V::RecurrenceRule(r)) => {
                        // DTSTART is enumerated as a civil UTC clock. UNTIL
                        // in a VTIMEZONE is an absolute UTC boundary, so move
                        // it into the same clock using TZOFFSETFROM first.
                        let mut r = (**r).clone();
                        if let Some(until) = &mut r.until {
                            let absolute = until.to_date_time().ok_or(ERROR)?;
                            let offset = absolute.offset.ok_or(ERROR)?.local_minus_utc();
                            let local = absolute
                                .date_time
                                .checked_add_signed(Duration::seconds(i64::from(from - offset)))
                                .ok_or(ERROR)?;
                            use chrono::{Datelike, Timelike};
                            until.year = Some(local.year().try_into().map_err(|_| ERROR)?);
                            until.month = Some(local.month() as u8);
                            until.day = Some(local.day() as u8);
                            until.hour = Some(local.hour() as u8);
                            until.minute = Some(local.minute() as u8);
                            until.second = Some(local.second() as u8);
                            until.tz_hour = Some(0);
                            until.tz_minute = Some(0);
                            until.tz_minus = false;
                        }
                        Ok(r.to_string())
                    }
                    _ => Err(ERROR.to_owned()),
                })
                .transpose()?;
            if rule
                .as_ref()
                .is_some_and(|r| !r.split(';').any(|p| p == "FREQ=YEARLY"))
            {
                return Err(ERROR.into());
            }
            let mut dates = Vec::new();
            for p in obs.properties(&K::Rdate) {
                for v in &p.values {
                    dates.push(wall(v)?);
                }
            }
            observances.push(Observance {
                start,
                from,
                to,
                rule,
                dates,
            });
        }
        if observances.is_empty() || observances.len() > 64 {
            return Err(ERROR.into());
        }
        zones.push(EmbeddedZone { zone, observances });
    }
    Ok(zones)
}
pub fn validate_years(zones: &[EmbeddedZone], years: &BTreeSet<i32>) -> Result<(), CalendarError> {
    if zones.is_empty() || years.is_empty() {
        return Ok(());
    }
    let began = std::time::Instant::now();
    let mut work = 0usize;
    let end = NaiveDate::from_ymd_opt(
        years
            .last()
            .copied()
            .ok_or(ERROR)?
            .checked_add(1)
            .ok_or(ERROR)?,
        1,
        1,
    )
    .ok_or(ERROR)?
    .and_hms_opt(0, 0, 0)
    .ok_or(ERROR)?;
    for zone in zones {
        let mut transitions = Vec::new();
        for obs in &zone.observances {
            let mut dates = vec![obs.start];
            dates.extend(obs.dates.iter().copied());
            if let Some(rule) = &obs.rule {
                let anchor = rrule::Tz::UTC.from_utc_datetime(&obs.start);
                let parsed = rule
                    .parse::<RRule<Unvalidated>>()
                    .map_err(|_| ERROR)?
                    .validate(anchor)
                    .map_err(|_| ERROR)?;
                let result = RRuleSet::new(anchor)
                    .rrule(parsed)
                    .before(rrule::Tz::UTC.from_utc_datetime(&end))
                    .all(10000);
                work = work.saturating_add(result.dates.len());
                if result.limited || work > 65535 || began.elapsed().as_secs() >= 2 {
                    return Err(ERROR.into());
                }
                dates.extend(result.dates.into_iter().map(|d| d.naive_utc()));
            }
            for date in dates {
                transitions.push((
                    date.checked_sub_signed(Duration::seconds(i64::from(obs.from)))
                        .ok_or(ERROR)?,
                    obs.from,
                    obs.to,
                ));
            }
        }
        transitions.sort_unstable();
        transitions.dedup();
        for year in years {
            if began.elapsed().as_secs() >= 2 {
                return Err(ERROR.into());
            }
            let first = NaiveDate::from_ymd_opt(*year, 1, 1)
                .ok_or(ERROR)?
                .and_hms_opt(0, 0, 0)
                .ok_or(ERROR)?;
            let last = NaiveDate::from_ymd_opt(year.checked_add(1).ok_or(ERROR)?, 1, 1)
                .ok_or(ERROR)?
                .and_hms_opt(0, 0, 0)
                .ok_or(ERROR)?;
            let mut probes = vec![first, last - Duration::seconds(1)];
            for (at, _, _) in transitions
                .iter()
                .filter(|(at, _, _)| *at >= first && *at < last)
            {
                probes.push(*at);
                probes.push(*at - Duration::seconds(1));
            }
            // Compare both sides of every IANA transition too. Daily probes
            // prevent missing a seasonal period absent from the embedded rules.
            let mut day = first;
            while day < last {
                probes.push(day);
                day += Duration::days(1);
            }
            for at in probes {
                work = work.saturating_add(1);
                if work > 65535 || began.elapsed().as_secs() >= 2 {
                    return Err(ERROR.into());
                }
                let pos = transitions.partition_point(|(t, _, _)| *t <= at);
                let expected = pos
                    .checked_sub(1)
                    .and_then(|i| transitions.get(i))
                    .map(|(_, _, to)| *to)
                    .or_else(|| transitions.first().map(|(_, from, _)| *from))
                    .ok_or(ERROR)?;
                let actual = Utc
                    .from_utc_datetime(&at)
                    .with_timezone(&zone.zone)
                    .offset()
                    .fix()
                    .local_minus_utc();
                if expected != actual {
                    return Err(ERROR.into());
                }
            }
        }
    }
    Ok(())
}
