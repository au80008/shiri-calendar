use super::{model::*, CalendarError, MAX_COMPONENTS, MAX_FEED_BYTES};
use calcard::{
    common::{timezone::Tz, PartialDateTime},
    icalendar::{
        timezone::TzResolver, ICalendarComponent, ICalendarComponentType as C, ICalendarEntry,
        ICalendarParameterName as P, ICalendarProperty as K, ICalendarStatus, ICalendarValue as V,
    },
    Entry, Parser,
};
use chrono::{Datelike, TimeZone};
use rrule::{RRule, RRuleSet, Unvalidated};
use std::{collections::BTreeMap, time::Instant};

fn text(c: &ICalendarComponent, prop: K) -> String {
    c.property(&prop)
        .and_then(|p| p.values.first())
        .and_then(V::as_text)
        .unwrap_or("")
        .to_string()
}
fn times(
    entry: &ICalendarEntry,
    resolver: &TzResolver<&str>,
    fallback: Tz,
    force: bool,
) -> Result<Vec<EventTime>, CalendarError> {
    let tz = entry.parameter(&P::Tzid).and_then(|v| v.as_text());
    if entry.has_parameter(&P::Range) {
        return Err("暂不支持 RANGE=THISANDFUTURE，请使用逐次改期的订阅来源".into());
    }
    entry
        .values
        .iter()
        .map(|v| {
            let V::PartialDateTime(value) = v else {
                return Err("日历包含无法识别的日期或 RDATE 时段，请检查来源".into());
            };
            time(value, tz, resolver, fallback, force)
        })
        .collect()
}
fn time(
    value: &PartialDateTime,
    tz: Option<&str>,
    resolver: &TzResolver<&str>,
    fallback: Tz,
    force: bool,
) -> Result<EventTime, CalendarError> {
    let date = value.to_date_time().ok_or("日历日期或时间无效")?;
    if !(1900..=9999).contains(&date.date_time.year()) {
        return Err("日历日期需在 1900–9999 年之间".into());
    }
    let all_day = value.hour.is_none();
    let zone = if all_day {
        Tz::UTC
    } else if let Some(offset) = date.offset {
        Tz::Fixed(offset)
    } else if let Some(name) = tz {
        match resolver
            .resolve(name)
            .filter(|t| !t.is_floating() && !force)
        {
            Some(zone) => zone,
            None if force => fallback,
            None => {
                return Err("无法识别日历时区；请在来源设置选择解释时区并允许替代 TZID 时区".into())
            }
        }
    } else {
        fallback
    };
    let t = EventTime {
        wall: date.date_time,
        zone,
        all_day,
    };
    t.instant()?;
    Ok(t)
}
fn single(
    c: &ICalendarComponent,
    k: K,
    resolver: &TzResolver<&str>,
    fallback: Tz,
    force: bool,
) -> Result<Option<EventTime>, CalendarError> {
    if c.properties(&k).count() > 1 {
        return Err("日历同一事件包含重复的关键字段".into());
    }
    let Some(e) = c.property(&k) else {
        return Ok(None);
    };
    let mut values = times(e, resolver, fallback, force)?;
    if values.len() != 1 {
        return Err("日历的起止时间必须是单个日期".into());
    }
    Ok(values.pop())
}
/// Enumerate civil recurrences in UTC, then resolve their original zone.
/// This prevents rrule from shifting nonexistent DST wall times into real ones.
pub fn recurrence_set(event: &FeedEvent) -> Result<RRuleSet, CalendarError> {
    let start = event.start.as_ref().ok_or("重复课程缺少开始时间")?;
    let anchor = rrule::Tz::UTC.from_utc_datetime(&start.wall);
    let mut set = RRuleSet::new(anchor);
    if let Some(rule) = &event.rule {
        set = set.rrule(
            rule.parse::<RRule<Unvalidated>>()
                .map_err(|_| "日历重复规则无法识别")?
                .validate(anchor)
                .map_err(|_| "日历重复规则无效")?,
        );
    }
    Ok(set)
}
fn validate_structure(text: &str) -> Result<(), CalendarError> {
    if text.len() > MAX_FEED_BYTES {
        return Err("日历超过 10 MiB，请缩小来源范围".into());
    }
    let mut stack = Vec::new();
    let mut calendars = 0;
    let mut unfolded = String::new();
    for line in text.trim_start_matches('\u{feff}').lines() {
        let line = line.trim_end_matches('\r');
        if line.starts_with([' ', '\t']) {
            unfolded.push_str(&line[1..]);
        } else {
            unfolded.push('\n');
            unfolded.push_str(line);
        }
    }
    for line in unfolded.lines() {
        let upper = line.to_ascii_uppercase();
        if let Some(kind) = upper.strip_prefix("BEGIN:") {
            if stack.is_empty() && kind != "VCALENDAR" {
                return Err("此链接未返回日历，请复制 iCal/ICS 订阅地址".into());
            }
            if kind == "VCALENDAR" {
                calendars += 1;
            }
            stack.push(kind.to_owned());
        } else if let Some(kind) = upper.strip_prefix("END:") {
            if stack.pop().as_deref() != Some(kind) {
                return Err("日历下载不完整或结构损坏，保留上次课表".into());
            }
        } else if upper.split([';', ':']).next() == Some("RRULE") {
            let rule = upper.split_once(':').ok_or("日历重复规则无效")?.1;
            rule.parse::<RRule<Unvalidated>>()
                .map_err(|_| "日历重复规则无法识别")?;
            let mut seen = std::collections::BTreeSet::new();
            for token in rule.split(';') {
                let Some((key, value)) = token.split_once('=') else {
                    return Err("日历重复规则无效".into());
                };
                if value.is_empty()
                    || ![
                        "FREQ",
                        "UNTIL",
                        "COUNT",
                        "INTERVAL",
                        "BYSECOND",
                        "BYMINUTE",
                        "BYHOUR",
                        "BYDAY",
                        "BYMONTHDAY",
                        "BYYEARDAY",
                        "BYWEEKNO",
                        "BYMONTH",
                        "BYSETPOS",
                        "WKST",
                    ]
                    .contains(&key)
                {
                    return Err("日历包含不支持的重复规则".into());
                }
                if !seen.insert(key)
                    || (["COUNT", "INTERVAL"].contains(&key)
                        && value.parse::<u32>().ok().is_none_or(|n| n == 0))
                {
                    return Err("日历重复次数或间隔无效".into());
                }
            }
        } else if upper.split([';', ':']).next() == Some("EXRULE") {
            return Err("暂不支持 EXRULE，请使用 EXDATE 订阅日历".into());
        } else if !line.is_empty() && !line.contains(':') {
            return Err("日历包含无法解析的内容行".into());
        }
    }
    if !stack.is_empty()
        || calendars != 1
        || !text
            .trim_end()
            .to_ascii_uppercase()
            .ends_with("END:VCALENDAR")
    {
        return Err("此链接未返回完整日历，请复制 iCal/ICS 订阅地址".into());
    }
    Ok(())
}

pub fn parse_calendar(
    text_input: &str,
    fallback_zone: &str,
    override_unknown_zone: bool,
) -> Result<ParsedCalendar, CalendarError> {
    let began = Instant::now();
    validate_structure(text_input)?;
    let fallback = fallback_zone
        .parse::<chrono_tz::Tz>()
        .map(Tz::Tz)
        .map_err(|_| "解释时区无效，请选择 IANA 时区")?;
    // Published calcard 0.3.14 strict mode rejects even valid nested BEGIN.
    // Framing and critical properties are validated above and below instead.
    let mut parser = Parser::new(text_input);
    let Entry::ICalendar(calendar) = parser.entry() else {
        return Err("日历格式无效，请使用 iCal/ICS 订阅地址".into());
    };
    if !matches!(parser.entry(), Entry::Eof) {
        return Err("日历包含无法解析的内容，保留上次课表".into());
    }
    let resolver = calendar.build_tz_resolver();
    let mut result = ParsedCalendar {
        name: None,
        events: Vec::new(),
        unsupported_count: 0,
        embedded_zones: super::timezones::embedded_zones(&calendar, override_unknown_zone)?,
    };
    let mut unique = BTreeMap::new();
    let mut total = 0;
    for component in &calendar.components {
        if began.elapsed().as_secs() >= 2 {
            return Err("日历解析超时，请缩小来源范围".into());
        }
        match component.component_type {
            C::VCalendar => {
                let name = text(component, K::Other("X-WR-CALNAME".into()));
                if !name.is_empty() {
                    result.name = Some(name);
                }
            }
            C::VTodo | C::VJournal => result.unsupported_count += 1,
            C::VEvent => {
                total += 1;
                if total > MAX_COMPONENTS {
                    return Err("日历超过 50000 个事件，请缩小范围".into());
                }
                let uid = component
                    .uid()
                    .filter(|s| !s.is_empty())
                    .ok_or("日历事件缺少 UID，无法可靠更新")?
                    .to_string();
                let cancelled = component.status() == Some(&ICalendarStatus::Cancelled);
                let start = single(
                    component,
                    K::Dtstart,
                    &resolver,
                    fallback,
                    override_unknown_zone,
                )?;
                if start.is_none() && !cancelled {
                    return Err("日历事件缺少有效开始时间".into());
                }
                let end = single(
                    component,
                    K::Dtend,
                    &resolver,
                    fallback,
                    override_unknown_zone,
                )?;
                let recurrence_id = single(
                    component,
                    K::RecurrenceId,
                    &resolver,
                    fallback,
                    override_unknown_zone,
                )?;
                let mut duration = EventDuration::default();
                if let Some(start) = &start {
                    if let Some(end) = &end {
                        if component.has_property(&K::Duration) || start.all_day != end.all_day {
                            return Err("课程结束时间与时长冲突".into());
                        }
                        if start.all_day {
                            duration.days = (end.wall - start.wall).num_days();
                        } else {
                            duration.seconds = (end.instant()? - start.instant()?).num_seconds();
                        }
                    } else if let Some(prop) = component.property(&K::Duration) {
                        let Some(V::Duration(d)) = prop.values.first() else {
                            return Err("课程时长无效".into());
                        };
                        if d.neg
                            || (start.all_day && (d.hours != 0 || d.minutes != 0 || d.seconds != 0))
                        {
                            return Err("课程时长无效".into());
                        }
                        duration.days = i64::from(d.weeks) * 7 + i64::from(d.days);
                        duration.seconds = i64::from(d.hours) * 3600
                            + i64::from(d.minutes) * 60
                            + i64::from(d.seconds);
                    } else if start.all_day {
                        duration.days = 1;
                    }
                    if duration.days < 0
                        || duration.seconds < 0
                        || (start.all_day && duration.days == 0)
                    {
                        return Err("课程结束时间必须在开始之后".into());
                    }
                    duration.end(start)?;
                }
                let mut event = FeedEvent {
                    uid,
                    title: text(component, K::Summary),
                    original_title: text(component, K::Summary),
                    description: text(component, K::Description),
                    location: text(component, K::Location),
                    start,
                    duration,
                    rule: None,
                    rdates: Vec::new(),
                    exdates: Vec::new(),
                    recurrence_id,
                    cancelled,
                    sequence: component
                        .property(&K::Sequence)
                        .and_then(|e| e.values.first())
                        .and_then(|v| {
                            if let V::Integer(i) = v {
                                Some(*i)
                            } else {
                                None
                            }
                        })
                        .unwrap_or(0),
                    stamp: single(
                        component,
                        K::Dtstamp,
                        &resolver,
                        fallback,
                        override_unknown_zone,
                    )?
                    .and_then(|t| t.instant().ok())
                    .map_or(0, |t| t.timestamp()),
                    present: component
                        .entries
                        .iter()
                        .map(|e| format!("{:?}", e.name))
                        .collect(),
                };
                if event.title.is_empty() {
                    event.title = "未命名日程".into();
                }
                if component.properties(&K::Rrule).count() > 1 {
                    return Err("暂不支持同一事件含多条 RRULE".into());
                }
                if let Some(entry) = component.property(&K::Rrule) {
                    if event.recurrence_id.is_some() {
                        return Err("重复例外不应包含新的 RRULE".into());
                    }
                    let Some(V::RecurrenceRule(rule)) = entry.values.first() else {
                        return Err("日历重复规则无效".into());
                    };
                    let mut rule = (**rule).clone();
                    if let (Some(until), Some(start)) = (&rule.until, &event.start) {
                        let t = time(until, None, &resolver, start.zone, override_unknown_zone)?;
                        // All recurrence library boundaries are UTC; fixed offsets use wall-time UTC.
                        let boundary = t.instant()?.with_timezone(&start.zone).naive_local();
                        rule.until = Some(PartialDateTime {
                            year: Some(
                                boundary
                                    .format("%Y")
                                    .to_string()
                                    .parse()
                                    .map_err(|_| "截止日期无效")?,
                            ),
                            month: Some(
                                boundary
                                    .format("%m")
                                    .to_string()
                                    .parse()
                                    .map_err(|_| "截止日期无效")?,
                            ),
                            day: Some(
                                boundary
                                    .format("%d")
                                    .to_string()
                                    .parse()
                                    .map_err(|_| "截止日期无效")?,
                            ),
                            hour: Some(boundary.format("%H").to_string().parse().unwrap_or(0)),
                            minute: Some(boundary.format("%M").to_string().parse().unwrap_or(0)),
                            second: Some(boundary.format("%S").to_string().parse().unwrap_or(0)),
                            tz_hour: Some(0),
                            tz_minute: Some(0),
                            ..Default::default()
                        });
                    }
                    event.rule = Some(rule.to_string());
                    recurrence_set(&event)?;
                }
                for (key, dest) in [
                    (K::Rdate, &mut event.rdates),
                    (K::Exdate, &mut event.exdates),
                ] {
                    for entry in component.properties(&key) {
                        dest.extend(times(entry, &resolver, fallback, override_unknown_zone)?);
                    }
                }
                if let Some(start) = &event.start {
                    if event
                        .rdates
                        .iter()
                        .chain(&event.exdates)
                        .chain(&event.recurrence_id)
                        .any(|t| t.all_day != start.all_day)
                    {
                        return Err("重复日期类型必须与开始日期一致".into());
                    }
                }
                let key = (
                    event.uid.clone(),
                    event
                        .recurrence_id
                        .as_ref()
                        .map(EventTime::key)
                        .transpose()?,
                );
                let replace = unique.get(&key).is_none_or(|e: &FeedEvent| {
                    (event.sequence, event.stamp) >= (e.sequence, e.stamp)
                });
                if replace {
                    unique.insert(key, event);
                }
            }
            _ => {}
        }
    }
    result.events = unique.into_values().collect();
    let years = result
        .events
        .iter()
        .flat_map(|e| {
            e.start
                .iter()
                .chain(e.rdates.iter())
                .chain(e.exdates.iter())
                .chain(e.recurrence_id.iter())
        })
        .map(|t| t.wall.year())
        .collect();
    super::timezones::validate_years(&result.embedded_zones, &years)?;
    Ok(result)
}
