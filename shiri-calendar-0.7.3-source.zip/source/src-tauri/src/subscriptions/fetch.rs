use super::{CalendarError, MAX_FEED_BYTES};
pub use reqwest::Url;
use reqwest::{
    blocking::Client,
    header::{ETAG, IF_MODIFIED_SINCE, IF_NONE_MATCH, LAST_MODIFIED},
    redirect::Policy,
};
use std::{io::Read, time::Duration};

#[derive(Default, Clone, Debug)]
pub struct HttpValidators {
    pub etag: Option<String>,
    pub last_modified: Option<String>,
    pub has_cache: bool,
}
#[derive(Clone, Debug)]
pub enum FetchResult {
    Modified {
        body: String,
        etag: Option<String>,
        last_modified: Option<String>,
    },
    NotModified,
}
pub fn normalize_url(input: &str) -> Result<Url, CalendarError> {
    let mut s = input.trim();
    for quote in ['"', '\'', '`'] {
        if s.starts_with(quote) && s.ends_with(quote) && s.len() >= 2 {
            s = s[1..s.len() - 1].trim();
            break;
        }
    }
    if s.len() > 16384 {
        return Err("日历地址过长".into());
    }
    let mut url = Url::parse(s).map_err(|_| "链接无效，请粘贴完整 iCal/ICS 订阅地址")?;
    if matches!(url.scheme(), "webcal" | "webcals") {
        let rebuilt = format!("https:{}", &s[s.find(':').ok_or("链接无效")? + 1..]);
        url = Url::parse(&rebuilt).map_err(|_| "日历链接无效")?;
    }
    if !matches!(url.scheme(), "https" | "http")
        || url.host_str().is_none()
        || !url.username().is_empty()
        || url.password().is_some()
    {
        return Err(
            "请使用 http、https 或 webcal 日历订阅链接；不支持网页登录地址或 URL 用户密码".into(),
        );
    }
    url.set_fragment(None);
    Ok(url)
}
pub fn quote_cleanup_candidate(url: &Url) -> Option<Url> {
    let mut changed = false;
    let pairs: Vec<(String, String)> = url
        .query_pairs()
        .map(|(k, v)| {
            let mut value = v.into_owned();
            if value.len() >= 2
                && ((value.starts_with('"') && value.ends_with('"'))
                    || (value.starts_with('\'') && value.ends_with('\'')))
            {
                value = value[1..value.len() - 1].to_string();
                changed = true;
            }
            (k.into_owned(), value)
        })
        .collect();
    if !changed {
        return None;
    }
    let mut clean = url.clone();
    clean.query_pairs_mut().clear().extend_pairs(pairs);
    Some(clean)
}
pub struct Fetcher {
    client: Client,
}
impl Fetcher {
    pub fn new(timeout: Duration) -> Result<Self, CalendarError> {
        let client = Client::builder()
            .timeout(timeout)
            .connect_timeout(timeout.min(Duration::from_secs(15)))
            .referer(false)
            .user_agent("Shiri-Calendar/0.5")
            .redirect(Policy::custom(|attempt| {
                if attempt.previous().len() > 5
                    || !matches!(attempt.url().scheme(), "http" | "https")
                {
                    attempt.error("日历跳转超出范围")
                } else {
                    attempt.follow()
                }
            }))
            .build()
            .map_err(|_| "网络组件无法启动，请稍后重试")?;
        Ok(Self { client })
    }
    pub fn fetch(
        &self,
        url: &Url,
        validators: &HttpValidators,
    ) -> Result<FetchResult, CalendarError> {
        let first = self.fetch_once(url, validators)?;
        if matches!(first, FetchResult::NotModified) && !validators.has_cache {
            match self.fetch_once(url, &HttpValidators::default())? {
                FetchResult::NotModified => {
                    Err("来源返回未修改，但本地没有缓存，请稍后重试".into())
                }
                r => Ok(r),
            }
        } else {
            Ok(first)
        }
    }
    fn fetch_once(
        &self,
        url: &Url,
        validators: &HttpValidators,
    ) -> Result<FetchResult, CalendarError> {
        let mut request = self.client.get(url.clone());
        if let Some(etag) = &validators.etag {
            request = request.header(IF_NONE_MATCH, etag);
        }
        if let Some(modified) = &validators.last_modified {
            request = request.header(IF_MODIFIED_SINCE, modified);
        }
        let response = request.send().map_err(|e| {
            if e.is_timeout() {
                "下载日历超时，请检查网络后重试"
            } else if e.is_redirect() {
                "日历重定向超过 5 次或使用了不支持的协议"
            } else {
                "无法连接日历来源，请检查网络和订阅地址"
            }
        })?;
        let status = response.status();
        if status.as_u16() == 304 {
            return Ok(FetchResult::NotModified);
        }
        if !status.is_success() {
            return Err(match status.as_u16() {
                401 | 403 => "此日历需要登录或链接已失效，请使用有效的 iCal/ICS 订阅地址".into(),
                429 => "日历来源暂时限制访问，请稍后刷新".into(),
                code => format!("日历来源返回 HTTP {code}，保留上次课表"),
            });
        }
        if response
            .content_length()
            .is_some_and(|n| n > MAX_FEED_BYTES as u64)
        {
            return Err("日历超过 10 MiB，请缩小来源范围".into());
        }
        let etag = response
            .headers()
            .get(ETAG)
            .and_then(|h| h.to_str().ok())
            .map(str::to_owned);
        let last_modified = response
            .headers()
            .get(LAST_MODIFIED)
            .and_then(|h| h.to_str().ok())
            .map(str::to_owned);
        let mut bytes = Vec::new();
        response
            .take((MAX_FEED_BYTES + 1) as u64)
            .read_to_end(&mut bytes)
            .map_err(|_| "日历下载未完成，请检查网络后重试")?;
        if bytes.len() > MAX_FEED_BYTES {
            return Err("日历超过 10 MiB，请缩小来源范围".into());
        }
        let body = String::from_utf8(bytes)
            .map_err(|_| "日历文字编码无效，请使用 UTF-8 格式的 ICS 订阅")?;
        if !body
            .trim_start_matches('\u{feff}')
            .trim_start()
            .get(..15)
            .is_some_and(|s| s.eq_ignore_ascii_case("BEGIN:VCALENDAR"))
        {
            return Err("此链接未返回日历，请复制 iCal/ICS 订阅地址".into());
        }
        Ok(FetchResult::Modified {
            body,
            etag,
            last_modified,
        })
    }
    pub fn checked_fetch(
        &self,
        url: &Url,
        validators: &HttpValidators,
        allow_correction: bool,
    ) -> Result<(Url, FetchResult, bool), CalendarError> {
        match self.fetch(url, validators) {
            Ok(result) => Ok((url.clone(), result, false)),
            Err(error) if allow_correction && error.contains("未返回日历") => {
                if let Some(candidate) = quote_cleanup_candidate(url) {
                    let fetched = self.fetch(&candidate, &HttpValidators::default())?;
                    Ok((candidate, fetched, true))
                } else {
                    Err(error)
                }
            }
            Err(error) => Err(error),
        }
    }
}
pub fn fetch_calendar(
    url: &Url,
    validators: &HttpValidators,
) -> Result<FetchResult, CalendarError> {
    Fetcher::new(Duration::from_secs(30))?.fetch(url, validators)
}
