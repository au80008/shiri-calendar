use super::{
    expand::{civil_date, expand_calendar},
    fetch::{normalize_url, FetchResult, Fetcher, HttpValidators},
    ics::parse_calendar,
    model::*,
    CalendarError,
};
use chrono::{Duration as Days, Utc};
use std::{
    collections::{BTreeSet, HashMap, VecDeque},
    sync::{Arc, Mutex},
    time::{Duration, Instant},
};

pub fn checked_from_body(
    input: &SourceInput,
    body: String,
    etag: Option<String>,
    last_modified: Option<String>,
) -> Result<CheckedFeed, CalendarError> {
    input.validate()?;
    let parsed = Arc::new(parse_calendar(
        &body,
        &input.fallback_zone,
        input.override_unknown_zone,
    )?);
    // Validate a useful bounded range before replacing a good existing cache.
    let today = Utc::now().date_naive();
    let range = OccurrenceRange {
        from: today.to_string(),
        to: (today + Days::days(41)).to_string(),
        display_zone: Some(input.fallback_zone.clone()),
    };
    expand_calendar(&parsed, &CalendarSourceSummary::default(), &range)?;
    Ok(CheckedFeed {
        canonical_url: normalize_url(&input.url)?.to_string(),
        raw_ics: body,
        etag,
        last_modified,
        parsed,
        corrected: false,
    })
}
#[derive(Default)]
pub struct PreviewStore {
    entries: VecDeque<(String, SourceInput, CheckedFeed, Instant)>,
}
impl PreviewStore {
    pub fn len(&self) -> usize {
        self.entries.len()
    }
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }
    pub fn insert(
        &mut self,
        input: SourceInput,
        feed: CheckedFeed,
        now: Instant,
    ) -> Result<PreviewResult, CalendarError> {
        self.entries
            .retain(|e| now.saturating_duration_since(e.3) < Duration::from_secs(600));
        while self.entries.len() >= 8 {
            self.entries.pop_front();
        }
        let ticket = uuid::Uuid::new_v4().to_string();
        let mut samples = Vec::new();
        let mut dates = Vec::new();
        let mut recurring = false;
        for event in &feed.parsed.events {
            if event.cancelled {
                continue;
            }
            if let Some(start) = &event.start {
                let date = start.wall.date().to_string();
                dates.push(date.clone());
                samples.push(PreviewSample {
                    title: event.title.clone(),
                    date,
                    time: (!start.all_day).then(|| start.wall.format("%H:%M").to_string()),
                    location: event.location.clone(),
                });
            }
            recurring |= event.rule.is_some();
        }
        dates.sort();
        samples.sort_by(|a, b| (&a.date, &a.time).cmp(&(&b.date, &b.time)));
        samples.truncate(3);
        let mut warnings = Vec::new();
        if feed.corrected {
            warnings.push("已清理链接参数外层的复制引号，确认后使用修正后的地址".into());
        }
        if recurring {
            warnings.push("包含重复系列，将按查看的日期展开".into());
        }
        let result = PreviewResult {
            ticket: ticket.clone(),
            canonical_host: normalize_url(&feed.canonical_url)?
                .host_str()
                .unwrap_or("")
                .to_string(),
            calendar_name: feed.parsed.name.clone(),
            event_count: feed.parsed.events.iter().filter(|e| !e.cancelled).count(),
            unsupported_count: feed.parsed.unsupported_count,
            first_date: dates.first().cloned(),
            last_date: if recurring {
                None
            } else {
                dates.last().cloned()
            },
            samples,
            warnings,
        };
        self.entries.push_back((ticket, input, feed, now));
        Ok(result)
    }
    pub fn get(
        &self,
        ticket: &str,
        input: &SourceInput,
        now: Instant,
    ) -> Result<CheckedFeed, CalendarError> {
        self.entries
            .iter()
            .find(|e| {
                e.0 == ticket
                    && &e.1 == input
                    && now.saturating_duration_since(e.3) < Duration::from_secs(600)
            })
            .map(|e| e.2.clone())
            .ok_or_else(|| "预览已过期或输入发生变化，请重新检查链接".into())
    }
}
#[derive(Default)]
struct Runtime {
    previews: PreviewStore,
    parsed: HashMap<String, (u64, u64, Arc<ParsedCalendar>)>,
    in_flight: BTreeSet<(String, u64)>,
}
#[derive(Clone, Default)]
pub struct CalendarService {
    runtime: Arc<Mutex<Runtime>>,
}
pub struct RefreshLease {
    runtime: Arc<Mutex<Runtime>>,
    key: (String, u64),
}
impl Drop for RefreshLease {
    fn drop(&mut self) {
        if let Ok(mut state) = self.runtime.lock() {
            state.in_flight.remove(&self.key);
        }
    }
}
impl CalendarService {
    pub fn inspect_calendar(&self, input: SourceInput) -> Result<PreviewResult, CalendarError> {
        input.validate()?;
        let (canonical, result, corrected) = Fetcher::new(Duration::from_secs(30))?.checked_fetch(
            &normalize_url(&input.url)?,
            &HttpValidators::default(),
            true,
        )?;
        let FetchResult::Modified {
            body,
            etag,
            last_modified,
        } = result
        else {
            return Err("未获得可检查的日历内容".into());
        };
        let mut normalized = input.clone();
        normalized.url = canonical.to_string();
        let mut checked = checked_from_body(&normalized, body, etag, last_modified)?;
        checked.corrected = corrected;
        self.runtime
            .lock()
            .map_err(|_| "日历状态忙")?
            .previews
            .insert(input, checked, Instant::now())
    }
    pub fn prepared(
        &self,
        input: &SourceInput,
        ticket: &str,
    ) -> Result<CheckedFeed, CalendarError> {
        self.runtime
            .lock()
            .map_err(|_| "日历状态忙")?
            .previews
            .get(ticket, input, Instant::now())
    }
    pub fn claim_refresh(&self, id: &str, revision: u64) -> Option<RefreshLease> {
        let key = (id.to_string(), revision);
        let mut state = self.runtime.lock().ok()?;
        if !state.in_flight.insert(key.clone()) {
            return None;
        }
        Some(RefreshLease {
            runtime: self.runtime.clone(),
            key,
        })
    }
    pub fn is_refreshing(&self, id: &str, revision: u64) -> bool {
        self.runtime
            .lock()
            .is_ok_and(|s| s.in_flight.contains(&(id.to_owned(), revision)))
    }
    pub fn install(&self, source: &StoredSubscription, parsed: Arc<ParsedCalendar>) {
        if let Ok(mut state) = self.runtime.lock() {
            let version = (source.revision, source.feed_version);
            if state
                .parsed
                .get(&source.id)
                .is_none_or(|(r, f, _)| (*r, *f) <= version)
            {
                state
                    .parsed
                    .insert(source.id.clone(), (version.0, version.1, parsed));
            }
        }
    }
    pub fn forget(&self, id: &str) {
        if let Ok(mut s) = self.runtime.lock() {
            s.parsed.remove(id);
        }
    }
    pub fn parsed(
        &self,
        source: &StoredSubscription,
    ) -> Result<Arc<ParsedCalendar>, CalendarError> {
        let original = self.original_parsed(source)?;
        super::imports::project(&original, source).map(Arc::new)
    }
    fn original_parsed(
        &self,
        source: &StoredSubscription,
    ) -> Result<Arc<ParsedCalendar>, CalendarError> {
        if let Some(p) = self
            .runtime
            .lock()
            .map_err(|_| "日历状态忙")?
            .parsed
            .get(&source.id)
            .filter(|(r, f, _)| *r == source.revision && *f == source.feed_version)
            .map(|(_, _, p)| p.clone())
        {
            return Ok(p);
        }
        let parsed = Arc::new(parse_calendar(
            &source.raw_ics,
            &source.input.fallback_zone,
            source.input.override_unknown_zone,
        )?);
        self.install(source, parsed.clone());
        Ok(parsed)
    }
    pub fn query(
        &self,
        sources: &[StoredSubscription],
        range: &OccurrenceRange,
    ) -> Result<OccurrenceBatch, CalendarError> {
        let from = civil_date(&range.from)?;
        let to = civil_date(&range.to)?;
        if from > to || (to - from).num_days() >= 126 {
            return Err("每次查询需为 1–126 天".into());
        }
        let mut batch = OccurrenceBatch::default();
        for source in sources.iter().filter(|s| s.input.visible) {
            let query = (|| {
                let original = self.original_parsed(source)?;
                let projected = super::imports::project(&original, source)?;
                let mut items = expand_calendar(&projected, &source.summary(), range)?;
                let groups = super::imports::related_groups(
                    &original,
                    &projected,
                    &source.input.fallback_zone,
                )?;
                let metadata: HashMap<_, _> = groups
                    .iter()
                    .filter(|(_, uids)| uids.len() >= 2)
                    .flat_map(|(pattern, uids)| {
                        uids.iter().map(move |uid| (uid, (pattern, uids.len())))
                    })
                    .collect();
                for item in &mut items {
                    if let Some((pattern, count)) = metadata.get(&item.uid) {
                        item.related_title = Some(pattern.title.clone());
                        item.related_slot = Some(pattern.slot.clone());
                        item.related_count = *count;
                    }
                }
                Ok::<_, CalendarError>(items)
            })();
            match query {
                Ok(items) => batch.items.extend(items),
                Err(message) => batch.warnings.push(SourceWarning {
                    source_id: source.id.clone(),
                    message,
                }),
            }
        }
        Ok(batch)
    }
    pub fn download(&self, source: &StoredSubscription) -> Result<CheckedFeed, CalendarError> {
        let validators = HttpValidators {
            etag: source.etag.clone(),
            last_modified: source.last_modified.clone(),
            has_cache: !source.raw_ics.is_empty(),
        };
        match Fetcher::new(Duration::from_secs(30))?
            .fetch(&normalize_url(&source.input.url)?, &validators)?
        {
            FetchResult::Modified {
                body,
                etag,
                last_modified,
            } => checked_from_body(&source.input, body, etag, last_modified),
            FetchResult::NotModified => Ok(CheckedFeed {
                canonical_url: source.input.url.clone(),
                raw_ics: source.raw_ics.clone(),
                etag: source.etag.clone(),
                last_modified: source.last_modified.clone(),
                parsed: self.original_parsed(source)?,
                corrected: false,
            }),
        }
    }
}

use crate::{model::AppSnapshot, state::AppState};
use tauri::{AppHandle, Emitter, Manager};
pub fn app_snapshot(app: &AppHandle) -> Result<AppSnapshot, CalendarError> {
    let state = app.state::<AppState>();
    let mut snapshot = {
        let guard = state.inner.lock().map_err(|_| "状态忙")?;
        guard.repository.as_ref().map_err(|e| e.clone())?.snapshot()
    };
    for source in &mut snapshot.calendar_sources {
        source.refreshing = state
            .subscriptions
            .is_refreshing(&source.id, source.revision);
    }
    Ok(snapshot)
}
pub fn publish_and_tick(app: &AppHandle) {
    if let Ok(snapshot) = app_snapshot(app) {
        let _ = app.emit_to("main", "calendar://state-changed", snapshot);
    }
    let handle = app.clone();
    let _ = app.run_on_main_thread(move || crate::reminders::tick(&handle));
}
