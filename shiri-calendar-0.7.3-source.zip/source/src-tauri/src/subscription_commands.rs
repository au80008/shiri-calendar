use crate::{
    commands::authorize,
    model::AppSnapshot,
    state::AppState,
    subscriptions::{model::*, service},
};
use tauri::{AppHandle, Manager, WebviewWindow};

#[tauri::command]
pub async fn inspect_calendar(
    app: AppHandle,
    window: WebviewWindow,
    input: SourceInput,
) -> Result<PreviewResult, String> {
    authorize(&window, "main")?;
    tauri::async_runtime::spawn_blocking(move || {
        app.state::<AppState>()
            .subscriptions
            .inspect_calendar(input)
    })
    .await
    .map_err(|_| "日历检查任务未完成")?
}
#[tauri::command]
pub async fn save_subscription(
    app: AppHandle,
    window: WebviewWindow,
    id: Option<String>,
    input: SourceInput,
    ticket: Option<String>,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    tauri::async_runtime::spawn_blocking(move || {
        let state = app.state::<AppState>();
        let checked = ticket
            .map(|t| state.subscriptions.prepared(&input, &t))
            .transpose()?;
        let saved = {
            let mut guard = state.inner.lock().map_err(|_| "状态忙")?;
            guard
                .repository
                .as_mut()
                .map_err(|e| e.clone())?
                .save_subscription(id.as_deref(), &input, checked.as_ref())?
        };
        if let Some(feed) = checked {
            state.subscriptions.install(&saved, feed.parsed);
        } else {
            let _ = state.subscriptions.parsed(&saved);
        }
        service::publish_and_tick(&app);
        service::app_snapshot(&app)
    })
    .await
    .map_err(|_| "日历保存任务未完成")?
}
#[tauri::command]
pub async fn remove_subscription(
    app: AppHandle,
    window: WebviewWindow,
    id: String,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    tauri::async_runtime::spawn_blocking(move || {
        let state = app.state::<AppState>();
        {
            let mut guard = state.inner.lock().map_err(|_| "状态忙")?;
            guard
                .repository
                .as_mut()
                .map_err(|e| e.clone())?
                .remove_subscription(&id)?;
        }
        state.subscriptions.forget(&id);
        service::publish_and_tick(&app);
        service::app_snapshot(&app)
    })
    .await
    .map_err(|_| "日历移除任务未完成")?
}
#[tauri::command]
pub async fn get_calendar_occurrences(
    app: AppHandle,
    window: WebviewWindow,
    range: OccurrenceRange,
) -> Result<OccurrenceBatch, String> {
    authorize(&window, "main")?;
    tauri::async_runtime::spawn_blocking(move || {
        let state = app.state::<AppState>();
        let sources = {
            let guard = state.inner.lock().map_err(|_| "状态忙")?;
            guard
                .repository
                .as_ref()
                .map_err(|e| e.clone())?
                .data
                .subscriptions
                .clone()
        };
        state.subscriptions.query(&sources, &range)
    })
    .await
    .map_err(|_| "日历查询任务未完成")?
}
#[tauri::command]
pub fn get_calendar_link(
    app: AppHandle,
    window: WebviewWindow,
    id: String,
) -> Result<String, String> {
    authorize(&window, "main")?;
    let state = app.state::<AppState>();
    let guard = state.inner.lock().map_err(|_| "状态忙")?;
    guard
        .repository
        .as_ref()
        .map_err(|e| e.clone())?
        .data
        .subscriptions
        .iter()
        .find(|s| s.id == id)
        .map(|_| String::new())
        .ok_or_else(|| "日历来源已移除".into())
}
#[tauri::command]
pub async fn set_calendar_view(
    app: AppHandle,
    window: WebviewWindow,
    prefs: CalendarViewPrefs,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    tauri::async_runtime::spawn_blocking(move || {
        let state = app.state::<AppState>();
        {
            let mut guard = state.inner.lock().map_err(|_| "状态忙")?;
            guard
                .repository
                .as_mut()
                .map_err(|e| e.clone())?
                .set_calendar_view(prefs)?;
        }
        service::publish_and_tick(&app);
        service::app_snapshot(&app)
    })
    .await
    .map_err(|_| "日历设置未保存")?
}
