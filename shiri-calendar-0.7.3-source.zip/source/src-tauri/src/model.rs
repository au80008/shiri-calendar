use chrono::{NaiveDate, NaiveTime};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ItemKind {
    #[default]
    Event,
    Note,
    Task,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Frequency {
    Daily,
    Weekly,
    Monthly,
    Yearly,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Recurrence {
    pub frequency: Frequency,
    pub interval: u16,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub weekdays: Option<Vec<u8>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub until: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub count: Option<u32>,
}
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct OccurrenceException {
    #[serde(default)]
    pub deleted: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub completed: Option<bool>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub input: Option<ItemInput>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ItemInput {
    #[serde(default)]
    pub kind: ItemKind,
    pub title: String,
    pub date: String,
    pub time: Option<String>,
    #[serde(default)]
    pub end_time: Option<String>,
    pub notes: String,
    pub reminder_minutes: Option<i64>,
    pub completed: bool,
    #[serde(default)]
    pub recurrence: Option<Recurrence>,
}
impl ItemInput {
    pub fn validate(&self) -> Result<(), String> {
        if self.kind == ItemKind::Note
            && (self.time.is_some()
                || self.end_time.is_some()
                || self.reminder_minutes.is_some()
                || self.completed)
        {
            return Err("备忘不设置时间、提醒或完成状态".into());
        }
        if self.title.trim().is_empty() || self.title.trim().chars().count() > 120 {
            return Err("日程名称需为 1–120 字".into());
        }
        if self.notes.chars().count() > 2000 {
            return Err("备注最多 2000 字".into());
        }
        let date = NaiveDate::parse_from_str(&self.date, "%Y-%m-%d").map_err(|_| "日期无效")?;
        if date.format("%Y-%m-%d").to_string() != self.date
            || self.date.as_str() < "1900-01-01"
            || self.date.as_str() > "9999-12-31"
        {
            return Err("日期需为 1900–9999 年的有效日期".into());
        }
        if let Some(time) = &self.time {
            let parsed = NaiveTime::parse_from_str(time, "%H:%M").map_err(|_| "时间无效")?;
            if parsed.format("%H:%M").to_string() != *time {
                return Err("时间需为 HH:mm".into());
            }
        }
        if let Some(end) = &self.end_time {
            let parsed = NaiveTime::parse_from_str(end, "%H:%M").map_err(|_| "结束时间无效")?;
            if parsed.format("%H:%M").to_string() != *end {
                return Err("结束时间需为 HH:mm".into());
            }
            let start = self.time.as_ref().ok_or("填写结束时间前请先填写开始时间")?;
            if end <= start {
                return Err("结束时间需晚于开始时间（同一天）".into());
            }
        }
        if let Some(minutes) = self.reminder_minutes {
            if self.time.is_none() {
                return Err("设置提醒前请先填写时间".into());
            }
            if ![0, 5, 10, 30].contains(&minutes) {
                return Err("提醒时间无效".into());
            }
        }
        if let Some(rule) = &self.recurrence {
            if self.kind == ItemKind::Note || self.completed {
                return Err("重复日程不支持备忘或整组完成状态".into());
            }
            if !(1..=999).contains(&rule.interval)
                || rule.count.is_some_and(|n| !(1..=10000).contains(&n))
                || (rule.until.is_some() && rule.count.is_some())
            {
                return Err("重复间隔或结束条件无效".into());
            }
            if let Some(days) = &rule.weekdays {
                let unique: BTreeSet<_> = days.iter().collect();
                if rule.frequency != Frequency::Weekly
                    || days.is_empty()
                    || unique.len() != days.len()
                    || days.iter().any(|d| !(1..=7).contains(d))
                {
                    return Err("重复星期无效".into());
                }
            }
            if let Some(until) = &rule.until {
                let end =
                    NaiveDate::parse_from_str(until, "%Y-%m-%d").map_err(|_| "重复结束日期无效")?;
                if end.format("%Y-%m-%d").to_string() != *until
                    || until < &self.date
                    || until.as_str() > "9999-12-31"
                {
                    return Err("重复结束日期需不早于开始日期".into());
                }
            }
        }
        Ok(())
    }
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CalendarItem {
    #[serde(default)]
    pub kind: ItemKind,
    pub id: String,
    pub title: String,
    pub date: String,
    pub time: Option<String>,
    #[serde(default)]
    pub end_time: Option<String>,
    pub notes: String,
    pub reminder_minutes: Option<i64>,
    pub completed: bool,
    pub created_at: String,
    pub updated_at: String,
    #[serde(default)]
    pub recurrence: Option<Recurrence>,
    #[serde(default)]
    pub exceptions: BTreeMap<String, OccurrenceException>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub series_id: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub occurrence_date: Option<String>,
}
impl CalendarItem {
    pub fn input(&self) -> ItemInput {
        ItemInput {
            kind: self.kind,
            title: self.title.clone(),
            date: self.date.clone(),
            time: self.time.clone(),
            end_time: self.end_time.clone(),
            notes: self.notes.clone(),
            reminder_minutes: self.reminder_minutes,
            completed: self.completed,
            recurrence: self.recurrence.clone(),
        }
    }
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WindowPrefs {
    pub x: Option<f64>,
    pub y: Option<f64>,
    pub pinned: bool,
    pub collapsed: bool,
    #[serde(default)]
    pub timetable_open: bool,
    #[serde(default)]
    pub fullscreen: bool,
    #[serde(default)]
    pub restore_right: Option<f64>,
    #[serde(default)]
    pub restore_top: Option<f64>,
    #[serde(default)]
    pub restore_timetable_open: bool,
}
impl Default for WindowPrefs {
    fn default() -> Self {
        Self {
            x: None,
            y: None,
            pinned: true,
            collapsed: false,
            timetable_open: false,
            fullscreen: false,
            restore_right: None,
            restore_top: None,
            restore_timetable_open: false,
        }
    }
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub enum Language {
    #[default]
    #[serde(rename = "zh-CN")]
    ZhCn,
    #[serde(rename = "en")]
    En,
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum CalendarScale {
    #[default]
    Week,
    Month,
    Year,
}
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct AppSettings {
    #[serde(default)]
    pub language: Language,
    #[serde(default)]
    pub calendar_view: CalendarScale,
}
#[derive(Clone, Copy, Debug, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum WindowMode {
    Compact,
    Timetable,
    Fullscreen,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct StoredData {
    pub schema_version: u32,
    pub items: Vec<CalendarItem>,
    #[serde(default)]
    pub window: WindowPrefs,
    #[serde(default)]
    pub delivered: BTreeSet<String>,
    #[serde(default)]
    pub pending: Vec<String>,
    #[serde(default)]
    pub subscriptions: Vec<crate::subscriptions::model::StoredSubscription>,
    #[serde(default)]
    pub calendar_view: crate::subscriptions::model::CalendarViewPrefs,
    #[serde(default)]
    pub settings: AppSettings,
}
impl Default for StoredData {
    fn default() -> Self {
        Self {
            schema_version: 7,
            items: Vec::new(),
            window: WindowPrefs::default(),
            delivered: BTreeSet::new(),
            pending: Vec::new(),
            subscriptions: Vec::new(),
            calendar_view: Default::default(),
            settings: Default::default(),
        }
    }
}
#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AppSnapshot {
    pub items: Vec<CalendarItem>,
    pub window: WindowPrefs,
    pub warnings: Vec<String>,
    pub calendar_sources: Vec<crate::subscriptions::model::CalendarSourceSummary>,
    pub calendar_view: crate::subscriptions::model::CalendarViewPrefs,
    pub settings: AppSettings,
}
#[derive(Clone, Debug, Serialize)]
pub struct Reminder {
    pub key: String,
    pub item: CalendarItem,
}
