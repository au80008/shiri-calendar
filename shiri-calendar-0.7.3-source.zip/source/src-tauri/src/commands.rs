use crate::{
    desktop,
    model::{AppSnapshot, ItemInput, Reminder},
    reminders,
    state::AppState,
    storage::Repository,
};
use tauri::{AppHandle, Emitter, Manager, WebviewWindow};

pub(crate) fn authorize(window: &WebviewWindow, label: &str) -> Result<(), String> {
    let url = window.url().map_err(|e| e.to_string())?;
    let local = url.scheme() == "tauri"
        || (url.scheme() == "http" && url.host_str() == Some("tauri.localhost"))
        || (cfg!(debug_assertions)
            && url.scheme() == "http"
            && url.host_str() == Some("127.0.0.1")
            && url.port() == Some(1420));
    if window.label() == label && local {
        Ok(())
    } else {
        Err("当前窗口无权执行此操作".into())
    }
}
fn read(app: &AppHandle) -> Result<AppSnapshot, String> {
    crate::subscriptions::service::app_snapshot(app)
}
fn mutate(
    app: &AppHandle,
    operation: impl FnOnce(&mut Repository) -> Result<(), String>,
) -> Result<AppSnapshot, String> {
    let snapshot = {
        let state = app.state::<AppState>();
        let mut guard = state.inner.lock().map_err(|_| "状态忙")?;
        let repo = guard.repository.as_mut().map_err(|e| e.clone())?;
        operation(repo)?;
        repo.snapshot()
    };
    let _ = app.emit_to("main", "calendar://state-changed", &snapshot);
    let handle = app.clone();
    let _ = app.run_on_main_thread(move || reminders::tick(&handle));
    Ok(snapshot)
}
#[tauri::command]
pub fn get_language(
    app: AppHandle,
    window: WebviewWindow,
) -> Result<crate::model::Language, String> {
    let label = if window.label() == "reminder" {
        "reminder"
    } else {
        "main"
    };
    authorize(&window, label)?;
    let state = app.state::<AppState>();
    let guard = state.inner.lock().map_err(|_| "状态忙")?;
    Ok(guard
        .repository
        .as_ref()
        .map(|repo| repo.data.settings.language)
        .unwrap_or_default())
}
#[tauri::command]
pub fn set_settings(
    app: AppHandle,
    window: WebviewWindow,
    settings: crate::model::AppSettings,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    let snapshot = mutate(&app, |repo| {
        let mut next = repo.data.clone();
        next.settings = settings;
        repo.commit(next)
    })?;
    if let Err(error) = desktop::apply_language(&app, snapshot.settings.language) {
        desktop::warn(&app, error);
    }
    let _ = app.emit("calendar://language-changed", snapshot.settings.language);
    Ok(snapshot)
}
#[tauri::command]
pub fn set_window_mode(
    app: AppHandle,
    window: WebviewWindow,
    mode: crate::model::WindowMode,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    desktop::set_window_mode(&app, mode)
}
#[tauri::command]
pub fn get_snapshot(app: AppHandle, window: WebviewWindow) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    read(&app)
}
#[tauri::command]
pub fn delete_imported_event(
    app: AppHandle,
    window: WebviewWindow,
    source_id: String,
    uid: String,
    recurrence_key: String,
    all_occurrences: Option<bool>,
    all_related: Option<bool>,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    if all_occurrences.unwrap_or(false) && all_related.unwrap_or(false) {
        return Err("请选择一种删除范围".into());
    }
    mutate(&app, |repo| {
        if all_related.unwrap_or(false) {
            repo.delete_imported_related(&source_id, &uid)
        } else if all_occurrences.unwrap_or(false) {
            repo.delete_imported_series(&source_id, &uid)
        } else {
            repo.delete_imported(&source_id, &uid, &recurrence_key)
        }
    })
}
#[tauri::command]
pub fn edit_imported_event(
    app: AppHandle,
    window: WebviewWindow,
    source_id: String,
    uid: String,
    recurrence_key: String,
    input: Option<crate::subscriptions::imports::ImportedInput>,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    mutate(&app, |repo| {
        repo.edit_imported(&source_id, &uid, &recurrence_key, input)
    })
}
#[tauri::command]
pub fn create_item(
    app: AppHandle,
    window: WebviewWindow,
    input: ItemInput,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    mutate(&app, |r| r.create(input).map(|_| ()))
}
#[tauri::command]
pub fn update_item(
    app: AppHandle,
    window: WebviewWindow,
    id: String,
    input: ItemInput,
    occurrence_date: Option<String>,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    mutate(&app, |r| match occurrence_date {
        Some(date) => r.update_occurrence(&id, &date, input),
        None => r.update(&id, input),
    })
}
#[tauri::command]
pub fn delete_item(
    app: AppHandle,
    window: WebviewWindow,
    id: String,
    occurrence_date: Option<String>,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    mutate(&app, |r| match occurrence_date {
        Some(date) => r.delete_occurrence(&id, &date),
        None => r.delete(&id),
    })
}
#[tauri::command]
pub fn set_completed(
    app: AppHandle,
    window: WebviewWindow,
    id: String,
    completed: bool,
    occurrence_date: Option<String>,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    mutate(&app, |r| match occurrence_date {
        Some(date) => r.set_completed_occurrence(&id, &date, completed),
        None => r.set_completed(&id, completed),
    })
}
#[tauri::command]
pub fn set_pinned(
    app: AppHandle,
    window: WebviewWindow,
    pinned: bool,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    let s = desktop::set_pinned(&app, pinned)?;
    desktop::publish(&app);
    Ok(s)
}
#[tauri::command]
pub fn set_collapsed(
    app: AppHandle,
    window: WebviewWindow,
    collapsed: bool,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    desktop::set_collapsed(&app, collapsed)
}
#[tauri::command]
pub fn set_timetable_open(
    app: AppHandle,
    window: WebviewWindow,
    open: bool,
) -> Result<AppSnapshot, String> {
    authorize(&window, "main")?;
    desktop::set_timetable_open(&app, open)
}
#[tauri::command]
pub fn hide_main(app: AppHandle, window: WebviewWindow) -> Result<(), String> {
    authorize(&window, "main")?;
    desktop::hide_main(&app)
}
#[tauri::command]
pub fn show_main(
    app: AppHandle,
    window: WebviewWindow,
    date: Option<String>,
) -> Result<(), String> {
    authorize(&window, "main")?;
    desktop::show_main(&app, date)
}
#[tauri::command]
pub fn get_active_reminders(
    app: AppHandle,
    window: WebviewWindow,
) -> Result<Vec<Reminder>, String> {
    authorize(&window, "reminder")?;
    let state = app.state::<AppState>();
    let g = state.inner.lock().map_err(|_| "状态忙")?;
    Ok(g.active.clone())
}
fn dismiss(app: &AppHandle, key: &str) -> Result<(), String> {
    let active = {
        let state = app.state::<AppState>();
        let mut g = state.inner.lock().map_err(|_| "状态忙")?;
        let crate::state::RuntimeState {
            repository, active, ..
        } = &mut *g;
        let repo = repository.as_mut().map_err(|e| e.clone())?;
        reminders::dismiss_pending(repo, active, key)?;
        g.active.clone()
    };
    if active.is_empty() {
        if let Some(w) = app.get_webview_window("reminder") {
            w.hide().map_err(|e| e.to_string())?;
        }
    }
    let _ = app.emit_to("reminder", "calendar://reminders-changed", active);
    let handle = app.clone();
    let _ = app.run_on_main_thread(move || reminders::tick(&handle));
    Ok(())
}
#[tauri::command]
pub fn dismiss_reminder(app: AppHandle, window: WebviewWindow, key: String) -> Result<(), String> {
    authorize(&window, "reminder")?;
    dismiss(&app, &key)
}
#[tauri::command]
pub async fn open_reminder(
    app: AppHandle,
    window: WebviewWindow,
    key: String,
) -> Result<(), String> {
    authorize(&window, "reminder")?;
    tauri::async_runtime::spawn_blocking(move || {
        let state = app.state::<AppState>();
        let (items, sources, zone) = {
            let g = state.inner.lock().map_err(|_| "状态忙")?;
            if !g.active.iter().any(|r| r.key == key) {
                return Err("提醒已关闭".into());
            }
            let repo = g.repository.as_ref().map_err(|e| e.clone())?;
            (
                repo.data.items.clone(),
                repo.data.subscriptions.clone(),
                repo.data.calendar_view.display_zone.clone(),
            )
        };
        let item = if crate::subscriptions::reminders::is_external(&key) {
            crate::subscriptions::reminders::resolve_external_plan(
                &state.subscriptions,
                &key,
                &sources,
                zone.as_deref(),
            )?
            .map(|r| r.item)
        } else {
            reminders::resolve_plan(&items, &key)
        }
        .ok_or("这条日程已修改或删除")?;
        desktop::show_main(&app, Some(item.date))?;
        dismiss(&app, &key)
    })
    .await
    .map_err(|_| "提醒跳转未完成")?
}
