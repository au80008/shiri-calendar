use tauri::Manager;
mod commands;
pub mod desktop;
pub mod model;
pub mod reminders;
mod state;
pub mod storage;
mod subscription_commands;
pub mod subscriptions;

pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_single_instance::init(|app, _, _| {
            let _ = desktop::show_main(app, None);
        }))
        .plugin(tauri_plugin_global_shortcut::Builder::new().build())
        .plugin(tauri_plugin_notification::init())
        .plugin(
            tauri::plugin::Builder::<tauri::Wry>::new("navigation-guard")
                .on_navigation(|_, url| {
                    url.scheme() == "tauri"
                        || (url.scheme() == "http" && url.host_str() == Some("tauri.localhost"))
                        || (cfg!(debug_assertions)
                            && url.scheme() == "http"
                            && url.host_str() == Some("127.0.0.1")
                            && url.port() == Some(1420))
                })
                .build(),
        )
        .invoke_handler(tauri::generate_handler![
            commands::get_snapshot,
            commands::get_language,
            commands::set_settings,
            commands::set_window_mode,
            commands::edit_imported_event,
            commands::delete_imported_event,
            commands::create_item,
            commands::update_item,
            commands::delete_item,
            commands::set_completed,
            commands::set_pinned,
            commands::set_collapsed,
            commands::set_timetable_open,
            commands::hide_main,
            commands::show_main,
            commands::get_active_reminders,
            commands::dismiss_reminder,
            commands::open_reminder,
            subscription_commands::inspect_calendar,
            subscription_commands::save_subscription,
            subscription_commands::remove_subscription,
            subscription_commands::get_calendar_occurrences,
            subscription_commands::get_calendar_link,
            subscription_commands::set_calendar_view
        ])
        .setup(|app| {
            let directory = app.path().app_local_data_dir()?;
            #[cfg(debug_assertions)]
            let directory = directory.join("development");
            app.manage(state::AppState::new(storage::Repository::open(directory)));
            // Initialize state before either WebView can issue its first IPC call.
            for config in &app.config().app.windows {
                tauri::WebviewWindowBuilder::from_config(app, config)?.build()?;
            }
            if let Some(window) = app.get_webview_window("main") {
                window_bounds::install(&window)?;
            }
            if let Err(error) = desktop::init(app.handle()) {
                desktop::warn(app.handle(), format!("桌面集成异常：{error}"));
                let _ = desktop::configure(app.handle(), true);
                if let Some(w) = app.get_webview_window("main") {
                    let _ = w.show();
                }
            }
            reminders::start(app.handle().clone());
            Ok(())
        })
        .on_window_event(|window, event| {
            if window.label() == "main" {
                match event {
                    tauri::WindowEvent::CloseRequested { api, .. } => {
                        api.prevent_close();
                        let _ = desktop::hide_main(window.app_handle());
                    }
                    tauri::WindowEvent::Moved(position) => {
                        desktop::moved(window.app_handle(), position.x as f64, position.y as f64);
                    }
                    _ => {}
                }
            } else if window.label() == "reminder" {
                if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                    api.prevent_close();
                    let _ = window.hide();
                }
            }
        })
        .run(tauri::generate_context!())
        .expect("无法启动拾日");
}
pub mod recurrence;
mod window_bounds;
