use crate::model::{CalendarItem, Frequency};
use chrono::{Datelike, Duration, NaiveDate};
use std::collections::BTreeMap;

fn parse(value: &str) -> Option<NaiveDate> {
    let date = NaiveDate::parse_from_str(value, "%Y-%m-%d").ok()?;
    (date.format("%Y-%m-%d").to_string() == value && ("1900-01-01"..="9999-12-31").contains(&value))
        .then_some(date)
}

/// Enumerate planned valid dates before applying exceptions. Daily and weekly rules
/// seek directly to the requested interval, including their ordinal for count ends.
pub fn nominal_dates(item: &CalendarItem, start: &str, end: &str) -> Vec<String> {
    let (Some(anchor), Some(lower), Some(mut upper), Some(rule)) = (
        parse(&item.date),
        parse(start),
        parse(end),
        item.recurrence.as_ref(),
    ) else {
        return Vec::new();
    };
    if item.input().validate().is_err() || lower > upper {
        return Vec::new();
    }
    if let Some(until) = rule.until.as_deref().and_then(parse) {
        upper = upper.min(until);
    }
    let lower = lower.max(anchor);
    if lower > upper {
        return Vec::new();
    }
    let interval = i64::from(rule.interval);
    let limit = u64::from(rule.count.unwrap_or(u32::MAX));
    let mut out = Vec::new();
    match rule.frequency {
        Frequency::Daily => {
            let distance = lower.signed_duration_since(anchor).num_days();
            let mut ordinal = ((distance + interval - 1) / interval) as u64;
            while ordinal < limit {
                let Some(date) =
                    anchor.checked_add_signed(Duration::days(ordinal as i64 * interval))
                else {
                    break;
                };
                if date > upper {
                    break;
                }
                out.push(date.to_string());
                ordinal += 1;
            }
        }
        Frequency::Weekly => {
            let anchor_day = anchor.weekday().number_from_monday();
            let monday = anchor - Duration::days(i64::from(anchor_day - 1));
            let mut days = rule
                .weekdays
                .clone()
                .unwrap_or_else(|| vec![anchor_day as u8]);
            days.sort_unstable();
            let first_count = days.iter().filter(|d| u32::from(**d) >= anchor_day).count() as u64;
            let mut cycle = lower.signed_duration_since(monday).num_days() / (7 * interval);
            while let Some(week) = monday.checked_add_signed(Duration::days(cycle * interval * 7)) {
                if week > upper {
                    break;
                }
                let mut ordinal = if cycle == 0 {
                    0
                } else {
                    first_count + (cycle as u64 - 1) * days.len() as u64
                };
                for day in &days {
                    let Some(date) = week.checked_add_signed(Duration::days(i64::from(*day - 1)))
                    else {
                        continue;
                    };
                    if date < anchor {
                        continue;
                    }
                    if ordinal >= limit {
                        return out;
                    }
                    if date >= lower && date <= upper {
                        out.push(date.to_string());
                    }
                    ordinal += 1;
                }
                cycle += 1;
            }
        }
        Frequency::Monthly | Frequency::Yearly => {
            let step = interval
                * if rule.frequency == Frequency::Yearly {
                    12
                } else {
                    1
                };
            let anchor_month = i64::from(anchor.year()) * 12 + i64::from(anchor.month0());
            let lower_month = i64::from(lower.year()) * 12 + i64::from(lower.month0());
            let mut cycle = if rule.count.is_some() {
                0
            } else {
                (lower_month - anchor_month) / step
            };
            let mut ordinal = 0u64;
            loop {
                let month = anchor_month + cycle * step;
                let year = month / 12;
                if year > i64::from(upper.year()) || year > 9999 {
                    break;
                }
                if let Some(date) =
                    NaiveDate::from_ymd_opt(year as i32, (month % 12 + 1) as u32, anchor.day())
                {
                    if date > upper || ordinal >= limit {
                        break;
                    }
                    if date >= lower {
                        out.push(date.to_string());
                    }
                    ordinal += 1;
                }
                cycle += 1;
            }
        }
    }
    out
}

pub fn is_planned(item: &CalendarItem, nominal: &str) -> bool {
    !nominal_dates(item, nominal, nominal).is_empty()
}

/// Resolve by original scheduled date, regardless of a later move.
pub fn resolve_occurrence(item: &CalendarItem, nominal: &str) -> Option<CalendarItem> {
    if !is_planned(item, nominal) {
        return None;
    }
    let exception = item.exceptions.get(nominal);
    if exception.is_some_and(|e| e.deleted) {
        return None;
    }
    let mut result = item.clone();
    result.id = format!("{}@{}", item.id, nominal);
    result.date = nominal.into();
    result.series_id = Some(item.id.clone());
    result.occurrence_date = Some(nominal.into());
    result.exceptions.clear();
    if let Some(input) = exception.and_then(|e| e.input.as_ref()) {
        result.kind = input.kind;
        result.title = input.title.clone();
        result.date = input.date.clone();
        result.time = input.time.clone();
        result.end_time = input.end_time.clone();
        result.notes = input.notes.clone();
        result.reminder_minutes = input.reminder_minutes;
        result.completed = input.completed;
    }
    if let Some(completed) = exception.and_then(|e| e.completed) {
        result.completed = completed;
    }
    Some(result)
}

/// Snapshots contain base series. Consumers expand only the visible civil range.
pub fn expand_items(items: &[CalendarItem], start: &str, end: &str) -> Vec<CalendarItem> {
    if parse(start).is_none() || parse(end).is_none() || start > end {
        return Vec::new();
    }
    let mut result = Vec::new();
    for item in items {
        if item.recurrence.is_none() {
            if item.date.as_str() >= start && item.date.as_str() <= end {
                result.push(item.clone());
            }
            continue;
        }
        let mut occurrences = BTreeMap::new();
        for nominal in
            nominal_dates(item, start, end)
                .into_iter()
                .chain(item.exceptions.iter().filter_map(|(date, e)| {
                    e.input
                        .as_ref()
                        .filter(|input| input.date.as_str() >= start && input.date.as_str() <= end)
                        .map(|_| date.clone())
                }))
        {
            if let Some(value) = resolve_occurrence(item, &nominal) {
                if value.date.as_str() >= start && value.date.as_str() <= end {
                    occurrences.insert(value.id.clone(), value);
                }
            }
        }
        result.extend(occurrences.into_values());
    }
    result.sort_by(|a, b| (&a.date, &a.time, &a.id).cmp(&(&b.date, &b.time, &b.id)));
    result
}

pub fn resolve_item(items: &[CalendarItem], id: &str) -> Option<CalendarItem> {
    if let Some(item) = items.iter().find(|i| i.id == id && i.recurrence.is_none()) {
        return Some(item.clone());
    }
    let (series_id, date) = id.rsplit_once('@')?;
    resolve_occurrence(items.iter().find(|i| i.id == series_id)?, date)
}
