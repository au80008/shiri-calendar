# 拾日 · 0.7.3 开源版

Windows 本地日历、待办与提醒，支持月/周/年视图和日历订阅。

## 运行

下载配套 Windows x64 程序包，解压后运行拾日.exe；需要 Microsoft Edge WebView2。提醒需要程序保持运行，关机或休眠时不会主动唤醒电脑。

本开源版使用独立应用标识 com.shiri.calendar.opensource；数据保存在 %LOCALAPPDATA%\com.shiri.calendar.opensource 下，与本地开发版分开。不要在 Issue 中上传真实订阅链接、课程或数据库。

## 构建

需要 Node.js、Rust stable MSVC、Microsoft C++ Build Tools 的 C++ 桌面开发组件与 Windows SDK，以及 WebView2。

```powershell
npm ci
npm run tauri build -- --no-bundle
```

程序位于 src-tauri/target/release/shiri-calendar.exe；前端资源由构建流程嵌入程序。开发预览可运行 npm run tauri dev。

## 许可证

原创代码采用 MIT，见 LICENSE；第三方版权、许可全文和对应源码获取说明合并在 THIRD_PARTY_NOTICES.txt，分发源码与程序时一并保留。
