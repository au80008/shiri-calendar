Shiri Calendar 0.7.3 - Windows x64

Getting started
1. Download shiri-calendar-0.7.3-windows-x64.zip and extract the entire archive.
2. Open the extracted windows-x64 folder and double-click "拾日.exe".
3. Microsoft Edge WebView2 is required. If it is missing, install the
   Microsoft Edge WebView2 Evergreen Runtime, then start the app again.

The app includes its interface files. No development server, Node.js,
or Rust installation is needed to run this Windows package.

Using the app
- Use the Add button to create calendar events, tasks, or notes.
- Use the gear icon to open Settings and select English for the interface.
- Press Ctrl+Alt+C to show or hide the window.
- Hiding the window keeps the app and reminders running in the system tray.
- To quit completely, use the tray icon's quit option. Reminders require
  the app to remain running; the app cannot wake a sleeping or powered-off PC.

Local data
Calendar data and backups are stored in:
%LOCALAPPDATA%\com.shiri.calendar.opensource\

This location is separate from the local development version. Calendar
subscription URLs may contain private access keys. Do not share your
subscription URLs or database files publicly.

License
Original project code is licensed under MIT; see LICENSE.
Third-party notices, license texts, and source availability information
are included in THIRD_PARTY_NOTICES.txt. Keep these files when redistributing.

The separate shiri-calendar-0.7.3-source.zip archive is for building the app
from source; it is not the ready-to-run Windows package.
